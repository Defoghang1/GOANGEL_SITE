import os
import pickle
import logging
from datetime import datetime as dt, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.stats import poisson

try:
    import torch
except ImportError:
    torch = None

from features import (
    process_matches,
    train_models,
    build_feature_vector,
    build_tracking_state,
    TeamHistoryTracker,
    EloSystem,
    EXPECTED_FEATURE_COUNT,
    FEATURE_NAMES,
    _extract_model_probabilities,
)
from api import get_all_matches_for_date, get_historical_matches
from config import (
    CACHE_DIR,
    HISTORICAL_FILE,
    MODELS_FILE,
    SCALER_FILE,
    WEIGHTS_FILE,
    CACHE_NEVER_EXPIRES,
    CACHE_TTL_HOURS,
    CACHE_ATOMIC_WRITE,
    MIN_MATCHES_FOR_TRAINING,
    MIN_REALISTIC_LAMBDA,
    MAX_REALISTIC_LAMBDA,
    DEFAULT_HOME_LAMBDA,
    DEFAULT_AWAY_LAMBDA,
    DIXON_COLES_RHO,
    TEMPERATURE_SCALING_ENABLED,
    TEMPERATURE_SCALING_DEFAULT,
    TEMPERATURE_SCALING_MIN,
    TEMPERATURE_SCALING_MAX,
    ENSEMBLE_DISAGREEMENT_THRESHOLD,
    REALISTIC_HOME_LAMBDA_BY_GROUP,
    REALISTIC_AWAY_LAMBDA_BY_GROUP,
    get_competition_group,
    stage_print,
)

logger = logging.getLogger("goangel.predict")

_SCORE_GRID_SIZE: int = 6
_HT_SCORE_GRID_SIZE: int = 4
_HT_FT_LAMBDA_RATIO: float = 0.45
_MAX_SCORE_DISPLAY: int = 5

_PLAYABLE_STATUSES: frozenset = frozenset({
    "SCHEDULED",
    "TIMED",
    "NOT_STARTED",
    "NS",
    "UPCOMING",
    "TBD",
})

_REQUIRED_MATCH_COLUMNS: Tuple[str, ...] = (
    "home_raw",
    "away_raw",
    "home_key",
    "away_key",
)

_XG_SOURCE_TAG: str = "penaltyblog_model_estimate"

_TOP_EXACT_SCORES: int = 2

_THRESHOLD_DIRECT_WIN: float = 0.55
_THRESHOLD_DRAW: float = 0.35
_THRESHOLD_DC_1X_X2: float = 0.78
_THRESHOLD_DC_12: float = 0.85
_THRESHOLD_OVER15: float = 0.75
_THRESHOLD_UNDER15: float = 0.55
_THRESHOLD_OVER25: float = 0.62
_THRESHOLD_UNDER25: float = 0.55
_THRESHOLD_BTTS_YES: float = 0.62
_THRESHOLD_BTTS_NO: float = 0.55

_HT_THRESHOLD_DIRECT_WIN: float = 0.50
_HT_THRESHOLD_DRAW: float = 0.30
_HT_THRESHOLD_DC_1X_X2: float = 0.75
_HT_THRESHOLD_DC_12: float = 0.85
_HT_THRESHOLD_OVER05: float = 0.68
_HT_THRESHOLD_UNDER05: float = 0.40
_HT_THRESHOLD_OVER15: float = 0.38
_HT_THRESHOLD_UNDER15: float = 0.72
_HT_THRESHOLD_OVER25: float = 0.12
_HT_THRESHOLD_UNDER25: float = 0.85

_MARKET_BASELINES: Dict[str, float] = {
    "home_win": 0.42,
    "away_win": 0.32,
    "draw": 0.26,
    "dc_1x": 0.68,
    "dc_x2": 0.58,
    "dc_12": 0.74,
    "over_1_5": 0.72,
    "under_1_5": 0.28,
    "over_2_5": 0.50,
    "under_2_5": 0.50,
    "btts_yes": 0.52,
    "btts_no": 0.48,
    "ht_home_win": 0.32,
    "ht_away_win": 0.26,
    "ht_draw": 0.43,
    "ht_dc_1x": 0.75,
    "ht_dc_x2": 0.69,
    "ht_dc_12": 0.58,
    "ht_over_0_5": 0.70,
    "ht_under_0_5": 0.30,
    "ht_over_1_5": 0.30,
    "ht_under_1_5": 0.70,
    "ht_over_2_5": 0.08,
    "ht_under_2_5": 0.92,
}

_HT_EDGE_DISCOUNT: float = 0.35

_FT_EDGE_MIN: float = 0.05
_HT_EDGE_MIN: float = 0.08

_THRESHOLD_RELIABLE: float = 0.65

_MIN_ACTIVE_ML_MODELS: int = 3
_MIN_TOTAL_ACTIVE_MODELS: int = 4

_MAX_ACCEPTED_ENSEMBLE_STD: float = 0.14

_PROBA_SUM_TOLERANCE: float = 0.02
_MARKET_COHERENCE_BLEND: float = 0.5
_EPS: float = 1e-9
_EPS_WEIGHT: float = 1e-6

_DAYS_PER_SECOND: float = 86400.0
_MAX_REST_DAYS_VALIDITY: float = 365.0


def _cache_is_fresh(path: Path) -> bool:
    if CACHE_NEVER_EXPIRES:
        return path.exists()
    if not path.exists():
        return False
    try:
        mtime = dt.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    except OSError:
        return False
    age_hours = (dt.now(timezone.utc) - mtime).total_seconds() / 3600.0
    return age_hours < CACHE_TTL_HOURS


def _atomic_write_pickle(path: Path, obj: Any) -> None:
    if not CACHE_ATOMIC_WRITE:
        with open(path, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
        return
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        with open(tmp_path, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_path, path)
    except Exception as exc:
        logger.error("Échec écriture atomique %s : %s", path, exc)
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass
        raise


def _safe_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    try:
        if pd.isna(value):
            return default
    except (TypeError, ValueError):
        pass
    try:
        text = str(value).strip()
    except Exception:
        return default
    if not text or text.lower() in ("nan", "none", "null", "nat"):
        return default
    return text


def _safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    if isinstance(value, bool):
        return default
    try:
        if value is None:
            return default
        v = float(value)
    except (TypeError, ValueError):
        return default
    if not np.isfinite(v):
        return default
    return v


def _safe_int(value: Any, default: Optional[int] = None) -> Optional[int]:
    if isinstance(value, bool):
        return default
    try:
        if value is None:
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def _safe_probability(value: Any, fallback: float) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        v = float(fallback)
    if not np.isfinite(v):
        v = float(fallback)
    return float(np.clip(v, 0.0, 1.0))


def _safe_xg(value: Any, fallback: float) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        v = float(fallback)
    if not np.isfinite(v) or v <= 0.0:
        v = float(fallback)
    return float(np.clip(v, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))


def _safe_goals_mean(df: pd.DataFrame, column: str, fallback: float) -> float:
    if df is None or df.empty or column not in df.columns:
        return float(fallback)
    try:
        series = pd.to_numeric(df[column], errors="coerce").dropna()
    except Exception:
        return float(fallback)
    if series.empty:
        return float(fallback)
    m = float(series.mean())
    if not np.isfinite(m) or m <= 0.0:
        return float(fallback)
    return m


def _validate_hda(proba: Any) -> Optional[np.ndarray]:
    if proba is None:
        return None
    try:
        arr = np.asarray(proba, dtype=np.float64)
    except Exception:
        return None
    if arr.ndim == 2 and arr.shape[0] >= 1:
        arr = arr[0]
    if arr.ndim != 1 or arr.shape[0] != 3:
        return None
    if not np.all(np.isfinite(arr)):
        return None
    if np.any(arr < 0.0):
        return None
    if np.any(arr > 1.0 + 1e-6):
        return None
    total = float(arr.sum())
    if total <= 0.0:
        return None
    return arr / total


def _load_full_history() -> pd.DataFrame:
    stage_print("⚽ RÉCUPÉRATION DE L'HISTORIQUE COMPLET DES MATCHS")
    logger.info("Récupération de l'historique complet via Football-Data.org...")
    try:
        historical = get_historical_matches()
    except Exception as exc:
        logger.error("Erreur lors de la récupération historique : %s", exc)
        return pd.DataFrame()

    if not historical:
        logger.error("Aucun match historique récupéré depuis l'API")
        stage_print("🏆 TOTAL MATCHS HISTORIQUES RÉCUPÉRÉS : 0")
        return pd.DataFrame()

    df_hist = process_matches(
        historical,
        allowed_statuses=("FINISHED",),
        include_awarded=False,
    )
    if df_hist.empty:
        logger.error("Le traitement des matchs historiques a produit un DataFrame vide")
        stage_print("🏆 TOTAL MATCHS HISTORIQUES RÉCUPÉRÉS : 0")
        return df_hist

    df_past = df_hist.dropna(subset=["goals_home", "goals_away"]).copy()

    if "match_id" in df_past.columns:
        df_past = df_past.drop_duplicates(subset=["match_id"], keep="first")

    if "date_parsed" in df_past.columns:
        df_past = (
            df_past
            .dropna(subset=["date_parsed"])
            .sort_values("date_parsed", kind="mergesort")
            .reset_index(drop=True)
        )

    logger.info(
        "%d matchs terminés valides retenus sur %d matchs bruts",
        len(df_past), len(df_hist),
    )
    stage_print(f"🏆 TOTAL MATCHS HISTORIQUES RÉCUPÉRÉS : {len(df_past)}")
    return df_past


def _validate_cached_payload(
    df_past: Any,
    ml_models: Any,
    pb_models: Any,
    scaler: Any,
    weights: Any,
) -> bool:
    if not isinstance(df_past, pd.DataFrame) or df_past.empty:
        return False
    if "home_key" not in df_past.columns or "away_key" not in df_past.columns:
        return False
    if scaler is None or not hasattr(scaler, "n_features_in_"):
        return False
    try:
        if int(scaler.n_features_in_) != EXPECTED_FEATURE_COUNT:
            logger.warning(
                "Scaler obsolète : %d features (attendu %d)",
                int(scaler.n_features_in_),
                EXPECTED_FEATURE_COUNT,
            )
            return False
    except Exception:
        return False

    if ml_models is not None and not isinstance(ml_models, dict):
        return False
    if pb_models is not None and not isinstance(pb_models, list):
        return False
    if weights is not None and not isinstance(weights, dict):
        return False

    n_ml = len(ml_models) if isinstance(ml_models, dict) else 0
    n_pb = len(pb_models) if isinstance(pb_models, list) else 0
    if n_ml == 0 and n_pb == 0:
        logger.warning("Cache : aucun modèle utilisable (ml=%d, pb=%d)", n_ml, n_pb)
        return False

    if isinstance(weights, dict):
        cached_feature_count = weights.get("__feature_count__")
        if cached_feature_count is not None:
            try:
                if int(cached_feature_count) != EXPECTED_FEATURE_COUNT:
                    logger.warning(
                        "Nombre de features du cache (%s) != attendu (%d)",
                        cached_feature_count,
                        EXPECTED_FEATURE_COUNT,
                    )
                    return False
            except (TypeError, ValueError):
                return False

        cached_features = weights.get("__feature_names__")
        if isinstance(cached_features, list):
            try:
                if list(cached_features) != list(FEATURE_NAMES):
                    logger.warning(
                        "Liste de features du cache différente de la version courante"
                    )
                    return False
            except Exception:
                pass

        cached_schema = weights.get("__score_grid_size__")
        if cached_schema is not None:
            try:
                if int(cached_schema) != _SCORE_GRID_SIZE:
                    logger.warning(
                        "Score grid size du cache (%s) != courant (%d)",
                        cached_schema,
                        _SCORE_GRID_SIZE,
                    )
                    return False
            except (TypeError, ValueError):
                pass

    return True


def load_or_build_data_and_models(
    force_refresh: bool = False,
) -> Tuple[
    Optional[Dict[str, Any]],
    Optional[List[Tuple[str, Any]]],
    Any,
    pd.DataFrame,
    Dict[str, float],
]:
    cache_files = [HISTORICAL_FILE, MODELS_FILE, SCALER_FILE, WEIGHTS_FILE]
    files_present = all(f.exists() for f in cache_files)
    files_fresh = files_present and all(_cache_is_fresh(f) for f in cache_files)

    cache_available = not force_refresh and files_fresh

    if cache_available:
        try:
            with open(HISTORICAL_FILE, "rb") as f:
                df_past = pickle.load(f)
            with open(MODELS_FILE, "rb") as f:
                ml_models, pb_models = pickle.load(f)
            with open(SCALER_FILE, "rb") as f:
                scaler = pickle.load(f)
            with open(WEIGHTS_FILE, "rb") as f:
                weights = pickle.load(f)

            if _validate_cached_payload(df_past, ml_models, pb_models, scaler, weights):
                n_ml = len(ml_models) if isinstance(ml_models, dict) else 0
                n_pb = len(pb_models) if isinstance(pb_models, list) else 0
                logger.info(
                    "Cache chargé : %d matchs, %d ML, %d Penaltyblog",
                    len(df_past), n_ml, n_pb,
                )
                stage_print(
                    f"✅ Cache chargé : {len(df_past)} matchs, "
                    f"{n_ml} ML + {n_pb} Penaltyblog."
                )
                return ml_models, pb_models, scaler, df_past, weights

            logger.warning("Cache invalide ou incomplet. Reconstruction forcée.")
        except Exception as exc:
            logger.error(
                "Erreur de chargement du cache : %s. Reconstruction forcée.", exc
            )

    stage_print("⚙️ CONSTRUCTION INITIALE DES DONNÉES & MODÈLES")
    logger.info("Construction initiale des données et modèles...")
    df_past = _load_full_history()
    ml_models: Optional[Dict[str, Any]] = None
    pb_models: Optional[List[Tuple[str, Any]]] = None
    scaler: Any = None
    weights: Dict[str, float] = {}

    if not df_past.empty and len(df_past) >= MIN_MATCHES_FOR_TRAINING:
        try:
            ml_models, pb_models, scaler, weights = train_models(df_past)
        except Exception:
            logger.exception("Échec de l'entraînement")
            ml_models, pb_models, scaler, weights = None, None, None, {}
    else:
        logger.error(
            "Historique insuffisant pour l'entraînement : %d matchs", len(df_past)
        )
        stage_print("❌ Historique insuffisant pour entraîner les modèles")

    if isinstance(weights, dict):
        weights["__feature_count__"] = EXPECTED_FEATURE_COUNT
        weights["__feature_names__"] = list(FEATURE_NAMES)
        weights["__score_grid_size__"] = _SCORE_GRID_SIZE
        weights["__data_source__"] = "football-data.org"

    stage_print("🤖 FIN DE CHARGEMENT DES MODÈLES & DE L'ENTRAÎNEMENT")

    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _atomic_write_pickle(HISTORICAL_FILE, df_past)
        _atomic_write_pickle(MODELS_FILE, (ml_models, pb_models))
        _atomic_write_pickle(SCALER_FILE, scaler)
        _atomic_write_pickle(WEIGHTS_FILE, weights)
        logger.info("Cache sauvegardé.")
        stage_print(
            f"✅ MODÈLES ET DONNÉES SAUVEGARDÉS DANS ({CACHE_DIR}) "
            f"POUR ÉVITER LE RÉENTRAÎNEMENT COMPLET À CHAQUE LANCEMENT."
        )
    except OSError as exc:
        logger.error("Erreur lors de la sauvegarde du cache : %s", exc)
        stage_print("❌ Erreur lors de la sauvegarde du cache")

    return ml_models, pb_models, scaler, df_past, weights


def _dixon_coles_tau(i: int, j: int, lh: float, la: float, rho: float) -> float:
    if rho == 0.0:
        return 1.0
    if i == 0 and j == 0:
        tau = 1.0 - lh * la * rho
    elif i == 0 and j == 1:
        tau = 1.0 + lh * rho
    elif i == 1 and j == 0:
        tau = 1.0 + la * rho
    elif i == 1 and j == 1:
        tau = 1.0 - rho
    else:
        tau = 1.0
    if tau < 0.01:
        tau = 0.01
    return tau


def _poisson_matrix(
    lambda_home: float,
    lambda_away: float,
    rho: float = DIXON_COLES_RHO,
    grid_size: int = _SCORE_GRID_SIZE,
) -> np.ndarray:
    lambda_home = _safe_xg(lambda_home, DEFAULT_HOME_LAMBDA)
    lambda_away = _safe_xg(lambda_away, DEFAULT_AWAY_LAMBDA)
    grid = max(3, int(grid_size))
    mat = np.zeros((grid, grid), dtype=np.float64)
    for i in range(grid):
        pi = poisson.pmf(i, lambda_home)
        for j in range(grid):
            pj = poisson.pmf(j, lambda_away)
            tau = _dixon_coles_tau(i, j, lambda_home, lambda_away, rho)
            mat[i, j] = pi * pj * tau
    total = mat.sum()
    if total > 0:
        mat = mat / total
    else:
        mat[0, 0] = 1.0
    return mat


def _markets_from_matrix(mat: np.ndarray) -> Dict[str, Any]:
    n = mat.shape[0]
    prob_home = float(np.sum(np.tril(mat, k=-1)))
    prob_draw = float(np.trace(mat))
    prob_away = float(np.sum(np.triu(mat, k=1)))
    total = prob_home + prob_draw + prob_away
    if total > 0:
        prob_home /= total
        prob_draw /= total
        prob_away /= total
    over15 = float(sum(mat[i, j] for i in range(n) for j in range(n) if i + j > 1))
    over25 = float(sum(mat[i, j] for i in range(n) for j in range(n) if i + j > 2))
    btts_yes = float(
        sum(mat[i, j] for i in range(n) for j in range(n) if i > 0 and j > 0)
    )
    return {
        "home_draw_away": [prob_home, prob_draw, prob_away],
        "over15": float(np.clip(over15, 0.0, 1.0)),
        "over25": float(np.clip(over25, 0.0, 1.0)),
        "btts_yes": float(np.clip(btts_yes, 0.0, 1.0)),
    }


def _ht_poisson_matrix(
    lambda_home_ht: float,
    lambda_away_ht: float,
    grid_size: int = _HT_SCORE_GRID_SIZE,
) -> np.ndarray:
    lh = float(np.clip(lambda_home_ht, 0.02, 4.0))
    la = float(np.clip(lambda_away_ht, 0.02, 4.0))
    grid = max(3, int(grid_size))
    mat = np.zeros((grid, grid), dtype=np.float64)
    for i in range(grid):
        pi = poisson.pmf(i, lh)
        for j in range(grid):
            pj = poisson.pmf(j, la)
            mat[i, j] = pi * pj
    total = mat.sum()
    if total > 0:
        mat = mat / total
    else:
        mat[0, 0] = 1.0
    return mat


def _ht_markets_from_matrix(mat: np.ndarray) -> Dict[str, float]:
    n = mat.shape[0]
    prob_home = float(np.sum(np.tril(mat, k=-1)))
    prob_draw = float(np.trace(mat))
    prob_away = float(np.sum(np.triu(mat, k=1)))
    total = prob_home + prob_draw + prob_away
    if total > 0:
        prob_home /= total
        prob_draw /= total
        prob_away /= total
    over05 = 1.0 - float(mat[0, 0])
    over15 = float(sum(mat[i, j] for i in range(n) for j in range(n) if i + j > 1))
    over25 = float(sum(mat[i, j] for i in range(n) for j in range(n) if i + j > 2))
    return {
        "ht_home_draw_away": [prob_home, prob_draw, prob_away],
        "ht_over05": float(np.clip(over05, 0.0, 1.0)),
        "ht_over15": float(np.clip(over15, 0.0, 1.0)),
        "ht_over25": float(np.clip(over25, 0.0, 1.0)),
    }


def _compute_ht_markets(
    lambda_home: float,
    lambda_away: float,
) -> Dict[str, Any]:
    lh = _safe_xg(lambda_home, DEFAULT_HOME_LAMBDA)
    la = _safe_xg(lambda_away, DEFAULT_AWAY_LAMBDA)
    lh_ht = float(np.clip(lh * _HT_FT_LAMBDA_RATIO, 0.02, 4.0))
    la_ht = float(np.clip(la * _HT_FT_LAMBDA_RATIO, 0.02, 4.0))
    mat = _ht_poisson_matrix(lh_ht, la_ht)
    markets = _ht_markets_from_matrix(mat)
    markets["ht_home_xg"] = lh_ht
    markets["ht_away_xg"] = la_ht
    return markets


def _top_exact_scores(
    mat: np.ndarray,
    n: int = _TOP_EXACT_SCORES,
) -> List[str]:
    scores: List[Tuple[float, int, int]] = []
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            scores.append((float(mat[i, j]), i, j))
    scores.sort(reverse=True)
    top = scores[: max(1, n)]
    return [f"{i}-{j}" for _, i, j in top]


def _estimate_lambdas_from_history(
    home_key: str,
    away_key: str,
    tracker: TeamHistoryTracker,
    elo_system: EloSystem,
    competition_code: Optional[str],
    avg_h: float,
    avg_a: float,
) -> Tuple[float, float]:
    home_hist = tracker.snapshot(home_key, competition_code)
    away_hist = tracker.snapshot(away_key, competition_code)

    group = get_competition_group(competition_code)
    prior_home = float(
        REALISTIC_HOME_LAMBDA_BY_GROUP.get(
            group, avg_h if avg_h > 0 else DEFAULT_HOME_LAMBDA
        )
    )
    prior_away = float(
        REALISTIC_AWAY_LAMBDA_BY_GROUP.get(
            group, avg_a if avg_a > 0 else DEFAULT_AWAY_LAMBDA
        )
    )
    league_avg = max(0.5, (prior_home + prior_away) / 2.0)

    def _mean(values: List[float]) -> Optional[float]:
        if not values:
            return None
        arr = np.asarray(values, dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return None
        return float(arr.mean())

    home_gf = _mean(home_hist["gf"])
    home_ga = _mean(home_hist["ga"])
    away_gf = _mean(away_hist["gf"])
    away_ga = _mean(away_hist["ga"])

    home_home_gf = _mean(home_hist["home_gf"])
    home_home_ga = _mean(home_hist["home_ga"])
    away_away_gf = _mean(away_hist["away_gf"])
    away_away_ga = _mean(away_hist["away_ga"])

    home_attack_values: List[float] = []
    if home_gf is not None:
        home_attack_values.append(home_gf)
    if home_home_gf is not None:
        home_attack_values.append(home_home_gf)
    home_attack = (
        float(np.mean(home_attack_values)) if home_attack_values else league_avg
    )

    home_defense_values: List[float] = []
    if home_ga is not None:
        home_defense_values.append(home_ga)
    if home_home_ga is not None:
        home_defense_values.append(home_home_ga)
    home_defense = (
        float(np.mean(home_defense_values)) if home_defense_values else league_avg
    )

    away_attack_values: List[float] = []
    if away_gf is not None:
        away_attack_values.append(away_gf)
    if away_away_gf is not None:
        away_attack_values.append(away_away_gf)
    away_attack = (
        float(np.mean(away_attack_values)) if away_attack_values else league_avg
    )

    away_defense_values: List[float] = []
    if away_ga is not None:
        away_defense_values.append(away_ga)
    if away_away_ga is not None:
        away_defense_values.append(away_away_ga)
    away_defense = (
        float(np.mean(away_defense_values)) if away_defense_values else league_avg
    )

    home_attack_ratio = home_attack / league_avg if league_avg > 0 else 1.0
    home_defense_ratio = home_defense / league_avg if league_avg > 0 else 1.0
    away_attack_ratio = away_attack / league_avg if league_avg > 0 else 1.0
    away_defense_ratio = away_defense / league_avg if league_avg > 0 else 1.0

    home_attack_ratio = float(np.clip(home_attack_ratio, 0.3, 3.0))
    home_defense_ratio = float(np.clip(home_defense_ratio, 0.3, 3.0))
    away_attack_ratio = float(np.clip(away_attack_ratio, 0.3, 3.0))
    away_defense_ratio = float(np.clip(away_defense_ratio, 0.3, 3.0))

    base_home = prior_home * home_attack_ratio * away_defense_ratio
    base_away = prior_away * away_attack_ratio * home_defense_ratio
    base_home = 0.6 * base_home + 0.4 * prior_home
    base_away = 0.6 * base_away + 0.4 * prior_away

    home_elo = elo_system.get_rating(home_key, competition_code)
    away_elo = elo_system.get_rating(away_key, competition_code)
    elo_diff = home_elo - away_elo
    elo_scale = float(np.clip(elo_diff / 400.0, -1.5, 1.5))
    elo_factor_home = float(np.exp(0.20 * elo_scale))
    elo_factor_away = float(np.exp(-0.20 * elo_scale))

    lambda_home = base_home * elo_factor_home
    lambda_away = base_away * elo_factor_away

    matches_home = home_hist["matches_played"]
    matches_away = away_hist["matches_played"]
    reliability_home = float(np.clip(matches_home / 20.0, 0.0, 1.0))
    reliability_away = float(np.clip(matches_away / 20.0, 0.0, 1.0))

    lambda_home = (
        reliability_home * lambda_home + (1.0 - reliability_home) * prior_home
    )
    lambda_away = (
        reliability_away * lambda_away + (1.0 - reliability_away) * prior_away
    )

    lambda_home = _safe_xg(lambda_home, prior_home)
    lambda_away = _safe_xg(lambda_away, prior_away)
    return lambda_home, lambda_away


def _estimate_lambdas_from_feat(
    feat: np.ndarray,
    avg_h: float,
    avg_a: float,
) -> Tuple[float, float]:
    lambda_home = DEFAULT_HOME_LAMBDA if avg_h <= 0 else avg_h
    lambda_away = DEFAULT_AWAY_LAMBDA if avg_a <= 0 else avg_a

    try:
        arr = np.asarray(feat, dtype=np.float64)
    except Exception:
        arr = None

    if arr is not None and arr.size >= 4:
        flat = arr.ravel()
        try:
            home_gf_medium = float(flat[0])
            home_ga_medium = float(flat[1])
            away_gf_medium = float(flat[2])
            away_ga_medium = float(flat[3])
            if (
                np.isfinite(home_gf_medium)
                and np.isfinite(away_ga_medium)
                and home_gf_medium > 0
                and away_ga_medium > 0
            ):
                lambda_home = (home_gf_medium + away_ga_medium) / 2.0
            if (
                np.isfinite(away_gf_medium)
                and np.isfinite(home_ga_medium)
                and away_gf_medium > 0
                and home_ga_medium > 0
            ):
                lambda_away = (away_gf_medium + home_ga_medium) / 2.0
        except Exception:
            pass

    lambda_home = _safe_xg(lambda_home, DEFAULT_HOME_LAMBDA)
    lambda_away = _safe_xg(lambda_away, DEFAULT_AWAY_LAMBDA)
    return lambda_home, lambda_away


def _sanitize_weights(weights: List[float]) -> np.ndarray:
    if not weights:
        return np.array([], dtype=np.float64)
    arr = np.asarray(weights, dtype=np.float64)
    arr = np.where(np.isfinite(arr), arr, 0.0)
    arr = np.where(arr < 0.0, 0.0, arr)
    total = arr.sum()
    if total <= 0:
        return np.ones_like(arr) / float(arr.size)
    return arr / total


def _apply_temperature(proba: np.ndarray, temperature: float) -> np.ndarray:
    if temperature is None or temperature <= 0:
        return proba
    if abs(temperature - 1.0) < 1e-6:
        return proba
    clipped = np.clip(proba, _EPS, 1.0)
    logits = np.log(clipped) / float(temperature)
    logits -= logits.max()
    exp_logits = np.exp(logits)
    total = exp_logits.sum()
    if total <= 0:
        return proba
    return exp_logits / total


def _finalize_probabilities(proba: np.ndarray) -> np.ndarray:
    arr = np.array(proba, dtype=np.float64)
    if arr.shape != (3,) or not np.all(np.isfinite(arr)):
        return np.array([1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0])
    arr = np.clip(arr, 0.0, 1.0)
    total = arr.sum()
    if total <= 0:
        return np.array([1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0])
    return arr / total


def _model_predict_proba(
    model: Any,
    name: str,
    feat_scaled: np.ndarray,
) -> Optional[np.ndarray]:
    if model is None:
        return None

    predict_proba = getattr(model, "predict_proba", None)
    if callable(predict_proba):
        try:
            proba = predict_proba(feat_scaled)
            validated = _validate_hda(proba)
            if validated is not None:
                return validated
        except Exception as exc:
            logger.debug("predict_proba a échoué pour %s : %s", name, exc)

    if torch is not None and isinstance(model, torch.nn.Module):
        try:
            model.eval()
            with torch.no_grad():
                tensor = torch.as_tensor(feat_scaled, dtype=torch.float32)
                logits = model(tensor)
                proba = torch.softmax(logits, dim=-1).cpu().numpy()
                validated = _validate_hda(proba)
                if validated is not None:
                    return validated
        except Exception as exc:
            logger.debug("forward PyTorch a échoué pour %s : %s", name, exc)

    return None


def _resolve_pb_weight(
    weights: Dict[str, float],
    index: int,
    class_name: str,
    n_pb: int,
) -> float:
    if n_pb <= 0:
        return 0.0
    if not isinstance(weights, dict):
        return 1.0 / float(n_pb)
    for key in (f"pb_{index}", class_name):
        raw = weights.get(key)
        if raw is None:
            continue
        try:
            w = float(raw)
        except (TypeError, ValueError):
            continue
        if np.isfinite(w) and w >= 0.0:
            return w
    return 1.0 / float(n_pb)


def _build_fallback_output(
    avg_h: float,
    avg_a: float,
    feat: np.ndarray,
    lambda_home: Optional[float],
    lambda_away: Optional[float],
) -> Dict[str, Any]:
    if lambda_home is None or lambda_away is None:
        lambda_home, lambda_away = _estimate_lambdas_from_feat(feat, avg_h, avg_a)

    lambda_home = _safe_xg(lambda_home, DEFAULT_HOME_LAMBDA)
    lambda_away = _safe_xg(lambda_away, DEFAULT_AWAY_LAMBDA)

    mat = _poisson_matrix(lambda_home, lambda_away)
    markets = _markets_from_matrix(mat)

    base_proba = np.asarray(markets["home_draw_away"], dtype=np.float64)
    base_proba = _finalize_probabilities(base_proba)
    markets["home_draw_away"] = base_proba.tolist()

    markets["home_xg"] = float(lambda_home)
    markets["away_xg"] = float(lambda_away)
    markets["xg_source"] = _XG_SOURCE_TAG
    markets["xg_is_official"] = False
    markets["uncertainty"] = None
    markets["temperature"] = 1.0
    markets["fallback"] = True
    markets["score_matrix"] = mat
    markets["matrix_markets"] = markets["home_draw_away"]

    ht_markets = _compute_ht_markets(lambda_home, lambda_away)
    markets.update(ht_markets)

    return markets


def predict_match(
    home_key: str,
    away_key: str,
    home_raw: str,
    away_raw: str,
    competition_code: Optional[str],
    ml_models: Optional[Dict[str, Any]],
    pb_models: Optional[List[Tuple[str, Any]]],
    scaler: Any,
    df_past: pd.DataFrame,
    tracker: TeamHistoryTracker,
    elo_system: EloSystem,
    weights: Dict[str, float],
    match_date: Optional[pd.Timestamp] = None,
) -> Dict[str, Any]:
    if not isinstance(weights, dict):
        weights = {}

    if not isinstance(competition_code, str):
        competition_code = None
    elif competition_code:
        competition_code = competition_code.strip().upper()
    if not competition_code:
        competition_code = None

    avg_h = _safe_goals_mean(df_past, "goals_home", DEFAULT_HOME_LAMBDA)
    avg_a = _safe_goals_mean(df_past, "goals_away", DEFAULT_AWAY_LAMBDA)

    feat, _h2h_source = build_feature_vector(
        home_key,
        away_key,
        tracker,
        elo_system,
        match_date,
        competition_code,
    )

    feat_arr = np.asarray(feat, dtype=np.float64)
    if feat_arr.ndim == 0:
        feat_arr = feat_arr.reshape(1, -1)
    elif feat_arr.ndim == 1:
        feat_arr = feat_arr.reshape(1, -1)

    if feat_arr.ndim != 2 or feat_arr.shape[1] != EXPECTED_FEATURE_COUNT:
        logger.warning(
            "Feature shape inattendu : %s (attendu 1x%d). Fallback pour %s vs %s.",
            feat_arr.shape,
            EXPECTED_FEATURE_COUNT,
            home_raw,
            away_raw,
        )
        return _build_fallback_output(avg_h, avg_a, feat_arr, None, None)

    history_lambda_home, history_lambda_away = _estimate_lambdas_from_history(
        home_key,
        away_key,
        tracker,
        elo_system,
        competition_code,
        avg_h,
        avg_a,
    )

    if scaler is None or (not ml_models and not pb_models):
        return _build_fallback_output(
            avg_h,
            avg_a,
            feat_arr,
            history_lambda_home,
            history_lambda_away,
        )

    try:
        feat_scaled = scaler.transform(feat_arr)
    except Exception as exc:
        logger.error(
            "Erreur scaler pour %s vs %s : %s",
            home_raw,
            away_raw,
            exc,
        )
        return _build_fallback_output(
            avg_h,
            avg_a,
            feat_arr,
            history_lambda_home,
            history_lambda_away,
        )

    hda_probas: List[np.ndarray] = []
    hda_weights: List[float] = []

    over15_list: List[float] = []
    over15_weights: List[float] = []
    over25_list: List[float] = []
    over25_weights: List[float] = []
    btts_list: List[float] = []
    btts_weights: List[float] = []
    xg_home_list: List[float] = []
    xg_away_list: List[float] = []
    xg_weights: List[float] = []

    if pb_models:
        n_pb = len(pb_models)
        for i, (class_name, model) in enumerate(pb_models):
            try:
                grid = model.predict(home_key, away_key)
                markets = _extract_model_probabilities(grid)
                w = _resolve_pb_weight(weights, i, class_name, n_pb)

                hda = markets.get("home_draw_away")
                if hda is not None:
                    validated = _validate_hda(hda)
                    if validated is not None:
                        hda_probas.append(validated)
                        hda_weights.append(w)

                if "over15" in markets:
                    over15_list.append(_safe_probability(markets["over15"], 0.5))
                    over15_weights.append(w)
                if "over25" in markets:
                    over25_list.append(_safe_probability(markets["over25"], 0.5))
                    over25_weights.append(w)
                if "btts_yes" in markets:
                    btts_list.append(_safe_probability(markets["btts_yes"], 0.5))
                    btts_weights.append(w)

                expected_home = markets.get(
                    "expected_home_goals", markets.get("home_xg")
                )
                expected_away = markets.get(
                    "expected_away_goals", markets.get("away_xg")
                )
                if expected_home is not None and expected_away is not None:
                    xg_home_list.append(_safe_xg(expected_home, history_lambda_home))
                    xg_away_list.append(_safe_xg(expected_away, history_lambda_away))
                    xg_weights.append(w)
            except Exception as exc:
                logger.debug(
                    "PB[%d=%s] échec pour %s vs %s : %s",
                    i,
                    class_name,
                    home_raw,
                    away_raw,
                    exc,
                )

    if ml_models:
        for name, model in ml_models.items():
            proba = _model_predict_proba(model, name, feat_scaled)
            if proba is None:
                continue
            raw = weights.get(name, 0.0)
            try:
                w = float(raw)
            except (TypeError, ValueError):
                w = 0.0
            if not np.isfinite(w) or w < 0.0:
                w = 0.0
            hda_probas.append(proba)
            hda_weights.append(w)

    if not hda_probas:
        return _build_fallback_output(
            avg_h,
            avg_a,
            feat_arr,
            history_lambda_home,
            history_lambda_away,
        )

    probas_matrix = np.array(hda_probas, dtype=np.float64)
    uncertainty: Optional[List[float]] = None
    if probas_matrix.shape[0] > 1:
        uncertainty = probas_matrix.std(axis=0).tolist()

    if hda_weights and all(w == 0.0 for w in hda_weights):
        logger.warning(
            "Tous les poids des modèles sont nuls pour %s vs %s — répartition uniforme",
            home_raw,
            away_raw,
        )

    w_arr = _sanitize_weights(hda_weights)
    if w_arr.size == 0 or w_arr.size != probas_matrix.shape[0]:
        w_arr = np.ones(probas_matrix.shape[0]) / float(probas_matrix.shape[0])

    avg_hda = np.average(probas_matrix, axis=0, weights=w_arr)
    avg_hda = _finalize_probabilities(avg_hda)

    raw_temperature = weights.get("__temperature__", TEMPERATURE_SCALING_DEFAULT)
    try:
        temperature = float(raw_temperature)
    except (TypeError, ValueError):
        temperature = float(TEMPERATURE_SCALING_DEFAULT)
    if not np.isfinite(temperature):
        temperature = float(TEMPERATURE_SCALING_DEFAULT)

    if TEMPERATURE_SCALING_ENABLED:
        temperature = float(
            np.clip(temperature, TEMPERATURE_SCALING_MIN, TEMPERATURE_SCALING_MAX)
        )
    else:
        temperature = 1.0

    avg_hda = _apply_temperature(avg_hda, temperature)
    avg_hda = _finalize_probabilities(avg_hda)

    if xg_home_list and xg_away_list:
        xg_weight_arr = _sanitize_weights(xg_weights)
        if xg_weight_arr.size != len(xg_home_list):
            xg_weight_arr = np.ones(len(xg_home_list)) / float(len(xg_home_list))
        lambda_home = float(np.average(xg_home_list, weights=xg_weight_arr))
        lambda_away = float(np.average(xg_away_list, weights=xg_weight_arr))
        lambda_home = 0.5 * lambda_home + 0.5 * history_lambda_home
        lambda_away = 0.5 * lambda_away + 0.5 * history_lambda_away
    else:
        lambda_home = history_lambda_home
        lambda_away = history_lambda_away

    lambda_home = _safe_xg(lambda_home, history_lambda_home)
    lambda_away = _safe_xg(lambda_away, history_lambda_away)

    unified_matrix = _poisson_matrix(lambda_home, lambda_away)
    matrix_markets = _markets_from_matrix(unified_matrix)

    avg_over15 = matrix_markets["over15"]
    avg_over25 = matrix_markets["over25"]
    avg_btts = matrix_markets["btts_yes"]

    if over15_list:
        over15_weight_arr = _sanitize_weights(over15_weights)
        if over15_weight_arr.size != len(over15_list):
            over15_weight_arr = np.ones(len(over15_list)) / float(len(over15_list))
        pb_over15 = float(np.average(over15_list, weights=over15_weight_arr))
        avg_over15 = _safe_probability(
            _MARKET_COHERENCE_BLEND * pb_over15
            + (1.0 - _MARKET_COHERENCE_BLEND) * matrix_markets["over15"],
            matrix_markets["over15"],
        )

    if over25_list:
        over25_weight_arr = _sanitize_weights(over25_weights)
        if over25_weight_arr.size != len(over25_list):
            over25_weight_arr = np.ones(len(over25_list)) / float(len(over25_list))
        pb_over25 = float(np.average(over25_list, weights=over25_weight_arr))
        avg_over25 = _safe_probability(
            _MARKET_COHERENCE_BLEND * pb_over25
            + (1.0 - _MARKET_COHERENCE_BLEND) * matrix_markets["over25"],
            matrix_markets["over25"],
        )

    if btts_list:
        btts_weight_arr = _sanitize_weights(btts_weights)
        if btts_weight_arr.size != len(btts_list):
            btts_weight_arr = np.ones(len(btts_list)) / float(len(btts_list))
        pb_btts = float(np.average(btts_list, weights=btts_weight_arr))
        avg_btts = _safe_probability(
            _MARKET_COHERENCE_BLEND * pb_btts
            + (1.0 - _MARKET_COHERENCE_BLEND) * matrix_markets["btts_yes"],
            matrix_markets["btts_yes"],
        )

    if avg_over25 > avg_over15:
        avg_over25 = avg_over15

    hda_from_matrix = np.asarray(matrix_markets["home_draw_away"], dtype=np.float64)
    avg_hda = _finalize_probabilities(avg_hda)

    markets: Dict[str, Any] = {
        "home_draw_away": avg_hda.tolist(),
        "matrix_home_draw_away": hda_from_matrix.tolist(),
        "over15": float(np.clip(avg_over15, 0.0, 1.0)),
        "over25": float(np.clip(avg_over25, 0.0, 1.0)),
        "btts_yes": float(np.clip(avg_btts, 0.0, 1.0)),
        "home_xg": lambda_home,
        "away_xg": lambda_away,
        "xg_source": _XG_SOURCE_TAG,
        "xg_is_official": False,
        "uncertainty": uncertainty,
        "temperature": temperature,
        "fallback": False,
        "score_matrix": unified_matrix,
        "matrix_markets": matrix_markets,
    }

    ht_markets = _compute_ht_markets(lambda_home, lambda_away)
    markets.update(ht_markets)

    return markets


def _build_ft_candidates(
    proba: List[float],
    home_name: str,
    away_name: str,
    over15: float,
    over25: float,
    btts_yes: float,
    use_thresholds: bool,
) -> List[Tuple[float, str, str, bool]]:
    try:
        p_home = float(proba[0])
        p_draw = float(proba[1])
        p_away = float(proba[2])
    except Exception:
        return []

    if not (np.isfinite(p_home) and np.isfinite(p_draw) and np.isfinite(p_away)):
        return []

    p_home = float(np.clip(p_home, 0.0, 1.0))
    p_draw = float(np.clip(p_draw, 0.0, 1.0))
    p_away = float(np.clip(p_away, 0.0, 1.0))

    total_hda = p_home + p_draw + p_away
    if total_hda <= 0:
        return []
    if abs(total_hda - 1.0) > _PROBA_SUM_TOLERANCE:
        p_home /= total_hda
        p_draw /= total_hda
        p_away /= total_hda

    over15 = _safe_probability(over15, 0.5)
    over25 = _safe_probability(over25, 0.5)
    btts_yes = _safe_probability(btts_yes, 0.5)

    candidates: List[Tuple[float, str, str, bool]] = []

    def _push(prob: float, name: str, market_key: str, threshold: float) -> None:
        if use_thresholds:
            if prob >= threshold:
                candidates.append((float(prob), name, market_key, False))
        else:
            candidates.append((float(prob), name, market_key, False))

    _push(p_home, f"Victoire {home_name}", "home_win", _THRESHOLD_DIRECT_WIN)
    _push(p_away, f"Victoire {away_name}", "away_win", _THRESHOLD_DIRECT_WIN)
    _push(p_draw, "Match Nul", "draw", _THRESHOLD_DRAW)

    dc_1x = p_home + p_draw
    dc_x2 = p_away + p_draw
    dc_12 = p_home + p_away

    _push(dc_1x, f"Double chance 1X ({home_name} ou Nul)", "dc_1x", _THRESHOLD_DC_1X_X2)
    _push(dc_x2, f"Double chance X2 (Nul ou {away_name})", "dc_x2", _THRESHOLD_DC_1X_X2)
    _push(dc_12, "Double chance 12 (pas de nul)", "dc_12", _THRESHOLD_DC_12)

    _push(over15, "+1.5 buts", "over_1_5", _THRESHOLD_OVER15)
    _push(1.0 - over15, "-1.5 buts", "under_1_5", _THRESHOLD_UNDER15)
    _push(over25, "+2.5 buts", "over_2_5", _THRESHOLD_OVER25)
    _push(1.0 - over25, "-2.5 buts", "under_2_5", _THRESHOLD_UNDER25)

    _push(btts_yes, "BTTS — Les deux marquent (Oui)", "btts_yes", _THRESHOLD_BTTS_YES)
    _push(1.0 - btts_yes, "BTTS — Les deux marquent (Non)", "btts_no", _THRESHOLD_BTTS_NO)

    return candidates


def _build_ht_candidates(
    ht_markets: Dict[str, Any],
    home_name: str,
    away_name: str,
    use_thresholds: bool,
) -> List[Tuple[float, str, str, bool]]:
    if not ht_markets:
        return []

    hda = ht_markets.get("ht_home_draw_away")
    if hda is None:
        return []

    try:
        p_home = float(hda[0])
        p_draw = float(hda[1])
        p_away = float(hda[2])
    except Exception:
        return []

    if not (np.isfinite(p_home) and np.isfinite(p_draw) and np.isfinite(p_away)):
        return []

    total = p_home + p_draw + p_away
    if total <= 0:
        return []
    if abs(total - 1.0) > _PROBA_SUM_TOLERANCE:
        p_home /= total
        p_draw /= total
        p_away /= total

    over05 = _safe_probability(ht_markets.get("ht_over05", 0.5), 0.5)
    over15 = _safe_probability(ht_markets.get("ht_over15", 0.5), 0.5)
    over25 = _safe_probability(ht_markets.get("ht_over25", 0.5), 0.5)

    candidates: List[Tuple[float, str, str, bool]] = []

    def _push(prob: float, name: str, market_key: str, threshold: float) -> None:
        if use_thresholds:
            if prob >= threshold:
                candidates.append((float(prob), name, market_key, True))
        else:
            candidates.append((float(prob), name, market_key, True))

    _push(p_home, f"Victoire {home_name} (1ère MT)", "ht_home_win", _HT_THRESHOLD_DIRECT_WIN)
    _push(p_away, f"Victoire {away_name} (1ère MT)", "ht_away_win", _HT_THRESHOLD_DIRECT_WIN)
    _push(p_draw, "Match Nul (1ère MT)", "ht_draw", _HT_THRESHOLD_DRAW)

    dc_1x = p_home + p_draw
    dc_x2 = p_away + p_draw
    dc_12 = p_home + p_away

    _push(dc_1x, f"Double chance 1X ({home_name} ou Nul) (1ère MT)", "ht_dc_1x", _HT_THRESHOLD_DC_1X_X2)
    _push(dc_x2, f"Double chance X2 (Nul ou {away_name}) (1ère MT)", "ht_dc_x2", _HT_THRESHOLD_DC_1X_X2)
    _push(dc_12, "Double chance 12 (pas de nul) (1ère MT)", "ht_dc_12", _HT_THRESHOLD_DC_12)

    _push(over05, "+0.5 buts (1ère MT)", "ht_over_0_5", _HT_THRESHOLD_OVER05)
    _push(1.0 - over05, "-0.5 buts (1ère MT)", "ht_under_0_5", _HT_THRESHOLD_UNDER05)
    _push(over15, "+1.5 buts (1ère MT)", "ht_over_1_5", _HT_THRESHOLD_OVER15)
    _push(1.0 - over15, "-1.5 buts (1ère MT)", "ht_under_1_5", _HT_THRESHOLD_UNDER15)
    _push(over25, "+2.5 buts (1ère MT)", "ht_over_2_5", _HT_THRESHOLD_OVER25)
    _push(1.0 - over25, "-2.5 buts (1ère MT)", "ht_under_2_5", _HT_THRESHOLD_UNDER25)

    return candidates


def _market_edge(prob: float, market_key: str, is_ht: bool = False) -> float:
    baseline = _MARKET_BASELINES.get(market_key, 0.5)
    raw_edge = float(prob) - float(baseline)
    if is_ht:
        raw_edge *= float(_HT_EDGE_DISCOUNT)
    return float(raw_edge)


def _ensemble_is_reliable(markets: Dict[str, Any]) -> bool:
    if markets.get("fallback"):
        return False

    uncertainty = markets.get("uncertainty")
    if uncertainty is not None and len(uncertainty) == 3:
        max_std = float(max(uncertainty))
        if max_std > _MAX_ACCEPTED_ENSEMBLE_STD:
            return False

    return True


def _pick_recommended_bet(
    proba: List[float],
    home_name: str,
    away_name: str,
    over15: float,
    over25: float,
    btts_yes: float,
    ht_markets: Optional[Dict[str, Any]] = None,
    markets_context: Optional[Dict[str, Any]] = None,
) -> Optional[Tuple[str, float, bool]]:
    if markets_context is not None:
        if not _ensemble_is_reliable(markets_context):
            return None

    ft_strict = _build_ft_candidates(
        proba, home_name, away_name, over15, over25, btts_yes, use_thresholds=True
    )
    ft_eligible = [
        c for c in ft_strict
        if _market_edge(c[0], c[2], False) >= _FT_EDGE_MIN
    ]
    if ft_eligible:
        ft_eligible.sort(key=lambda c: _market_edge(c[0], c[2], False), reverse=True)
        prob, name, _key, is_ht = ft_eligible[0]
        return (str(name), float(prob), bool(is_ht))

    ht_strict = _build_ht_candidates(
        ht_markets or {}, home_name, away_name, use_thresholds=True
    )
    ht_eligible = [
        c for c in ht_strict
        if _market_edge(c[0], c[2], True) >= _HT_EDGE_MIN
    ]
    if ht_eligible:
        ht_eligible.sort(key=lambda c: _market_edge(c[0], c[2], True), reverse=True)
        prob, name, _key, is_ht = ht_eligible[0]
        return (str(name), float(prob), bool(is_ht))

    return None


def _reliability_indicator(reference_prob: Any, is_ht: bool = False) -> str:
    if is_ht:
        return "⚠️ Pari peu fiable"
    try:
        value = float(reference_prob)
    except (TypeError, ValueError):
        return "⚠️ Pari peu fiable"
    if not np.isfinite(value):
        return "⚠️ Pari peu fiable"
    if value >= _THRESHOLD_RELIABLE:
        return "✅ Pari fiable"
    return "⚠️ Pari peu fiable"


def _markets_are_valid(markets: Dict[str, Any]) -> bool:
    try:
        proba = markets.get("home_draw_away")
        if not isinstance(proba, list) or len(proba) != 3:
            return False
        values = [float(x) for x in proba]
        if not all(np.isfinite(v) for v in values):
            return False
        if any(v < 0.0 or v > 1.0 for v in values):
            return False
        total = sum(values)
        if not np.isfinite(total) or total <= 0:
            return False
        if abs(total - 1.0) > _PROBA_SUM_TOLERANCE:
            return False

        for key in ("over15", "over25", "btts_yes"):
            v = markets.get(key)
            if v is None:
                return False
            fv = float(v)
            if not np.isfinite(fv) or fv < 0.0 or fv > 1.0:
                return False

        for key in ("home_xg", "away_xg"):
            v = markets.get(key)
            if v is None:
                return False
            fv = float(v)
            if not np.isfinite(fv) or fv <= 0.0:
                return False
        return True
    except Exception:
        return False


def _count_active_models(
    ml_models: Optional[Dict[str, Any]],
    pb_models: Optional[List[Tuple[str, Any]]],
) -> Tuple[int, int]:
    n_ml = len(ml_models) if isinstance(ml_models, dict) else 0
    n_pb = len(pb_models) if isinstance(pb_models, list) else 0
    return n_ml, n_pb


def _print_match_prediction(
    row: pd.Series,
    markets: Dict[str, Any],
    ml_models: Optional[Dict[str, Any]] = None,
    pb_models: Optional[List[Tuple[str, Any]]] = None,
) -> None:
    home_display = _safe_str(row.get("home_raw", ""), default="Home")
    away_display = _safe_str(row.get("away_raw", ""), default="Away")

    if not _markets_are_valid(markets):
        print(f"\n{home_display} vs {away_display}")
        print(" 🚨 Conseiller : Aucun pari conseillé")
        print(" ⚠️ Pari peu fiable")
        return

    proba = markets["home_draw_away"]
    lambda_home = float(markets["home_xg"])
    lambda_away = float(markets["away_xg"])
    over15 = float(markets["over15"])
    over25 = float(markets["over25"])
    btts_yes = float(markets["btts_yes"])

    score_matrix = markets.get("score_matrix")
    if not isinstance(score_matrix, np.ndarray):
        score_matrix = _poisson_matrix(lambda_home, lambda_away)

    top_scores = _top_exact_scores(score_matrix, n=_TOP_EXACT_SCORES)
    scores_str = " | ".join(top_scores)

    print(f"\n{home_display} vs {away_display}")
    print(f" 🤔 XG : {lambda_home:.2f} - {lambda_away:.2f}")
    print(f" 🎯 Scores probables : {scores_str}")
    print(f" ⚽ {home_display} : {proba[0] * 100:.1f}%")
    print(f" 🤝 Nul : {proba[1] * 100:.1f}%")
    print(f" ⚽ {away_display} : {proba[2] * 100:.1f}%")
    print(f" 🏆 +1.5 buts : {over15 * 100:.1f}%")
    print(f" 🏆 -1.5 buts : {(1.0 - over15) * 100:.1f}%")
    print(f" 🏆 +2.5 buts : {over25 * 100:.1f}%")
    print(f" 🏆 -2.5 buts : {(1.0 - over25) * 100:.1f}%")
    print(f" 🎯 BTTS (Oui) : {btts_yes * 100:.1f}%")
    print(f" 🎯 BTTS (Non) : {(1.0 - btts_yes) * 100:.1f}%")

    ht_markets = {
        "ht_home_draw_away": markets.get("ht_home_draw_away"),
        "ht_over05": markets.get("ht_over05"),
        "ht_over15": markets.get("ht_over15"),
        "ht_over25": markets.get("ht_over25"),
    }

    n_ml, n_pb = _count_active_models(ml_models, pb_models)

    if n_ml < _MIN_ACTIVE_ML_MODELS or (n_ml + n_pb) < _MIN_TOTAL_ACTIVE_MODELS:
        print(" 🚨 Conseiller : Aucun pari conseillé")
        print(" ⚠️ Pari peu fiable")
        print(
            f" ℹ️  Modèles actifs insuffisants ({n_ml} ML + {n_pb} PB) — "
            f"minimum requis : {_MIN_ACTIVE_ML_MODELS} ML + "
            f"{_MIN_TOTAL_ACTIVE_MODELS} total"
        )
        return

    if markets.get("fallback"):
        print(" 🚨 Conseiller : Aucun pari conseillé")
        print(" ⚠️ Pari peu fiable")
        print(" ℹ️  Prédiction en mode dégradé — aucune recommandation émise")
        return

    uncertainty = markets.get("uncertainty")
    if uncertainty is not None and len(uncertainty) == 3:
        max_std = float(max(uncertainty))
        if max_std > _MAX_ACCEPTED_ENSEMBLE_STD:
            print(" 🚨 Conseiller : Aucun pari conseillé")
            print(" ⚠️ Pari peu fiable")
            print(
                f" ℹ️  Fort désaccord entre modèles "
                f"(écart-type max {max_std:.3f} > {_MAX_ACCEPTED_ENSEMBLE_STD:.3f})"
            )
            return

    bet_result = _pick_recommended_bet(
        proba,
        home_display,
        away_display,
        over15,
        over25,
        btts_yes,
        ht_markets,
        markets,
    )

    if bet_result is None:
        print(" 🚨 Conseiller : Aucun pari conseillé")
        print(" ⚠️ Pari peu fiable")
        print(" ℹ️  Aucun marché ne dépasse les seuils stricts de fiabilité et de valeur")
        return

    bet_name, bet_prob, bet_is_ht = bet_result
    reliability = _reliability_indicator(bet_prob, bet_is_ht)
    print(f" 🚨 Conseiller : {bet_name}")
    print(f" {reliability}")


def _check_required_columns(df: pd.DataFrame) -> bool:
    missing = [c for c in _REQUIRED_MATCH_COLUMNS if c not in df.columns]
    if missing:
        logger.error(
            "Colonnes obligatoires manquantes après process_matches() : %s",
            missing,
        )
        return False
    return True


def predict_for_date(
    date_str: str,
    ml_models: Optional[Dict[str, Any]],
    pb_models: Optional[List[Tuple[str, Any]]],
    scaler: Any,
    df_past: pd.DataFrame,
    weights: Dict[str, float],
) -> None:
    if not isinstance(weights, dict):
        weights = {}

    try:
        matches, source = get_all_matches_for_date(date_str)
    except Exception as exc:
        logger.error(
            "Erreur lors de la récupération des matchs du %s : %s", date_str, exc
        )
        print("\033[1;31mErreur lors de la récupération des matchs.\033[0m")
        return

    if not matches:
        print("❌ Aucun match trouvé.")
        return

    df_today = process_matches(
        matches,
        allowed_statuses=None,
        include_awarded=False,
    )

    if df_today.empty:
        print("❌ Aucun match exploitable trouvé.")
        return

    if not _check_required_columns(df_today):
        print("❌ Colonnes obligatoires manquantes dans la réponse API.")
        return

    if "status" not in df_today.columns:
        logger.warning(
            "Colonne 'status' absente — statut forcé à UNKNOWN (matchs exclus)."
        )
        df_today["status"] = "UNKNOWN"

    df_today["status"] = (
        df_today["status"].astype(str).str.strip().str.upper()
    )

    df_future = df_today[
        df_today["status"].isin(_PLAYABLE_STATUSES)
        & df_today["home_raw"].notna()
        & df_today["away_raw"].notna()
    ].copy()

    if df_future.empty:
        print("Aucun match à venir.")
        return

    df_future = df_future[
        df_future["home_key"].notna()
        & df_future["away_key"].notna()
        & (df_future["home_key"].astype(str).str.strip() != "")
        & (df_future["away_key"].astype(str).str.strip() != "")
    ].copy()

    if df_future.empty:
        print("Aucun match à venir.")
        return

    print(f"✅ {len(df_future)} matchs à venir (source: {source})")

    avg_h = _safe_goals_mean(df_past, "goals_home", DEFAULT_HOME_LAMBDA)
    avg_a = _safe_goals_mean(df_past, "goals_away", DEFAULT_AWAY_LAMBDA)

    if df_past is None or df_past.empty or len(df_past) < MIN_MATCHES_FOR_TRAINING:
        logger.warning("Historique insuffisant, estimation dégradée.")
        tracker_empty = TeamHistoryTracker(default_gf=avg_h, default_ga=avg_a)
        elo_empty = EloSystem()
        if df_past is not None and not df_past.empty:
            try:
                tracker_empty, elo_empty = build_tracking_state(df_past)
            except Exception as exc:
                logger.error("Erreur build_tracking_state dégradé : %s", exc)

        print("\n🔮 PRÉDICTIONS (mode dégradé) :")
        for _, row in df_future.iterrows():
            home_key = _safe_str(row.get("home_key", ""))
            away_key = _safe_str(row.get("away_key", ""))
            if not home_key or not away_key:
                continue

            comp_code = _safe_str(row.get("competition_code", ""), default="").upper()
            if not comp_code:
                comp_code = None

            try:
                feat, _ = build_feature_vector(
                    home_key,
                    away_key,
                    tracker_empty,
                    elo_empty,
                    row.get("date_parsed"),
                    comp_code,
                )
                feat_arr = np.asarray(feat, dtype=np.float64)
                if feat_arr.ndim == 0:
                    feat_arr = feat_arr.reshape(1, -1)
                elif feat_arr.ndim == 1:
                    feat_arr = feat_arr.reshape(1, -1)

                lambda_home, lambda_away = _estimate_lambdas_from_history(
                    home_key,
                    away_key,
                    tracker_empty,
                    elo_empty,
                    comp_code,
                    avg_h,
                    avg_a,
                )
                markets = _build_fallback_output(
                    avg_h,
                    avg_a,
                    feat_arr,
                    lambda_home,
                    lambda_away,
                )
            except Exception as exc:
                logger.error(
                    "Erreur fallback pour %s vs %s : %s",
                    home_key,
                    away_key,
                    exc,
                )
                continue
            _print_match_prediction(row, markets, ml_models, pb_models)
        return

    try:
        tracker, elo_system = build_tracking_state(df_past)
    except Exception as exc:
        logger.error("Erreur build_tracking_state : %s", exc)
        print("\033[1;31mErreur de construction de l'état de suivi.\033[0m")
        return

    print("\n🔮 PRÉDICTIONS :")
    for _, row in df_future.iterrows():
        home_display = _safe_str(row.get("home_raw", ""), default="Home")
        away_display = _safe_str(row.get("away_raw", ""), default="Away")
        home_key = _safe_str(row.get("home_key", ""))
        away_key = _safe_str(row.get("away_key", ""))

        if not home_key or not away_key:
            continue

        comp = _safe_str(row.get("competition", ""))
        comp_code = _safe_str(row.get("competition_code", ""), default="").upper()
        if not comp_code:
            comp_code = None

        match_date = row.get("date_parsed")

        try:
            markets = predict_match(
                home_key,
                away_key,
                home_display,
                away_display,
                comp_code,
                ml_models,
                pb_models,
                scaler,
                df_past,
                tracker,
                elo_system,
                weights,
                match_date,
            )
        except Exception:
            logger.exception(
                "Erreur de prédiction pour %s vs %s",
                home_display,
                away_display,
            )
            print(f"\n{home_display} vs {away_display} ({comp})")
            print(" \033[1;31mErreur lors du calcul de la prédiction.\033[0m")
            continue

        _print_match_prediction(row, markets, ml_models, pb_models)

import time
import logging
import threading
from datetime import date, datetime, timedelta, timezone
from itertools import cycle
from typing import Any, Dict, List, Optional, Tuple

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import (
    tokens,
    COMPETITIONS,
    API_BASE_URL,
    API_TIMEOUT_SECONDS,
    API_MAX_RETRIES,
    API_RETRY_BACKOFF_SECONDS,
    API_RATE_LIMIT_SLEEP_SECONDS,
    API_COMPETITION_SLEEP_SECONDS,
    HISTORICAL_SEASONS_LOOKBACK,
)

logger = logging.getLogger("goangel.api")


class FootballDataAPIError(Exception):
    pass


class TokenManager:
    def __init__(self, token_list: List[str]):
        if not token_list:
            raise FootballDataAPIError("Aucun token disponible pour TokenManager")
        self._lock = threading.Lock()
        self.tokens = list(token_list)
        self._pool = cycle(self.tokens)
        self._current = next(self._pool)
        self._cooldowns: Dict[str, float] = {t: 0.0 for t in self.tokens}

    def get_next(self) -> str:
        with self._lock:
            attempts = 0
            now = time.monotonic()
            token = next(self._pool)
            while self._cooldowns.get(token, 0.0) > now and attempts < len(self.tokens):
                token = next(self._pool)
                attempts += 1
            self._current = token
            return self._current

    def mark_rate_limited(self, token: str, retry_after_seconds: float) -> None:
        with self._lock:
            self._cooldowns[token] = time.monotonic() + max(retry_after_seconds, 1.0)

    def get_headers(self) -> Dict[str, str]:
        return {"X-Auth-Token": self.get_next()}

    def current_token(self) -> str:
        with self._lock:
            return self._current


token_manager = TokenManager(tokens)

_session = requests.Session()
_adapter = HTTPAdapter(
    pool_connections=10,
    pool_maxsize=10,
    max_retries=Retry(total=0, connect=0, read=0, redirect=2, status=0),
)
_session.mount("https://", _adapter)
_session.mount("http://", _adapter)


def _parse_retry_after(resp: requests.Response, default_seconds: float) -> float:
    header_value = (
        resp.headers.get("Retry-After")
        or resp.headers.get("X-RequestCounter-Reset")
    )
    if header_value is None:
        return default_seconds
    try:
        return max(float(header_value), 0.0)
    except (TypeError, ValueError):
        return default_seconds


def make_request(
    url: str,
    params: Optional[Dict[str, Any]] = None,
    retries: int = API_MAX_RETRIES,
) -> Optional[Dict[str, Any]]:
    if retries < 1:
        retries = 1

    last_error: Optional[str] = None

    for attempt in range(retries):
        current_token = token_manager.get_next()
        headers = {"X-Auth-Token": current_token}

        try:
            resp = _session.get(
                url,
                headers=headers,
                params=params,
                timeout=API_TIMEOUT_SECONDS,
            )
        except requests.exceptions.Timeout as exc:
            last_error = f"Timeout: {exc}"
            logger.warning(
                "Timeout sur %s (tentative %d/%d)", url, attempt + 1, retries
            )
            if attempt < retries - 1:
                time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
                continue
            break
        except requests.exceptions.ConnectionError as exc:
            last_error = f"ConnectionError: {exc}"
            logger.warning(
                "Erreur de connexion sur %s (tentative %d/%d)",
                url,
                attempt + 1,
                retries,
            )
            if attempt < retries - 1:
                time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
                continue
            break
        except requests.exceptions.RequestException as exc:
            last_error = f"RequestException: {exc}"
            logger.error("Erreur requête sur %s : %s", url, exc)
            if attempt < retries - 1:
                time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
                continue
            break

        if resp.status_code == 200:
            try:
                return resp.json()
            except ValueError as exc:
                last_error = f"JSONDecodeError: {exc}"
                logger.error("Réponse JSON invalide depuis %s : %s", url, exc)
                if attempt < retries - 1:
                    time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
                    continue
                break

        if resp.status_code == 429:
            retry_after = _parse_retry_after(resp, API_RATE_LIMIT_SLEEP_SECONDS)
            token_manager.mark_rate_limited(current_token, retry_after)
            logger.warning(
                "Rate limit atteint sur %s, attente %.1fs (tentative %d/%d)",
                url,
                retry_after,
                attempt + 1,
                retries,
            )
            time.sleep(retry_after)
            continue

        if resp.status_code in (401, 403):
            last_error = f"Auth error {resp.status_code}: {resp.text[:200]}"
            logger.error(
                "Erreur d'authentification (%d) sur %s avec token %s***",
                resp.status_code,
                url,
                current_token[:6],
            )
            if attempt < retries - 1:
                time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
                continue
            break

        if resp.status_code == 404:
            logger.info("Ressource introuvable (404) : %s", url)
            return None

        if 500 <= resp.status_code < 600:
            last_error = f"ServerError {resp.status_code}: {resp.text[:200]}"
            logger.warning(
                "Erreur serveur %d sur %s (tentative %d/%d)",
                resp.status_code,
                url,
                attempt + 1,
                retries,
            )
            if attempt < retries - 1:
                time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
                continue
            break

        last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
        logger.error(
            "Réponse inattendue %d sur %s : %s",
            resp.status_code,
            url,
            resp.text[:200],
        )
        if attempt < retries - 1:
            time.sleep(API_RETRY_BACKOFF_SECONDS * (attempt + 1))
            continue
        break

    logger.error(
        "Échec définitif de la requête vers %s après %d tentatives : %s",
        url,
        retries,
        last_error,
    )
    return None


def _validate_date_str(date_str: str) -> bool:
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except (TypeError, ValueError):
        return False


def get_matches_global(date_str: str) -> List[Dict[str, Any]]:
    if not _validate_date_str(date_str):
        raise FootballDataAPIError(f"Format de date invalide : {date_str}")
    url = f"{API_BASE_URL}/matches"
    data = make_request(url, params={"date": date_str})
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_matches_by_competition(
    code: str,
    date_from: str,
    date_to: Optional[str] = None,
) -> List[Dict[str, Any]]:
    if not _validate_date_str(date_from):
        raise FootballDataAPIError(f"Format de date_from invalide : {date_from}")
    if date_to is None:
        date_to = date_from
    if not _validate_date_str(date_to):
        raise FootballDataAPIError(f"Format de date_to invalide : {date_to}")
    url = f"{API_BASE_URL}/competitions/{code}/matches"
    params = {"dateFrom": date_from, "dateTo": date_to}
    data = make_request(url, params=params)
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_all_matches_for_date(date_str: str) -> Tuple[List[Dict[str, Any]], str]:
    matches = get_matches_global(date_str)
    if matches:
        target_codes = set(COMPETITIONS)
        filtered = [
            m
            for m in matches
            if m.get("competition", {}).get("code") in target_codes
        ]
        if filtered:
            return filtered, "global"
        return matches, "global"

    all_matches: List[Dict[str, Any]] = []
    seen_ids = set()

    for code in COMPETITIONS:
        try:
            fetched = get_matches_by_competition(code, date_str)
        except FootballDataAPIError as exc:
            logger.error(
                "Erreur lors de la récupération de la compétition %s : %s",
                code,
                exc,
            )
            fetched = []

        for m in fetched:
            match_id = m.get("id")
            if match_id is not None and match_id in seen_ids:
                continue
            if match_id is not None:
                seen_ids.add(match_id)
            all_matches.append(m)

        time.sleep(API_COMPETITION_SLEEP_SECONDS)

    return all_matches, "competitions"


def _season_date_ranges(seasons_lookback: int) -> List[Tuple[str, str]]:
    today = datetime.now(timezone.utc).date()
    ranges: List[Tuple[str, str]] = []
    for offset in range(seasons_lookback):
        end_year = today.year - offset
        start_date = date(end_year - 1, 7, 1)
        end_date = date(end_year, 6, 30)
        if end_date > today:
            end_date = today
        if start_date > today:
            continue
        ranges.append((start_date.isoformat(), end_date.isoformat()))
    return ranges


def get_historical_matches(
    seasons_lookback: int = HISTORICAL_SEASONS_LOOKBACK,
) -> List[Dict[str, Any]]:
    all_matches: List[Dict[str, Any]] = []
    seen_ids = set()
    date_ranges = _season_date_ranges(seasons_lookback)

    for code in COMPETITIONS:
        competition_matches_count = 0

        for date_from, date_to in date_ranges:
            current_from = datetime.strptime(date_from, "%Y-%m-%d").date()
            final_to = datetime.strptime(date_to, "%Y-%m-%d").date()

            while current_from <= final_to:
                chunk_to = min(current_from + timedelta(days=364), final_to)
                url = f"{API_BASE_URL}/competitions/{code}/matches"
                params = {
                    "dateFrom": current_from.isoformat(),
                    "dateTo": chunk_to.isoformat(),
                }
                data = make_request(url, params=params)

                if data:
                    chunk_matches = data.get("matches", [])
                    if isinstance(chunk_matches, list):
                        for m in chunk_matches:
                            match_id = m.get("id")
                            if match_id is not None and match_id in seen_ids:
                                continue
                            if match_id is not None:
                                seen_ids.add(match_id)
                            all_matches.append(m)
                            competition_matches_count += 1

                current_from = chunk_to + timedelta(days=1)

            time.sleep(API_COMPETITION_SLEEP_SECONDS)

        logger.info(
            "Compétition %s : %d matchs historiques récupérés",
            code,
            competition_matches_count,
        )

    logger.info(
        "Total matchs historiques récupérés : %d", len(all_matches)
    )
    return all_matches


def get_competition_standings(code: str) -> Optional[Dict[str, Any]]:
    url = f"{API_BASE_URL}/competitions/{code}/standings"
    return make_request(url)


def get_head_to_head(match_id: int, limit: int = 20) -> List[Dict[str, Any]]:
    if not isinstance(match_id, int) or match_id <= 0:
        raise FootballDataAPIError(f"match_id invalide : {match_id}")
    url = f"{API_BASE_URL}/matches/{match_id}/head2head"
    data = make_request(url, params={"limit": limit})
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_team_matches(
    team_id: int,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    if not isinstance(team_id, int) or team_id <= 0:
        raise FootballDataAPIError(f"team_id invalide : {team_id}")
    url = f"{API_BASE_URL}/teams/{team_id}/matches"
    params: Dict[str, Any] = {"limit": limit}
    if date_from is not None:
        if not _validate_date_str(date_from):
            raise FootballDataAPIError(
                f"Format de date_from invalide : {date_from}"
            )
        params["dateFrom"] = date_from
    if date_to is not None:
        if not _validate_date_str(date_to):
            raise FootballDataAPIError(
                f"Format de date_to invalide : {date_to}"
            )
        params["dateTo"] = date_to
    if status is not None:
        params["status"] = status
    data = make_request(url, params=params)
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_competition_teams(code: str) -> List[Dict[str, Any]]:
    url = f"{API_BASE_URL}/competitions/{code}/teams"
    data = make_request(url)
    if not data:
        return []
    teams = data.get("teams", [])
    return teams if isinstance(teams, list) else []


def get_api_diagnostics() -> Dict[str, Any]:
    return {
        "tokens": token_manager.snapshot() if hasattr(token_manager, "snapshot") else {},
    }

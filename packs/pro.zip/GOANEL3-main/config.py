import os
import re
import sys
import json
import hashlib
import logging
import warnings
from pathlib import Path
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Mapping
from dotenv import load_dotenv

try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

warnings.filterwarnings("ignore", message="X does not have valid feature names.*")
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn")

logger = logging.getLogger("goangel.config")

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

_LOGGING_CONFIGURED = False
_CONFIG_FROZEN = False

MIN_TOKEN_LENGTH: int = 10
MAX_TOKEN_LENGTH: int = 512
MIN_TOKENS_REQUIRED: int = 1

_FEATURES_SCHEMA_COUNT: int = 40
_ARTIFACT_SCHEMA_VERSION: str = "goangel-2026.09-v1"
_EXPECTED_CLASS_COUNT: int = 3

_TOKEN_SEPARATOR_RE = re.compile(r"[,;\s]+")


class ConfigError(Exception):
    pass


class ConfigValidationError(ConfigError):
    pass


class ConfigMissingError(ConfigError):
    pass


def _load_environment() -> None:
    if ENV_PATH.exists():
        load_dotenv(dotenv_path=ENV_PATH, override=False)
    else:
        load_dotenv(override=False)


_load_environment()


def _split_token_string(raw: str) -> List[str]:
    if not raw:
        return []
    parts = _TOKEN_SEPARATOR_RE.split(str(raw))
    cleaned: List[str] = []
    for part in parts:
        value = part.strip().strip('"').strip("'").strip()
        if value:
            cleaned.append(value)
    return cleaned


def _validate_token_format(token: str) -> Tuple[bool, str]:
    if not isinstance(token, str):
        return False, "type invalide"
    if len(token) < MIN_TOKEN_LENGTH:
        return False, f"trop court ({len(token)} < {MIN_TOKEN_LENGTH})"
    if len(token) > MAX_TOKEN_LENGTH:
        return False, f"trop long ({len(token)} > {MAX_TOKEN_LENGTH})"
    if any(ch.isspace() for ch in token):
        return False, "contient des espaces"
    return True, ""


def _resolve_strict_tokens() -> bool:
    raw = os.getenv("GOANGEL_STRICT_TOKENS")
    if raw is None or not str(raw).strip():
        return True
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "y", "o")


TOKENS_STRICT: bool = _resolve_strict_tokens()


def _collect_tokens() -> List[str]:
    raw_pool = os.getenv("FOOTBALL_DATA_TOKENS", "").strip()
    raw_single = os.getenv("FOOTBALL_DATA_TOKEN", "").strip()
    raw_key = os.getenv("FOOTBALL_DATA_API_KEY", "").strip()

    candidates: List[str] = []
    candidates.extend(_split_token_string(raw_pool))
    candidates.extend(_split_token_string(raw_single))
    candidates.extend(_split_token_string(raw_key))

    seen: set = set()
    unique: List[str] = []
    for token in candidates:
        ok, reason = _validate_token_format(token)
        if not ok:
            logger.warning(
                "Token ignoré (%s) : %s***",
                reason,
                token[:4] if len(token) >= 4 else "?",
            )
            continue
        if token in seen:
            continue
        seen.add(token)
        unique.append(token)

    if len(unique) < MIN_TOKENS_REQUIRED:
        message = (
            "Aucun token Football-Data.org valide trouvé. "
            "Renseignez FOOTBALL_DATA_TOKENS dans le fichier .env "
            "ou dans l'environnement."
        )
        if TOKENS_STRICT:
            raise ConfigMissingError(message)
        logger.warning("%s (mode non strict)", message)
        return []
    return unique


tokens: List[str] = _collect_tokens()
TOKEN_COUNT: int = len(tokens)
TOKEN_MASKS: List[str] = [f"{t[:6]}***" for t in tokens]


def get_token_pool_metadata() -> Dict[str, Any]:
    return {
        "count": TOKEN_COUNT,
        "min_length": min((len(t) for t in tokens), default=0),
        "max_length": max((len(t) for t in tokens), default=0),
        "strict": bool(TOKENS_STRICT),
    }


@dataclass(frozen=True)
class Competition:
    code: str
    name: str
    country: str
    flag: str
    tier: int
    group: str = "OTHER"


@dataclass(frozen=True)
class ModelHyperparams:
    name: str
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True


_COMPETITIONS_DEFINITIONS: List[Competition] = [
    Competition("WC",  "Coupe du Monde",            "Monde",             "🌍", 1, "INTERNATIONAL"),
    Competition("EC",  "Championnat d'Europe",      "Europe",            "🇪🇺", 1, "INTERNATIONAL"),
    Competition("CL",  "Ligue des Champions",       "Europe",            "🏆", 1, "EUROPE_CUP"),
    Competition("EL",  "Ligue Europa",              "Europe",            "🥈", 1, "EUROPE_CUP"),
    Competition("PL",  "Premier League",            "Angleterre",        "🏴", 1, "EUROPE_TOP5"),
    Competition("PD",  "La Liga",                   "Espagne",           "🇪🇸", 1, "EUROPE_TOP5"),
    Competition("BL1", "Bundesliga",                "Allemagne",         "🇩🇪", 1, "EUROPE_TOP5"),
    Competition("SA",  "Serie A",                   "Italie",            "🇮🇹", 1, "EUROPE_TOP5"),
    Competition("FL1", "Ligue 1",                   "France",            "🇫🇷", 1, "EUROPE_TOP5"),
    Competition("DED", "Eredivisie",                "Pays-Bas",          "🇳🇱", 2, "OTHER"),
    Competition("PPL", "Primeira Liga",             "Portugal",          "🇵🇹", 2, "OTHER"),
    Competition("ELC", "Championship",              "Angleterre",        "🏴", 2, "OTHER"),
    Competition("BSA", "Brasileirão",               "Brésil",            "🇧🇷", 2, "SOUTH_AMERICA"),
    Competition("CLI", "Copa Libertadores",         "Amérique du Sud",   "🌎", 1, "SOUTH_AMERICA"),
]

COMPETITIONS: List[str] = [c.code for c in _COMPETITIONS_DEFINITIONS]
COMPETITIONS_DETAILS: List[Competition] = _COMPETITIONS_DEFINITIONS
COMPETITIONS_BY_CODE: Dict[str, Competition] = {
    c.code: c for c in _COMPETITIONS_DEFINITIONS
}

COMPETITIONS_CATEGORICAL_INDEX: Dict[str, int] = {
    c.code: i for i, c in enumerate(_COMPETITIONS_DEFINITIONS)
}

COMPETITIONS_TIER_LEVEL: Dict[str, int] = {
    c.code: c.tier for c in _COMPETITIONS_DEFINITIONS
}

COMPETITIONS_TIER_INDEX: Dict[str, int] = dict(COMPETITIONS_TIER_LEVEL)

COMPETITION_GROUPS: Dict[str, List[str]] = {
    "EUROPE_TOP5":   ["PL", "PD", "BL1", "SA", "FL1"],
    "EUROPE_CUP":    ["CL", "EL"],
    "INTERNATIONAL": ["WC", "EC"],
    "SOUTH_AMERICA": ["BSA", "CLI"],
    "OTHER":         ["DED", "PPL", "ELC"],
}

COMPETITION_GROUP_ORDER: Tuple[str, ...] = (
    "EUROPE_TOP5",
    "EUROPE_CUP",
    "INTERNATIONAL",
    "SOUTH_AMERICA",
    "OTHER",
)

COMPETITION_GROUP_INDEX: Dict[str, int] = {
    name: idx for idx, name in enumerate(COMPETITION_GROUP_ORDER)
}

CODE_TO_GROUP: Dict[str, str] = {
    code: group
    for group, codes in COMPETITION_GROUPS.items()
    for code in codes
}

_VALID_COMPETITION_CODES_SET: frozenset = frozenset(COMPETITIONS)
_VALID_GROUPS_SET: frozenset = frozenset(COMPETITION_GROUPS.keys())

_DAYS_IN_MONTH: Dict[int, int] = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31,
}


def _validate_competition_definitions() -> List[str]:
    errors: List[str] = []
    seen_codes: set = set()
    for c in _COMPETITIONS_DEFINITIONS:
        if c.code in seen_codes:
            errors.append(f"Code compétition dupliqué : {c.code}")
        seen_codes.add(c.code)
        if c.tier < 1:
            errors.append(f"Compétition {c.code} : tier invalide ({c.tier})")
        if c.group not in _VALID_GROUPS_SET:
            errors.append(f"Compétition {c.code} : groupe inconnu ({c.group})")
    for group, codes in COMPETITION_GROUPS.items():
        for code in codes:
            if code not in _VALID_COMPETITION_CODES_SET:
                errors.append(f"Groupe {group} référence un code inconnu : {code}")
            else:
                competition = COMPETITIONS_BY_CODE[code]
                if competition.group != group:
                    errors.append(
                        f"Compétition {code} déclarée dans groupe "
                        f"{competition.group} mais listée dans {group}"
                    )
    all_grouped_codes = set(CODE_TO_GROUP.keys())
    missing = _VALID_COMPETITION_CODES_SET - all_grouped_codes
    if missing:
        errors.append(
            f"Codes compétitions absents de COMPETITION_GROUPS : {sorted(missing)}"
        )
    return errors


_COMPETITION_DEFINITION_ERRORS = _validate_competition_definitions()
if _COMPETITION_DEFINITION_ERRORS:
    for _err in _COMPETITION_DEFINITION_ERRORS:
        logger.critical("Configuration compétitions invalide : %s", _err)
    raise ConfigValidationError(
        "Configuration compétitions invalide : "
        + " | ".join(_COMPETITION_DEFINITION_ERRORS)
    )


def get_competition_group(code: Optional[str]) -> str:
    if not code:
        return "OTHER"
    return CODE_TO_GROUP.get(code, "OTHER")


REALISTIC_HOME_LAMBDA_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   1.55,
    "EUROPE_CUP":    1.42,
    "INTERNATIONAL": 1.35,
    "SOUTH_AMERICA": 1.32,
    "OTHER":         1.50,
}

REALISTIC_AWAY_LAMBDA_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   1.25,
    "EUROPE_CUP":    1.18,
    "INTERNATIONAL": 1.10,
    "SOUTH_AMERICA": 0.98,
    "OTHER":         1.18,
}

REALISTIC_DRAW_RATE_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   0.24,
    "EUROPE_CUP":    0.25,
    "INTERNATIONAL": 0.27,
    "SOUTH_AMERICA": 0.29,
    "OTHER":         0.26,
}

REALISTIC_HOME_ADVANTAGE_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   60.0,
    "EUROPE_CUP":    55.0,
    "INTERNATIONAL": 50.0,
    "SOUTH_AMERICA": 75.0,
    "OTHER":         60.0,
}

HEADERS: Dict[str, str] = {"X-Auth-Token": tokens[0]} if tokens else {}


def get_auth_headers(token_index: int = 0) -> Dict[str, str]:
    if not tokens:
        return {}
    try:
        idx = int(token_index)
    except (TypeError, ValueError):
        idx = 0
    idx = idx % len(tokens)
    return {"X-Auth-Token": tokens[idx]}


API_BASE_URL: str = "https://api.football-data.org/v4"
API_TIMEOUT_SECONDS: float = 15.0
API_MAX_RETRIES: int = 3
API_RETRY_BACKOFF_SECONDS: float = 0.6
API_RATE_LIMIT_SLEEP_SECONDS: float = 6.0
API_COMPETITION_SLEEP_SECONDS: float = 0.7
API_MAX_CONCURRENT_REQUESTS: int = 1
API_CHUNK_DAYS: int = 180
API_CIRCUIT_BREAKER_FAILURES: int = 5
API_CIRCUIT_BREAKER_COOLDOWN: float = 60.0

CACHE_DIR: Path = (BASE_DIR / "cache").resolve()
_CACHE_DIR_ERROR: Optional[str] = None
try:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
except Exception as exc:
    _CACHE_DIR_ERROR = f"Impossible de créer {CACHE_DIR} : {exc}"

HISTORICAL_FILE: Path = CACHE_DIR / "historical.pkl"
MODELS_FILE: Path = CACHE_DIR / "models.pkl"
SCALER_FILE: Path = CACHE_DIR / "scaler.pkl"
WEIGHTS_FILE: Path = CACHE_DIR / "weights.pkl"
NAME_TO_ID_FILE: Path = CACHE_DIR / "name_to_id.pkl"
CALIBRATION_STATE_FILE: Path = CACHE_DIR / "calibration.pkl"
TEMPERATURE_STATE_FILE: Path = CACHE_DIR / "temperature.pkl"
BACKTEST_STATE_FILE: Path = CACHE_DIR / "backtest.pkl"
MANIFEST_FILE: Path = CACHE_DIR / "manifest.json"

CACHE_TTL_HOURS: int = 0
CACHE_NEVER_EXPIRES: bool = True
CACHE_ATOMIC_WRITE: bool = True


def cache_is_fresh(path: Path) -> bool:
    if CACHE_NEVER_EXPIRES:
        return path.exists()
    if not path.exists():
        return False
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    except OSError:
        return False
    age_hours = (datetime.now(timezone.utc) - mtime).total_seconds() / 3600.0
    return age_hours < CACHE_TTL_HOURS


HISTORICAL_SEASONS_LOOKBACK: int = 5
HISTORICAL_MIN_MATCHES_PER_TEAM: int = 3
MIN_MATCHES_FOR_TRAINING: int = 500
MIN_MATCHES_PER_CLASS: int = 50

FORM_WINDOW_SHORT: int = 5
FORM_WINDOW_MEDIUM: int = 10
FORM_WINDOW_LONG: int = 20

ELO_INITIAL_RATING: float = 1500.0
ELO_K_FACTOR: float = 20.0
ELO_HOME_ADVANTAGE: float = 65.0
ELO_SEASON_REGRESSION: float = 0.15

TRAIN_RATIO: float = 0.65
VAL_RATIO: float = 0.10
CALIB_RATIO: float = 0.10
TEST_RATIO: float = 0.15

MODEL_TRAIN_TEST_SPLIT: float = 0.20
MODEL_WALK_FORWARD_FOLDS: int = 5
MODEL_RANDOM_SEED: int = 42
MODEL_RETRAIN_INTERVAL_HOURS: int = 24
MODEL_N_JOBS: int = -1

CALIBRATION_METHOD: str = "isotonic"
CALIBRATION_MIN_VAL_SAMPLES: int = 300
CALIBRATION_CV_FOLDS: int = 5

TEMPERATURE_SCALING_ENABLED: bool = True
TEMPERATURE_SCALING_DEFAULT: float = 1.15
TEMPERATURE_SCALING_MIN: float = 0.70
TEMPERATURE_SCALING_MAX: float = 2.50

ODDS_BLEND_WEIGHT: float = 0.0
MODEL_BLEND_WEIGHT: float = 1.0
ODDS_ENABLED_IN_TRAINING: bool = False

MAX_CONFIDENT_PROBABILITY: float = 0.78
MIN_CONFIDENT_PROBABILITY: float = 0.03
DRAW_FLOOR_PROBABILITY: float = 0.20

PROBABILITY_CLIP_EPS: float = 0.005

XGB_N_ESTIMATORS: int = 400
XGB_MAX_DEPTH: int = 5
XGB_LEARNING_RATE: float = 0.04
XGB_SUBSAMPLE: float = 0.80
XGB_COLSAMPLE: float = 0.80
XGB_MIN_CHILD_WEIGHT: float = 5.0
XGB_REG_LAMBDA: float = 1.5
XGB_REG_ALPHA: float = 0.5

LGBM_N_ESTIMATORS: int = 400
LGBM_MAX_DEPTH: int = -1
LGBM_LEARNING_RATE: float = 0.04
LGBM_NUM_LEAVES: int = 31
LGBM_MIN_CHILD_SAMPLES: int = 25
LGBM_SUBSAMPLE: float = 0.80
LGBM_COLSAMPLE: float = 0.80
LGBM_REG_LAMBDA: float = 1.5

CATBOOST_ITERATIONS: int = 400
CATBOOST_DEPTH: int = 6
CATBOOST_LEARNING_RATE: float = 0.04
CATBOOST_L2_LEAF_REG: float = 3.0
CATBOOST_RANDOM_STRENGTH: float = 1.0

RF_N_ESTIMATORS: int = 400
RF_MAX_DEPTH: int = 10
RF_MIN_SAMPLES_LEAF: int = 5
RF_MIN_SAMPLES_SPLIT: int = 10
RF_MAX_FEATURES: str = "sqrt"
RF_MAX_FEATURES_RESOLVED: Optional[str] = "sqrt"

DL_ENABLED: bool = True
DL_HIDDEN_SIZE: int = 64
DL_EPOCHS: int = 60
DL_BATCH_SIZE: int = 32
DL_LEARNING_RATE: float = 1e-3
DL_WEIGHT_DECAY: float = 1e-4
DL_DROPOUT: float = 0.30
DL_EARLY_STOPPING_PATIENCE: int = 12
DL_GRAD_CLIP: float = 1.0

MODEL_HYPERPARAMS: Dict[str, ModelHyperparams] = {
    "XGB": ModelHyperparams(
        name="XGB",
        params={
            "n_estimators": XGB_N_ESTIMATORS,
            "max_depth": XGB_MAX_DEPTH,
            "learning_rate": XGB_LEARNING_RATE,
            "subsample": XGB_SUBSAMPLE,
            "colsample_bytree": XGB_COLSAMPLE,
            "min_child_weight": XGB_MIN_CHILD_WEIGHT,
            "reg_lambda": XGB_REG_LAMBDA,
            "reg_alpha": XGB_REG_ALPHA,
            "random_state": MODEL_RANDOM_SEED,
            "n_jobs": MODEL_N_JOBS,
        },
        enabled=True,
    ),
    "LGBM": ModelHyperparams(
        name="LGBM",
        params={
            "n_estimators": LGBM_N_ESTIMATORS,
            "max_depth": LGBM_MAX_DEPTH,
            "learning_rate": LGBM_LEARNING_RATE,
            "num_leaves": LGBM_NUM_LEAVES,
            "min_child_samples": LGBM_MIN_CHILD_SAMPLES,
            "subsample": LGBM_SUBSAMPLE,
            "colsample_bytree": LGBM_COLSAMPLE,
            "reg_lambda": LGBM_REG_LAMBDA,
            "random_state": MODEL_RANDOM_SEED,
            "n_jobs": MODEL_N_JOBS,
        },
        enabled=True,
    ),
    "CatBoost": ModelHyperparams(
        name="CatBoost",
        params={
            "iterations": CATBOOST_ITERATIONS,
            "depth": CATBOOST_DEPTH,
            "learning_rate": CATBOOST_LEARNING_RATE,
            "l2_leaf_reg": CATBOOST_L2_LEAF_REG,
            "random_strength": CATBOOST_RANDOM_STRENGTH,
            "random_state": MODEL_RANDOM_SEED,
        },
        enabled=True,
    ),
    "RF": ModelHyperparams(
        name="RF",
        params={
            "n_estimators": RF_N_ESTIMATORS,
            "max_depth": RF_MAX_DEPTH,
            "min_samples_leaf": RF_MIN_SAMPLES_LEAF,
            "min_samples_split": RF_MIN_SAMPLES_SPLIT,
            "max_features": RF_MAX_FEATURES_RESOLVED,
            "random_state": MODEL_RANDOM_SEED,
            "n_jobs": MODEL_N_JOBS,
        },
        enabled=True,
    ),
    "DL": ModelHyperparams(
        name="DL",
        params={
            "hidden_size": DL_HIDDEN_SIZE,
            "epochs": DL_EPOCHS,
            "batch_size": DL_BATCH_SIZE,
            "learning_rate": DL_LEARNING_RATE,
            "weight_decay": DL_WEIGHT_DECAY,
            "dropout": DL_DROPOUT,
            "early_stopping_patience": DL_EARLY_STOPPING_PATIENCE,
            "grad_clip": DL_GRAD_CLIP,
        },
        enabled=DL_ENABLED,
    ),
}

MIN_REALISTIC_LAMBDA: float = 0.35
MAX_REALISTIC_LAMBDA: float = 4.5
DEFAULT_HOME_LAMBDA: float = 1.45
DEFAULT_AWAY_LAMBDA: float = 1.20
MAX_GOALS_GRID: int = 12
DIXON_COLES_RHO: float = -0.05

H2H_MAX_MATCHES: int = 8
H2H_MAX_AGE_DAYS: int = 1825
H2H_MIN_MATCHES_FOR_FEATURE: int = 2

REST_DAYS_DEFAULT: float = 7.0
REST_DAYS_CAP: float = 21.0

ODDS_API_KEY: str = ""
ODDS_API_BASE_URL: str = "https://api.the-odds-api.com/v4"
ODDS_API_ENABLED: bool = False
ODDS_CACHE_TTL_MINUTES: int = 30
ODDS_MATCH_NAME_MIN_SCORE: float = 0.72
ODDS_REGIONS: str = "eu"
ODDS_MARKETS: str = "h2h"
ODDS_ODDS_FORMAT: str = "decimal"
ODDS_REMOVE_VIG: bool = True
ODDS_REQUESTS_PER_MINUTE: int = 20

ODDS_API_SPORT_KEYS: Dict[str, str] = {
    "PL":  "soccer_epl",
    "PD":  "soccer_spain_la_liga",
    "BL1": "soccer_germany_bundesliga",
    "SA":  "soccer_italy_serie_a",
    "FL1": "soccer_france_ligue_one",
    "CL":  "soccer_uefa_champs_league",
    "EL":  "soccer_uefa_europa_league",
    "DED": "soccer_netherlands_eredivisie",
    "PPL": "soccer_portugal_primeira_liga",
    "ELC": "soccer_efl_champ",
    "BSA": "soccer_brazil_campeonato",
    "CLI": "soccer_conmebol_copa_libertadores",
    "WC":  "soccer_fifa_world_cup",
    "EC":  "soccer_uefa_european_championship",
}

INJURIES_API_KEY: str = ""
INJURIES_API_ENABLED: bool = False
INJURIES_CACHE_TTL_HOURS: int = 6

BACKTEST_LAST_N_MATCHES: int = 500
BACKTEST_MIN_LOG_LOSS: float = 1.05
BACKTEST_MIN_ACCURACY: float = 0.45
BACKTEST_MIN_BRIER: float = 0.20
BACKTEST_WALK_FORWARD_STEPS: int = 5
BACKTEST_SAVE_REPORT: bool = True

ENSEMBLE_MIN_WEIGHT: float = 0.0
ENSEMBLE_MAX_WEIGHT: float = 0.60
ENSEMBLE_DISAGREEMENT_THRESHOLD: float = 0.10

FEATURE_MIN_COVERAGE: float = 0.60
FEATURE_OUTLIER_ZSCORE: float = 5.0
FEATURE_CLIP_ENABLED: bool = True

LOG_LEVEL: int = logging.INFO
LOG_FORMAT: str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
LOG_FILE: str = str(CACHE_DIR / "goangel.log")
LOG_MAX_BYTES: int = 10 * 1024 * 1024
LOG_BACKUP_COUNT: int = 5
CONSOLE_VERBOSE: bool = False

TIMEZONE: str = "UTC"
_TZ_CACHE: Dict[str, Any] = {}


def _resolve_timezone() -> Any:
    if TIMEZONE in _TZ_CACHE:
        return _TZ_CACHE[TIMEZONE]
    tz: Any = timezone.utc
    if ZoneInfo is not None:
        try:
            tz = ZoneInfo(TIMEZONE)
        except Exception as exc:
            logger.warning("Timezone %r invalide, repli sur UTC : %s", TIMEZONE, exc)
            tz = timezone.utc
    _TZ_CACHE[TIMEZONE] = tz
    return tz


def get_timezone() -> Any:
    return _resolve_timezone()


def now_local() -> datetime:
    return datetime.now(get_timezone())


DEFAULT_SEASON_START_MONTH: int = 7
DEFAULT_SEASON_START_DAY: int = 1
DEFAULT_SEASON_END_MONTH: int = 6
DEFAULT_SEASON_END_DAY: int = 30


def _build_log_handlers() -> List[logging.Handler]:
    handlers: List[logging.Handler] = []
    if LOG_FILE:
        try:
            from logging.handlers import RotatingFileHandler
            log_path = Path(LOG_FILE)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = RotatingFileHandler(
                log_path,
                maxBytes=LOG_MAX_BYTES,
                backupCount=LOG_BACKUP_COUNT,
                encoding="utf-8",
            )
            file_handler.setLevel(LOG_LEVEL)
            file_handler.setFormatter(logging.Formatter(LOG_FORMAT))
            handlers.append(file_handler)
        except Exception as exc:
            print(
                f"Impossible d'initialiser le fichier de log : {exc}",
                file=sys.stderr,
            )
    if CONSOLE_VERBOSE:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(LOG_LEVEL)
        console_handler.setFormatter(logging.Formatter(LOG_FORMAT))
        handlers.append(console_handler)
    if not handlers:
        handlers.append(logging.NullHandler())
    return handlers


def configure_logging(force: bool = False) -> None:
    global _LOGGING_CONFIGURED
    if _LOGGING_CONFIGURED and not force:
        return
    handlers = _build_log_handlers()
    logging.basicConfig(
        level=LOG_LEVEL,
        format=LOG_FORMAT,
        handlers=handlers,
        force=True,
    )
    logging.captureWarnings(True)
    warnings_logger = logging.getLogger("py.warnings")
    warnings_logger.setLevel(LOG_LEVEL)
    warnings_logger.propagate = False
    for h in list(warnings_logger.handlers):
        warnings_logger.removeHandler(h)
    for h in handlers:
        warnings_logger.addHandler(h)
    _LOGGING_CONFIGURED = True


configure_logging()


def stage_print(message: str) -> None:
    try:
        print(message, flush=True)
    except Exception:
        pass


def _validate_ratios() -> List[str]:
    errors: List[str] = []
    total = TRAIN_RATIO + VAL_RATIO + CALIB_RATIO + TEST_RATIO
    if abs(total - 1.0) > 1e-6:
        errors.append(
            f"TRAIN_RATIO + VAL_RATIO + CALIB_RATIO + TEST_RATIO = {total:.6f} "
            f"(attendu 1.0)"
        )
    for name, value in (
        ("TRAIN_RATIO", TRAIN_RATIO),
        ("VAL_RATIO", VAL_RATIO),
        ("CALIB_RATIO", CALIB_RATIO),
        ("TEST_RATIO", TEST_RATIO),
    ):
        if value <= 0 or value >= 1:
            errors.append(f"{name} doit être dans (0, 1) (reçu {value})")
    return errors


def _validate_api_parameters() -> List[str]:
    errors: List[str] = []
    if API_TIMEOUT_SECONDS <= 0 or API_TIMEOUT_SECONDS > 300:
        errors.append(f"API_TIMEOUT_SECONDS hors bornes (reçu {API_TIMEOUT_SECONDS})")
    if API_MAX_RETRIES < 1 or API_MAX_RETRIES > 20:
        errors.append(f"API_MAX_RETRIES hors bornes (reçu {API_MAX_RETRIES})")
    if API_RETRY_BACKOFF_SECONDS < 0:
        errors.append(f"API_RETRY_BACKOFF_SECONDS doit être >= 0")
    if API_RATE_LIMIT_SLEEP_SECONDS < 0:
        errors.append(f"API_RATE_LIMIT_SLEEP_SECONDS doit être >= 0")
    if API_COMPETITION_SLEEP_SECONDS < 0:
        errors.append(f"API_COMPETITION_SLEEP_SECONDS doit être >= 0")
    if API_MAX_CONCURRENT_REQUESTS < 1 or API_MAX_CONCURRENT_REQUESTS > 64:
        errors.append(
            f"API_MAX_CONCURRENT_REQUESTS hors bornes "
            f"(reçu {API_MAX_CONCURRENT_REQUESTS})"
        )
    if API_CHUNK_DAYS < 1 or API_CHUNK_DAYS > 365:
        errors.append(f"API_CHUNK_DAYS hors bornes (reçu {API_CHUNK_DAYS})")
    if API_CIRCUIT_BREAKER_FAILURES < 1:
        errors.append("API_CIRCUIT_BREAKER_FAILURES doit être >= 1")
    if API_CIRCUIT_BREAKER_COOLDOWN < 1:
        errors.append("API_CIRCUIT_BREAKER_COOLDOWN doit être >= 1")
    return errors


def _validate_xgb_parameters() -> List[str]:
    errors: List[str] = []
    if XGB_N_ESTIMATORS < 10 or XGB_N_ESTIMATORS > 20000:
        errors.append(f"XGB_N_ESTIMATORS hors bornes (reçu {XGB_N_ESTIMATORS})")
    if XGB_MAX_DEPTH < 1 or XGB_MAX_DEPTH > 32:
        errors.append(f"XGB_MAX_DEPTH hors bornes (reçu {XGB_MAX_DEPTH})")
    if XGB_LEARNING_RATE <= 0 or XGB_LEARNING_RATE > 1:
        errors.append(f"XGB_LEARNING_RATE hors bornes (reçu {XGB_LEARNING_RATE})")
    if XGB_SUBSAMPLE <= 0 or XGB_SUBSAMPLE > 1:
        errors.append(f"XGB_SUBSAMPLE hors bornes (reçu {XGB_SUBSAMPLE})")
    if XGB_COLSAMPLE <= 0 or XGB_COLSAMPLE > 1:
        errors.append(f"XGB_COLSAMPLE hors bornes (reçu {XGB_COLSAMPLE})")
    if XGB_MIN_CHILD_WEIGHT < 0:
        errors.append("XGB_MIN_CHILD_WEIGHT doit être >= 0")
    if XGB_REG_LAMBDA < 0:
        errors.append("XGB_REG_LAMBDA doit être >= 0")
    if XGB_REG_ALPHA < 0:
        errors.append("XGB_REG_ALPHA doit être >= 0")
    return errors


def _validate_lgbm_parameters() -> List[str]:
    errors: List[str] = []
    if LGBM_N_ESTIMATORS < 10 or LGBM_N_ESTIMATORS > 20000:
        errors.append(f"LGBM_N_ESTIMATORS hors bornes (reçu {LGBM_N_ESTIMATORS})")
    if LGBM_MAX_DEPTH < -1 or LGBM_MAX_DEPTH > 64:
        errors.append(f"LGBM_MAX_DEPTH hors bornes (reçu {LGBM_MAX_DEPTH})")
    if LGBM_LEARNING_RATE <= 0 or LGBM_LEARNING_RATE > 1:
        errors.append(f"LGBM_LEARNING_RATE hors bornes (reçu {LGBM_LEARNING_RATE})")
    if LGBM_NUM_LEAVES < 4 or LGBM_NUM_LEAVES > 4096:
        errors.append(f"LGBM_NUM_LEAVES hors bornes (reçu {LGBM_NUM_LEAVES})")
    if LGBM_MIN_CHILD_SAMPLES < 1:
        errors.append("LGBM_MIN_CHILD_SAMPLES doit être >= 1")
    if LGBM_SUBSAMPLE <= 0 or LGBM_SUBSAMPLE > 1:
        errors.append(f"LGBM_SUBSAMPLE hors bornes (reçu {LGBM_SUBSAMPLE})")
    if LGBM_COLSAMPLE <= 0 or LGBM_COLSAMPLE > 1:
        errors.append(f"LGBM_COLSAMPLE hors bornes (reçu {LGBM_COLSAMPLE})")
    if LGBM_REG_LAMBDA < 0:
        errors.append("LGBM_REG_LAMBDA doit être >= 0")
    return errors


def _validate_catboost_parameters() -> List[str]:
    errors: List[str] = []
    if CATBOOST_ITERATIONS < 10 or CATBOOST_ITERATIONS > 20000:
        errors.append(f"CATBOOST_ITERATIONS hors bornes (reçu {CATBOOST_ITERATIONS})")
    if CATBOOST_DEPTH < 1 or CATBOOST_DEPTH > 16:
        errors.append(f"CATBOOST_DEPTH hors bornes (reçu {CATBOOST_DEPTH})")
    if CATBOOST_LEARNING_RATE <= 0 or CATBOOST_LEARNING_RATE > 1:
        errors.append(
            f"CATBOOST_LEARNING_RATE hors bornes (reçu {CATBOOST_LEARNING_RATE})"
        )
    if CATBOOST_L2_LEAF_REG < 0:
        errors.append("CATBOOST_L2_LEAF_REG doit être >= 0")
    if CATBOOST_RANDOM_STRENGTH < 0:
        errors.append("CATBOOST_RANDOM_STRENGTH doit être >= 0")
    return errors


def _validate_rf_parameters() -> List[str]:
    errors: List[str] = []
    if RF_N_ESTIMATORS < 10 or RF_N_ESTIMATORS > 10000:
        errors.append(f"RF_N_ESTIMATORS hors bornes (reçu {RF_N_ESTIMATORS})")
    if RF_MAX_DEPTH < 1 or RF_MAX_DEPTH > 200:
        errors.append(f"RF_MAX_DEPTH hors bornes (reçu {RF_MAX_DEPTH})")
    if RF_MIN_SAMPLES_LEAF < 1:
        errors.append("RF_MIN_SAMPLES_LEAF doit être >= 1")
    if RF_MIN_SAMPLES_SPLIT < 2:
        errors.append("RF_MIN_SAMPLES_SPLIT doit être >= 2")
    if RF_MAX_FEATURES not in ("sqrt", "log2", "None"):
        errors.append(f"RF_MAX_FEATURES invalide (reçu {RF_MAX_FEATURES})")
    return errors


def _validate_dl_parameters() -> List[str]:
    errors: List[str] = []
    if DL_HIDDEN_SIZE < 8 or DL_HIDDEN_SIZE > 4096:
        errors.append(f"DL_HIDDEN_SIZE hors bornes (reçu {DL_HIDDEN_SIZE})")
    if DL_EPOCHS < 1 or DL_EPOCHS > 5000:
        errors.append(f"DL_EPOCHS hors bornes (reçu {DL_EPOCHS})")
    if DL_BATCH_SIZE < 1 or DL_BATCH_SIZE > 8192:
        errors.append(f"DL_BATCH_SIZE hors bornes (reçu {DL_BATCH_SIZE})")
    if DL_LEARNING_RATE <= 0 or DL_LEARNING_RATE > 1:
        errors.append(f"DL_LEARNING_RATE hors bornes (reçu {DL_LEARNING_RATE})")
    if DL_WEIGHT_DECAY < 0 or DL_WEIGHT_DECAY > 1:
        errors.append(f"DL_WEIGHT_DECAY hors bornes (reçu {DL_WEIGHT_DECAY})")
    if DL_DROPOUT < 0 or DL_DROPOUT >= 1:
        errors.append(f"DL_DROPOUT hors bornes (reçu {DL_DROPOUT})")
    if DL_EARLY_STOPPING_PATIENCE < 1:
        errors.append("DL_EARLY_STOPPING_PATIENCE doit être >= 1")
    if DL_GRAD_CLIP <= 0:
        errors.append("DL_GRAD_CLIP doit être > 0")
    return errors


def _validate_goal_parameters() -> List[str]:
    errors: List[str] = []
    if MIN_REALISTIC_LAMBDA <= 0:
        errors.append("MIN_REALISTIC_LAMBDA doit être > 0")
    if MAX_REALISTIC_LAMBDA <= MIN_REALISTIC_LAMBDA:
        errors.append("MAX_REALISTIC_LAMBDA doit être > MIN_REALISTIC_LAMBDA")
    if DEFAULT_HOME_LAMBDA < MIN_REALISTIC_LAMBDA:
        errors.append("DEFAULT_HOME_LAMBDA doit être >= MIN_REALISTIC_LAMBDA")
    if DEFAULT_HOME_LAMBDA > MAX_REALISTIC_LAMBDA:
        errors.append("DEFAULT_HOME_LAMBDA doit être <= MAX_REALISTIC_LAMBDA")
    if DEFAULT_AWAY_LAMBDA < MIN_REALISTIC_LAMBDA:
        errors.append("DEFAULT_AWAY_LAMBDA doit être >= MIN_REALISTIC_LAMBDA")
    if DEFAULT_AWAY_LAMBDA > MAX_REALISTIC_LAMBDA:
        errors.append("DEFAULT_AWAY_LAMBDA doit être <= MAX_REALISTIC_LAMBDA")
    if MAX_GOALS_GRID < 6 or MAX_GOALS_GRID > 30:
        errors.append(f"MAX_GOALS_GRID hors bornes (reçu {MAX_GOALS_GRID})")
    if DIXON_COLES_RHO < -1.0 or DIXON_COLES_RHO > 1.0:
        errors.append(f"DIXON_COLES_RHO hors bornes (reçu {DIXON_COLES_RHO})")
    return errors


def _validate_calibration_parameters() -> List[str]:
    errors: List[str] = []
    if CALIBRATION_METHOD not in ("isotonic", "sigmoid"):
        errors.append(f"CALIBRATION_METHOD invalide (reçu {CALIBRATION_METHOD})")
    if CALIBRATION_MIN_VAL_SAMPLES < 30:
        errors.append("CALIBRATION_MIN_VAL_SAMPLES doit être >= 30")
    if CALIBRATION_CV_FOLDS < 2 or CALIBRATION_CV_FOLDS > 20:
        errors.append(f"CALIBRATION_CV_FOLDS hors bornes (reçu {CALIBRATION_CV_FOLDS})")
    if TEMPERATURE_SCALING_MIN >= TEMPERATURE_SCALING_MAX:
        errors.append("TEMPERATURE_SCALING_MIN doit être < TEMPERATURE_SCALING_MAX")
    if not (
        TEMPERATURE_SCALING_MIN
        <= TEMPERATURE_SCALING_DEFAULT
        <= TEMPERATURE_SCALING_MAX
    ):
        errors.append(
            "TEMPERATURE_SCALING_DEFAULT doit être dans "
            "[TEMPERATURE_SCALING_MIN, TEMPERATURE_SCALING_MAX]"
        )
    return errors


def _validate_blend_parameters() -> List[str]:
    errors: List[str] = []
    total = ODDS_BLEND_WEIGHT + MODEL_BLEND_WEIGHT
    if total <= 0:
        errors.append("ODDS_BLEND_WEIGHT + MODEL_BLEND_WEIGHT doit être > 0")
    if ODDS_BLEND_WEIGHT < 0 or ODDS_BLEND_WEIGHT > 1:
        errors.append(f"ODDS_BLEND_WEIGHT hors bornes (reçu {ODDS_BLEND_WEIGHT})")
    if MODEL_BLEND_WEIGHT < 0 or MODEL_BLEND_WEIGHT > 1:
        errors.append(f"MODEL_BLEND_WEIGHT hors bornes (reçu {MODEL_BLEND_WEIGHT})")
    return errors


def _validate_probability_parameters() -> List[str]:
    errors: List[str] = []
    if MAX_CONFIDENT_PROBABILITY <= MIN_CONFIDENT_PROBABILITY:
        errors.append(
            "MAX_CONFIDENT_PROBABILITY doit être > MIN_CONFIDENT_PROBABILITY"
        )
    if MAX_CONFIDENT_PROBABILITY > 1.0:
        errors.append("MAX_CONFIDENT_PROBABILITY doit être <= 1.0")
    if MIN_CONFIDENT_PROBABILITY < 0.0:
        errors.append("MIN_CONFIDENT_PROBABILITY doit être >= 0.0")
    if DRAW_FLOOR_PROBABILITY < 0.0 or DRAW_FLOOR_PROBABILITY > 0.5:
        errors.append(
            f"DRAW_FLOOR_PROBABILITY hors bornes (reçu {DRAW_FLOOR_PROBABILITY})"
        )
    if PROBABILITY_CLIP_EPS <= 0 or PROBABILITY_CLIP_EPS > 0.5:
        errors.append(f"PROBABILITY_CLIP_EPS hors bornes (reçu {PROBABILITY_CLIP_EPS})")
    return errors


def _validate_ensemble_parameters() -> List[str]:
    errors: List[str] = []
    if ENSEMBLE_MIN_WEIGHT < 0 or ENSEMBLE_MIN_WEIGHT > 1:
        errors.append(f"ENSEMBLE_MIN_WEIGHT hors bornes (reçu {ENSEMBLE_MIN_WEIGHT})")
    if ENSEMBLE_MAX_WEIGHT <= 0 or ENSEMBLE_MAX_WEIGHT > 1:
        errors.append(f"ENSEMBLE_MAX_WEIGHT hors bornes (reçu {ENSEMBLE_MAX_WEIGHT})")
    if ENSEMBLE_MAX_WEIGHT < ENSEMBLE_MIN_WEIGHT:
        errors.append("ENSEMBLE_MAX_WEIGHT doit être >= ENSEMBLE_MIN_WEIGHT")
    if ENSEMBLE_DISAGREEMENT_THRESHOLD <= 0 or ENSEMBLE_DISAGREEMENT_THRESHOLD > 1:
        errors.append(
            f"ENSEMBLE_DISAGREEMENT_THRESHOLD hors bornes "
            f"(reçu {ENSEMBLE_DISAGREEMENT_THRESHOLD})"
        )
    return errors


def _validate_backtest_parameters() -> List[str]:
    errors: List[str] = []
    if BACKTEST_LAST_N_MATCHES < 10:
        errors.append("BACKTEST_LAST_N_MATCHES doit être >= 10")
    if BACKTEST_MIN_LOG_LOSS <= 0:
        errors.append("BACKTEST_MIN_LOG_LOSS doit être > 0")
    if BACKTEST_MIN_ACCURACY <= 0 or BACKTEST_MIN_ACCURACY >= 1:
        errors.append("BACKTEST_MIN_ACCURACY doit être dans (0, 1)")
    if BACKTEST_MIN_BRIER <= 0 or BACKTEST_MIN_BRIER >= 1:
        errors.append("BACKTEST_MIN_BRIER doit être dans (0, 1)")
    if BACKTEST_WALK_FORWARD_STEPS < 2:
        errors.append("BACKTEST_WALK_FORWARD_STEPS doit être >= 2")
    return errors


def _validate_feature_parameters() -> List[str]:
    errors: List[str] = []
    if FEATURE_MIN_COVERAGE <= 0 or FEATURE_MIN_COVERAGE > 1:
        errors.append(f"FEATURE_MIN_COVERAGE hors bornes (reçu {FEATURE_MIN_COVERAGE})")
    if FEATURE_OUTLIER_ZSCORE <= 0:
        errors.append("FEATURE_OUTLIER_ZSCORE doit être > 0")
    return errors


def _validate_form_windows() -> List[str]:
    errors: List[str] = []
    if FORM_WINDOW_SHORT < 1:
        errors.append("FORM_WINDOW_SHORT doit être >= 1")
    if FORM_WINDOW_MEDIUM < FORM_WINDOW_SHORT:
        errors.append("FORM_WINDOW_MEDIUM doit être >= FORM_WINDOW_SHORT")
    if FORM_WINDOW_LONG < FORM_WINDOW_MEDIUM:
        errors.append("FORM_WINDOW_LONG doit être >= FORM_WINDOW_MEDIUM")
    return errors


def _validate_elo_parameters() -> List[str]:
    errors: List[str] = []
    if ELO_INITIAL_RATING <= 0:
        errors.append("ELO_INITIAL_RATING doit être > 0")
    if ELO_K_FACTOR <= 0 or ELO_K_FACTOR > 200:
        errors.append(f"ELO_K_FACTOR hors bornes (reçu {ELO_K_FACTOR})")
    if ELO_HOME_ADVANTAGE < 0:
        errors.append("ELO_HOME_ADVANTAGE doit être >= 0")
    if ELO_SEASON_REGRESSION < 0 or ELO_SEASON_REGRESSION > 1:
        errors.append(
            f"ELO_SEASON_REGRESSION hors bornes (reçu {ELO_SEASON_REGRESSION})"
        )
    return errors


def _validate_training_parameters() -> List[str]:
    errors: List[str] = []
    if MIN_MATCHES_FOR_TRAINING < 50:
        errors.append("MIN_MATCHES_FOR_TRAINING doit être >= 50")
    if MIN_MATCHES_PER_CLASS < 10:
        errors.append("MIN_MATCHES_PER_CLASS doit être >= 10")
    if HISTORICAL_SEASONS_LOOKBACK < 1 or HISTORICAL_SEASONS_LOOKBACK > 30:
        errors.append(
            f"HISTORICAL_SEASONS_LOOKBACK hors bornes "
            f"(reçu {HISTORICAL_SEASONS_LOOKBACK})"
        )
    if MODEL_TRAIN_TEST_SPLIT <= 0 or MODEL_TRAIN_TEST_SPLIT >= 1:
        errors.append(
            f"MODEL_TRAIN_TEST_SPLIT hors bornes (reçu {MODEL_TRAIN_TEST_SPLIT})"
        )
    if MODEL_WALK_FORWARD_FOLDS < 2 or MODEL_WALK_FORWARD_FOLDS > 30:
        errors.append(
            f"MODEL_WALK_FORWARD_FOLDS hors bornes "
            f"(reçu {MODEL_WALK_FORWARD_FOLDS})"
        )
    if MODEL_RANDOM_SEED < 0:
        errors.append("MODEL_RANDOM_SEED doit être >= 0")
    if MODEL_N_JOBS < -1:
        errors.append("MODEL_N_JOBS doit être >= -1")
    return errors


def _validate_cache_parameters() -> List[str]:
    errors: List[str] = []
    if _CACHE_DIR_ERROR is not None:
        errors.append(_CACHE_DIR_ERROR)
    elif not CACHE_DIR.exists():
        errors.append(f"Le répertoire de cache {CACHE_DIR} n'existe pas")
    elif not os.access(CACHE_DIR, os.W_OK):
        errors.append(
            f"Le répertoire de cache {CACHE_DIR} n'est pas accessible en écriture"
        )
    if not CACHE_NEVER_EXPIRES:
        errors.append(
            "CACHE_NEVER_EXPIRES doit rester True pour garantir la persistance"
        )
    return errors


def _validate_ensemble_and_hyperparams_consistency() -> List[str]:
    errors: List[str] = []
    if not MODEL_HYPERPARAMS:
        errors.append("MODEL_HYPERPARAMS est vide")
    for name, hp in MODEL_HYPERPARAMS.items():
        if not isinstance(hp, ModelHyperparams):
            errors.append(f"MODEL_HYPERPARAMS[{name}] n'est pas un ModelHyperparams")
    if TOKENS_STRICT and TOKEN_COUNT < MIN_TOKENS_REQUIRED:
        errors.append(
            f"Au moins {MIN_TOKENS_REQUIRED} token(s) requis "
            f"(reçu {TOKEN_COUNT})"
        )
    return errors


def _validate_competition_registry() -> List[str]:
    return _validate_competition_definitions()


def _aggregate_validation() -> List[str]:
    errors: List[str] = []
    errors.extend(_validate_ratios())
    errors.extend(_validate_api_parameters())
    errors.extend(_validate_xgb_parameters())
    errors.extend(_validate_lgbm_parameters())
    errors.extend(_validate_catboost_parameters())
    errors.extend(_validate_rf_parameters())
    errors.extend(_validate_dl_parameters())
    errors.extend(_validate_goal_parameters())
    errors.extend(_validate_calibration_parameters())
    errors.extend(_validate_blend_parameters())
    errors.extend(_validate_probability_parameters())
    errors.extend(_validate_ensemble_parameters())
    errors.extend(_validate_backtest_parameters())
    errors.extend(_validate_feature_parameters())
    errors.extend(_validate_form_windows())
    errors.extend(_validate_elo_parameters())
    errors.extend(_validate_training_parameters())
    errors.extend(_validate_cache_parameters())
    errors.extend(_validate_ensemble_and_hyperparams_consistency())
    errors.extend(_validate_competition_registry())
    return errors


def _compute_config_fingerprint() -> str:
    hasher = hashlib.sha256()
    parts: List[str] = [
        f"schema={_ARTIFACT_SCHEMA_VERSION}",
        f"features={_FEATURES_SCHEMA_COUNT}",
        f"classes={_EXPECTED_CLASS_COUNT}",
        f"max_goals={MAX_GOALS_GRID}",
        f"rho={DIXON_COLES_RHO}",
        f"min_lambda={MIN_REALISTIC_LAMBDA}",
        f"max_lambda={MAX_REALISTIC_LAMBDA}",
        f"calibration={CALIBRATION_METHOD}",
        f"temperature={TEMPERATURE_SCALING_DEFAULT}",
        f"ensemble_min={ENSEMBLE_MIN_WEIGHT}",
        f"ensemble_max={ENSEMBLE_MAX_WEIGHT}",
        f"competitions={','.join(sorted(COMPETITIONS))}",
    ]
    for group_name in COMPETITION_GROUP_ORDER:
        codes = COMPETITION_GROUPS.get(group_name, [])
        parts.append(f"group:{group_name}={','.join(codes)}")
    for key, value in sorted(COMPETITIONS_TIER_INDEX.items()):
        parts.append(f"tier:{key}={value}")
    for part in parts:
        hasher.update(part.encode("utf-8"))
        hasher.update(b"\x00")
    return hasher.hexdigest()


def _compute_feature_schema_fingerprint(feature_names: List[str]) -> str:
    hasher = hashlib.sha256()
    hasher.update(f"count={len(feature_names)}".encode("utf-8"))
    hasher.update(b"\x00")
    for name in feature_names:
        hasher.update(str(name).encode("utf-8"))
        hasher.update(b"\x00")
    return hasher.hexdigest()


CONFIG_FINGERPRINT: str = _compute_config_fingerprint()
ARTIFACT_SCHEMA_VERSION: str = _ARTIFACT_SCHEMA_VERSION
EXPECTED_FEATURE_COUNT_REFERENCE: int = _FEATURES_SCHEMA_COUNT
EXPECTED_CLASS_COUNT: int = _EXPECTED_CLASS_COUNT


def compute_feature_schema_hash(feature_names: List[str]) -> str:
    return _compute_feature_schema_fingerprint(feature_names)


def write_cache_manifest(extra: Optional[Mapping[str, Any]] = None) -> Optional[Path]:
    payload: Dict[str, Any] = {
        "artifact_schema_version": _ARTIFACT_SCHEMA_VERSION,
        "config_fingerprint": CONFIG_FINGERPRINT,
        "feature_schema_count": _FEATURES_SCHEMA_COUNT,
        "class_count": _EXPECTED_CLASS_COUNT,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "token_metadata": get_token_pool_metadata(),
        "competitions": list(COMPETITIONS),
    }
    if extra:
        for key, value in extra.items():
            payload[str(key)] = value
    try:
        MANIFEST_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = MANIFEST_FILE.with_suffix(MANIFEST_FILE.suffix + ".tmp")
        with open(tmp_path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        os.replace(tmp_path, MANIFEST_FILE)
        return MANIFEST_FILE
    except Exception as exc:
        logger.warning("Impossible d'écrire le manifeste de cache : %s", exc)
        return None


def read_cache_manifest() -> Optional[Dict[str, Any]]:
    if not MANIFEST_FILE.exists():
        return None
    try:
        with open(MANIFEST_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:
        logger.warning("Manifeste de cache illisible : %s", exc)
        return None
    if not isinstance(data, dict):
        return None
    return data


def validate_runtime_environment() -> None:
    errors = _aggregate_validation()
    if errors:
        for err in errors:
            logger.critical("Configuration invalide : %s", err)
        raise ConfigValidationError(
            "Configuration invalide : " + " | ".join(errors)
        )


validate_runtime_environment()

logger.info(
    "Configuration chargée : %d token(s), %d compétitions, cache=%s, "
    "ratios=%.2f/%.2f/%.2f/%.2f, calibration=%s, temperature=%.2f, "
    "cache_never_expires=%s, modèles=%d, fingerprint=%s",
    TOKEN_COUNT,
    len(COMPETITIONS),
    CACHE_DIR,
    TRAIN_RATIO,
    VAL_RATIO,
    CALIB_RATIO,
    TEST_RATIO,
    CALIBRATION_METHOD,
    TEMPERATURE_SCALING_DEFAULT,
    CACHE_NEVER_EXPIRES,
    len(MODEL_HYPERPARAMS),
    CONFIG_FINGERPRINT[:12],
)

import math
import logging
import unicodedata
import warnings
from collections import Counter
from datetime import date
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import log_loss

warnings.filterwarnings("ignore")

try:
    from sklearn.frozen import FrozenEstimator
except ImportError:
    FrozenEstimator = None

from penaltyblog.models import (
    PoissonGoalsModel,
    DixonColesGoalModel,
    BivariatePoissonGoalModel,
    ZeroInflatedPoissonGoalsModel,
    NegativeBinomialGoalModel,
    WeibullCopulaGoalsModel,
)

try:
    from xgboost import XGBClassifier
except ImportError:
    XGBClassifier = None
try:
    from lightgbm import LGBMClassifier
except ImportError:
    LGBMClassifier = None
try:
    from catboost import CatBoostClassifier
except ImportError:
    CatBoostClassifier = None
try:
    from sklearn.ensemble import RandomForestClassifier
except ImportError:
    RandomForestClassifier = None
try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
except ImportError:
    torch = None
    nn = None

from config import (
    FORM_WINDOW_MEDIUM,
    FORM_WINDOW_LONG,
    ELO_INITIAL_RATING,
    ELO_K_FACTOR,
    ELO_HOME_ADVANTAGE,
    MODEL_TRAIN_TEST_SPLIT,
    MODEL_WALK_FORWARD_FOLDS,
    MODEL_RANDOM_SEED,
    MODEL_N_JOBS,
    CALIBRATION_METHOD,
    CALIBRATION_MIN_VAL_SAMPLES,
    TEMPERATURE_SCALING_ENABLED,
    TEMPERATURE_SCALING_DEFAULT,
    TEMPERATURE_SCALING_MIN,
    TEMPERATURE_SCALING_MAX,
    XGB_N_ESTIMATORS,
    XGB_MAX_DEPTH,
    XGB_LEARNING_RATE,
    XGB_SUBSAMPLE,
    XGB_COLSAMPLE,
    XGB_MIN_CHILD_WEIGHT,
    XGB_REG_LAMBDA,
    XGB_REG_ALPHA,
    LGBM_N_ESTIMATORS,
    LGBM_MAX_DEPTH,
    LGBM_LEARNING_RATE,
    LGBM_NUM_LEAVES,
    LGBM_MIN_CHILD_SAMPLES,
    LGBM_SUBSAMPLE,
    LGBM_COLSAMPLE,
    LGBM_REG_LAMBDA,
    CATBOOST_ITERATIONS,
    CATBOOST_DEPTH,
    CATBOOST_LEARNING_RATE,
    CATBOOST_L2_LEAF_REG,
    CATBOOST_RANDOM_STRENGTH,
    RF_N_ESTIMATORS,
    RF_MAX_DEPTH,
    RF_MIN_SAMPLES_LEAF,
    RF_MIN_SAMPLES_SPLIT,
    RF_MAX_FEATURES_RESOLVED,
    DL_ENABLED,
    DL_HIDDEN_SIZE,
    DL_EPOCHS,
    DL_BATCH_SIZE,
    DL_LEARNING_RATE,
    DL_WEIGHT_DECAY,
    DL_DROPOUT,
    DL_EARLY_STOPPING_PATIENCE,
    DL_GRAD_CLIP,
    MIN_MATCHES_FOR_TRAINING,
    MIN_MATCHES_PER_CLASS,
    COMPETITIONS_TIER_INDEX,
    H2H_MAX_MATCHES,
    H2H_MAX_AGE_DAYS,
    H2H_MIN_MATCHES_FOR_FEATURE,
    REST_DAYS_DEFAULT,
    REST_DAYS_CAP,
    FEATURE_CLIP_ENABLED,
    FEATURE_OUTLIER_ZSCORE,
    ENSEMBLE_MIN_WEIGHT,
    ENSEMBLE_MAX_WEIGHT,
    DEFAULT_SEASON_START_MONTH,
    DEFAULT_SEASON_START_DAY,
    DEFAULT_SEASON_END_MONTH,
    DEFAULT_SEASON_END_DAY,
    stage_print,
)

logger = logging.getLogger("goangel.features")

FEATURE_NAMES: List[str] = [
    "home_gf_medium",
    "home_ga_medium",
    "away_gf_medium",
    "away_ga_medium",
    "home_gf_long",
    "home_ga_long",
    "away_gf_long",
    "away_ga_long",
    "home_home_gf",
    "home_home_ga",
    "away_away_gf",
    "away_away_ga",
    "home_goal_diff",
    "away_goal_diff",
    "home_points_rate",
    "away_points_rate",
    "home_elo",
    "away_elo",
    "elo_diff",
    "h2h_home_win_rate",
    "h2h_draw_rate",
    "h2h_away_win_rate",
    "h2h_avg_home_goals",
    "h2h_avg_away_goals",
    "home_rest_days",
    "away_rest_days",
    "home_matches_played",
    "away_matches_played",
    "competition_tier_index",
    "home_ht_gf_rate",
    "home_ht_ga_rate",
    "away_ht_gf_rate",
    "away_ht_ga_rate",
    "home_1h_lead_rate",
    "away_1h_lead_rate",
    "home_clean_sheet_rate",
    "away_clean_sheet_rate",
    "home_failed_to_score_rate",
    "away_failed_to_score_rate",
    "season_progress",
]

EXPECTED_FEATURE_COUNT: int = len(FEATURE_NAMES)

_FEATURE_INDEX: Dict[str, int] = {name: idx for idx, name in enumerate(FEATURE_NAMES)}

_NON_NEGATIVE_FEATURES: Tuple[str, ...] = (
    "home_gf_medium", "home_ga_medium", "away_gf_medium", "away_ga_medium",
    "home_gf_long", "home_ga_long", "away_gf_long", "away_ga_long",
    "home_home_gf", "home_home_ga", "away_away_gf", "away_away_ga",
    "home_points_rate", "away_points_rate",
    "h2h_home_win_rate", "h2h_draw_rate", "h2h_away_win_rate",
    "h2h_avg_home_goals", "h2h_avg_away_goals",
    "home_rest_days", "away_rest_days",
    "home_matches_played", "away_matches_played",
    "home_ht_gf_rate", "home_ht_ga_rate",
    "away_ht_gf_rate", "away_ht_ga_rate",
    "home_1h_lead_rate", "away_1h_lead_rate",
    "home_clean_sheet_rate", "away_clean_sheet_rate",
    "home_failed_to_score_rate", "away_failed_to_score_rate",
    "season_progress",
)

_PB_MODEL_CLASSES: Dict[str, Any] = {
    "PoissonGoalsModel": PoissonGoalsModel,
    "DixonColesGoalModel": DixonColesGoalModel,
    "BivariatePoissonGoalModel": BivariatePoissonGoalModel,
    "ZeroInflatedPoissonGoalsModel": ZeroInflatedPoissonGoalsModel,
    "NegativeBinomialGoalModel": NegativeBinomialGoalModel,
    "WeibullCopulaGoalsModel": WeibullCopulaGoalsModel,
}

_PB_MODEL_ORDER: Tuple[str, ...] = tuple(_PB_MODEL_CLASSES.keys())

_TRAIN_RATIO: float = 0.65
_VAL_RATIO: float = 0.10
_CALIB_RATIO: float = 0.10
_TEST_RATIO: float = 0.15
_WARMUP_RATIO: float = 0.10

_H2H_NEUTRAL_HOME_WINRATE: float = 0.40
_H2H_NEUTRAL_DRAW_RATE: float = 0.25
_H2H_NEUTRAL_AWAY_WINRATE: float = 0.35
_H2H_NEUTRAL_HOME_GOALS: float = 1.35
_H2H_NEUTRAL_AWAY_GOALS: float = 1.15

_LEAGUE_DEFAULT_GF: float = 1.35
_LEAGUE_DEFAULT_PTS: float = 0.42
_LEAGUE_DEFAULT_HOME_GF: float = 1.45

_HT_GOAL_SHARE: float = 0.50
_DEFAULT_HT_LEAD_RATE: float = 0.30
_DEFAULT_CLEAN_SHEET_RATE: float = 0.28
_DEFAULT_FAILED_TO_SCORE_RATE: float = 0.28
_DEFAULT_SEASON_PROGRESS: float = 0.50

_MIN_CLASSES_FOR_TRAINING: int = 3
_MIN_TEST_SAMPLES: int = 30
_MIN_VAL_SAMPLES_FOR_DL: int = 20

_XG_MODEL_SOURCE_TAG: str = "penaltyblog_model_estimate"

_VALID_TRAINING_STATUSES: Tuple[str, ...] = ("FINISHED",)
_OPTIONAL_AWARDED_STATUS: str = "AWARDED"

_MIN_MATCHES_PER_COMPETITION_FOR_DEFAULTS: int = 50
_MIN_MATCHES_FOR_COMP_SPECIFIC_STATS: int = 5

_CALIBRATION_STATUS_OK: str = "calibrated"
_CALIBRATION_STATUS_SKIPPED_SMALL: str = "skipped_small_calib_set"
_CALIBRATION_STATUS_SKIPPED_CLASSES: str = "skipped_missing_classes"
_CALIBRATION_STATUS_FAILED: str = "failed_kept_raw"
_CALIBRATION_STATUS_RAW_KEPT: str = "raw_model_kept"
_CALIBRATION_STATUS_TEMPERATURE: str = "temperature_scaled"

_H2H_SOURCE_SPECIFIC: str = "competition_specific"
_H2H_SOURCE_GLOBAL: str = "global_fallback"
_H2H_SOURCE_NEUTRAL: str = "neutral_default"

_LL_SOURCE_WALK_FORWARD: str = "walk_forward"
_LL_SOURCE_CALIBRATION: str = "calibration_set"
_LL_SOURCE_UNAVAILABLE: str = "unavailable"

_COMPETITION_UNKNOWN_INDEX: int = -1
_MAX_ACCEPTABLE_LOGLOSS: float = 1.35

_QUALITY_RELATIVE_THRESHOLD: float = 1.25

_GLOBAL_COMP_KEY: str = "_GLOBAL_"

_PROBA_ATOL: float = 1e-5

_PB_WF_MIN_TRAIN_SAMPLES: int = 80
_PB_WF_MIN_VAL_SAMPLES: int = 5
_PB_CALIB_MIN_VALID_SAMPLES: int = 30

_STRICT_COMPETITION_DEFAULT: bool = True

_DL_TEMPERATURE_GRID_MIN: float = 0.50
_DL_TEMPERATURE_GRID_MAX: float = 3.00
_DL_TEMPERATURE_GRID_STEPS: int = 26

_EPS: float = 1e-9
_EPS_WEIGHT: float = 1e-6

_DAYS_PER_SECOND: float = 86400.0
_MAX_REST_DAYS_VALIDITY: float = 365.0


def _safe_int_or_none(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    try:
        if isinstance(value, float):
            if value != value:
                return None
            if not value.is_integer():
                return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _safe_goals_or_none(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    try:
        if isinstance(value, float):
            if value != value:
                return None
            if not value.is_integer():
                return None
        goals = int(value)
    except (TypeError, ValueError):
        return None
    if goals < 0:
        return None
    return goals


def _normalize_competition_code(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip().upper()
    return text if text else None


def _comp_key(competition_code: Optional[str]) -> str:
    normalized = _normalize_competition_code(competition_code)
    return normalized if normalized is not None else _GLOBAL_COMP_KEY


def _extract_team_name(team: Dict[str, Any]) -> Optional[str]:
    if not isinstance(team, dict):
        return None
    for field in ("name", "shortName", "tla"):
        val = team.get(field)
        if isinstance(val, str) and val.strip():
            return val.strip()
    return None


def normalize_name(name: Any) -> str:
    if not isinstance(name, str):
        return ""
    normalized = unicodedata.normalize("NFKD", name).encode("ASCII", "ignore").decode("ASCII")
    normalized = normalized.lower().strip()
    normalized = "".join(
        ch if (ch.isalnum() or ch.isspace()) else " " for ch in normalized
    )
    normalized = " ".join(normalized.split())
    return normalized


def _team_key_raw(
    team_id: Any,
    raw_name: Any,
    competition_code: Optional[str] = None,
) -> str:
    parsed_id = _safe_int_or_none(team_id)
    if parsed_id is not None:
        return f"id:{parsed_id}"
    normalized = normalize_name(raw_name)
    comp = _normalize_competition_code(competition_code)
    if comp:
        return f"name:{comp}:{normalized}"
    return f"name:{normalized}"


def _build_name_to_id_resolver(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    votes: Dict[str, Dict[int, int]] = {}
    for r in rows:
        for name_field, id_field in (("home_raw", "home_id"), ("away_raw", "away_id")):
            name = normalize_name(r.get(name_field))
            tid = _safe_int_or_none(r.get(id_field))
            if not name or tid is None:
                continue
            votes.setdefault(name, {})
            votes[name][tid] = votes[name].get(tid, 0) + 1
    resolver: Dict[str, int] = {}
    for name, counts in votes.items():
        resolver[name] = max(counts.items(), key=lambda kv: kv[1])[0]
    return resolver


def _extract_dates_with_log(
    dates_raw: pd.Series,
) -> Tuple[pd.Series, int]:
    parsed = pd.to_datetime(dates_raw, errors="coerce", utc=True)
    invalid_mask = parsed.isna()
    invalid_count = int(invalid_mask.sum())
    if invalid_count > 0:
        sample = dates_raw[invalid_mask].head(5).tolist()
        logger.warning(
            "Dates invalides ignorées : %d (échantillon : %s)",
            invalid_count, sample,
        )
    return parsed, invalid_count


def _extract_halftime_scores(score: Any) -> Tuple[Optional[int], Optional[int]]:
    if not isinstance(score, dict):
        return None, None
    half_time = score.get("halfTime")
    if not isinstance(half_time, dict):
        return None, None
    ht_home = _safe_goals_or_none(half_time.get("home"))
    ht_away = _safe_goals_or_none(half_time.get("away"))
    return ht_home, ht_away


def process_matches(
    matches: List[Dict[str, Any]],
    allowed_statuses: Optional[Tuple[str, ...]] = _VALID_TRAINING_STATUSES,
    include_awarded: bool = False,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    skip_counters: Counter = Counter()
    seen_match_ids: set = set()

    for m in matches:
        if not isinstance(m, dict):
            skip_counters["not_dict"] += 1
            continue
        status_raw = m.get("status")
        status_norm = (
            str(status_raw).strip().upper()
            if isinstance(status_raw, str)
            else ""
        )

        is_awarded = status_norm == _OPTIONAL_AWARDED_STATUS
        if is_awarded:
            if not include_awarded:
                skip_counters["awarded_excluded"] += 1
                continue
        else:
            if allowed_statuses is not None and status_norm not in allowed_statuses:
                skip_counters[f"status_{status_norm or 'UNKNOWN'}"] += 1
                continue

        match_id_raw = m.get("id")
        match_id_int = _safe_int_or_none(match_id_raw)
        if match_id_int is not None:
            if match_id_int in seen_match_ids:
                skip_counters["duplicate_match_id"] += 1
                continue
            seen_match_ids.add(match_id_int)

        home_team = m.get("homeTeam")
        away_team = m.get("awayTeam")
        if not isinstance(home_team, dict) or not isinstance(away_team, dict):
            skip_counters["missing_team_dict"] += 1
            continue
        home_name = _extract_team_name(home_team)
        away_name = _extract_team_name(away_team)
        if not home_name or not away_name:
            skip_counters["missing_team_name"] += 1
            continue

        score = m.get("score", {})
        full_time = score.get("fullTime", {}) if isinstance(score, dict) else {}
        raw_home = full_time.get("home") if isinstance(full_time, dict) else None
        raw_away = full_time.get("away") if isinstance(full_time, dict) else None
        goals_home = _safe_goals_or_none(raw_home)
        goals_away = _safe_goals_or_none(raw_away)
        if goals_home is None:
            skip_counters["invalid_goals_home"] += 1
        if goals_away is None:
            skip_counters["invalid_goals_away"] += 1

        ht_home, ht_away = _extract_halftime_scores(score)
        if ht_home is None or ht_away is None:
            skip_counters["missing_halftime"] += 1

        comp = m.get("competition", {}) if isinstance(m.get("competition"), dict) else {}
        rows.append({
            "match_id": match_id_int,
            "home_raw": home_name,
            "away_raw": away_name,
            "home_id": home_team.get("id"),
            "away_id": away_team.get("id"),
            "goals_home": goals_home,
            "goals_away": goals_away,
            "ht_home": ht_home,
            "ht_away": ht_away,
            "status": status_norm if status_norm else "UNKNOWN",
            "date": m.get("utcDate", ""),
            "competition": comp.get("name", ""),
            "competition_code": _normalize_competition_code(comp.get("code")),
        })

    if skip_counters:
        logger.info(
            "process_matches : %d matchs retenus, rejets : %s",
            len(rows), dict(skip_counters),
        )

    if not rows:
        return pd.DataFrame()

    resolver = _build_name_to_id_resolver(rows)

    name_to_resolved_id: Dict[str, int] = {}
    for r in rows:
        norm_home = normalize_name(r["home_raw"])
        norm_away = normalize_name(r["away_raw"])
        hid = _safe_int_or_none(r.get("home_id"))
        aid = _safe_int_or_none(r.get("away_id"))
        if hid is not None:
            name_to_resolved_id.setdefault(norm_home, hid)
        if aid is not None:
            name_to_resolved_id.setdefault(norm_away, aid)

    for r in rows:
        norm_home = normalize_name(r["home_raw"])
        norm_away = normalize_name(r["away_raw"])

        if _safe_int_or_none(r.get("home_id")) is None:
            if norm_home in name_to_resolved_id:
                r["home_id"] = name_to_resolved_id[norm_home]
            elif norm_home in resolver:
                r["home_id"] = resolver[norm_home]
        if _safe_int_or_none(r.get("away_id")) is None:
            if norm_away in name_to_resolved_id:
                r["away_id"] = name_to_resolved_id[norm_away]
            elif norm_away in resolver:
                r["away_id"] = resolver[norm_away]

        r["home"] = norm_home
        r["away"] = norm_away
        comp_code = r.get("competition_code")
        r["home_key"] = _team_key_raw(r.get("home_id"), r["home_raw"], comp_code)
        r["away_key"] = _team_key_raw(r.get("away_id"), r["away_raw"], comp_code)

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    df["date_parsed"], n_invalid_dates = _extract_dates_with_log(df["date"])
    if n_invalid_dates > 0:
        df = df[df["date_parsed"].notna()].copy()

    if "match_id" in df.columns:
        before = len(df)
        df = df.drop_duplicates(subset=["match_id"], keep="first").reset_index(drop=True)
        dropped = before - len(df)
        if dropped > 0:
            logger.info("Doublons match_id supprimés : %d", dropped)

    df = df.sort_values("date_parsed", kind="mergesort").reset_index(drop=True)
    return df


class EloSystem:
    def __init__(
        self,
        initial_rating: float = ELO_INITIAL_RATING,
        k_factor: float = ELO_K_FACTOR,
        home_advantage: float = ELO_HOME_ADVANTAGE,
    ):
        self.initial_rating = float(initial_rating)
        self.k_factor = float(k_factor)
        self.home_advantage = float(home_advantage)
        self.ratings: Dict[Tuple[str, str], float] = {}

    def _key(self, competition_code: Optional[str], team: str) -> Tuple[str, str]:
        comp = _comp_key(competition_code)
        return (comp, team)

    def get_rating(
        self,
        team: str,
        competition_code: Optional[str] = None,
    ) -> float:
        return self.ratings.get(self._key(competition_code, team), self.initial_rating)

    def expected_score(self, rating_a: float, rating_b: float) -> float:
        return 1.0 / (1.0 + 10.0 ** ((rating_b - rating_a) / 400.0))

    def update(
        self,
        home: str,
        away: str,
        goals_home: int,
        goals_away: int,
        competition_code: Optional[str] = None,
    ) -> Tuple[float, float]:
        hkey = self._key(competition_code, home)
        akey = self._key(competition_code, away)
        home_rating = self.ratings.get(hkey, self.initial_rating)
        away_rating = self.ratings.get(akey, self.initial_rating)
        pre_home = home_rating
        pre_away = away_rating
        expected_home = self.expected_score(home_rating + self.home_advantage, away_rating)
        expected_away = 1.0 - expected_home
        if goals_home > goals_away:
            actual_home, actual_away = 1.0, 0.0
        elif goals_home == goals_away:
            actual_home, actual_away = 0.5, 0.5
        else:
            actual_home, actual_away = 0.0, 1.0
        goal_diff = abs(int(goals_home) - int(goals_away))
        multiplier = 1.0 + math.log(max(goal_diff, 1))
        multiplier = min(multiplier, 2.5)
        new_home = home_rating + self.k_factor * multiplier * (actual_home - expected_home)
        new_away = away_rating + self.k_factor * multiplier * (actual_away - expected_away)
        self.ratings[hkey] = new_home
        self.ratings[akey] = new_away
        return pre_home, pre_away


class TeamHistoryTracker:
    def __init__(
        self,
        default_gf: float = _LEAGUE_DEFAULT_GF,
        default_ga: float = _LEAGUE_DEFAULT_GF,
        default_pts: float = _LEAGUE_DEFAULT_PTS,
        strict_competition: bool = _STRICT_COMPETITION_DEFAULT,
    ):
        self.gf: Dict[Tuple[str, str], List[float]] = {}
        self.ga: Dict[Tuple[str, str], List[float]] = {}
        self.home_gf: Dict[Tuple[str, str], List[float]] = {}
        self.home_ga: Dict[Tuple[str, str], List[float]] = {}
        self.away_gf: Dict[Tuple[str, str], List[float]] = {}
        self.away_ga: Dict[Tuple[str, str], List[float]] = {}
        self.results: Dict[Tuple[str, str], List[str]] = {}
        self.last_match_date: Dict[Tuple[str, str], Optional[pd.Timestamp]] = {}
        self.matches_played: Dict[Tuple[str, str], int] = {}
        self.ht_gf: Dict[Tuple[str, str], List[float]] = {}
        self.ht_ga: Dict[Tuple[str, str], List[float]] = {}
        self.ht_lead: Dict[Tuple[str, str], List[float]] = {}
        self.clean_sheet: Dict[Tuple[str, str], List[float]] = {}
        self.failed_to_score: Dict[Tuple[str, str], List[float]] = {}
        self.h2h: Dict[
            Tuple[str, str],
            List[Tuple[int, int, Optional[pd.Timestamp], Optional[str]]],
        ] = {}
        self.default_gf = float(default_gf)
        self.default_ga = float(default_ga)
        self.default_pts = float(default_pts)
        self.strict_competition = bool(strict_competition)

    def _ensure(self, team: str, competition_code: Optional[str] = None) -> None:
        comp = _comp_key(competition_code)
        keys_to_init = [(comp, team)]
        if comp != _GLOBAL_COMP_KEY and not self.strict_competition:
            keys_to_init.append((_GLOBAL_COMP_KEY, team))
        for key in keys_to_init:
            if key not in self.gf:
                self.gf[key] = []
                self.ga[key] = []
                self.home_gf[key] = []
                self.home_ga[key] = []
                self.away_gf[key] = []
                self.away_ga[key] = []
                self.results[key] = []
                self.last_match_date[key] = None
                self.matches_played[key] = 0
                self.ht_gf[key] = []
                self.ht_ga[key] = []
                self.ht_lead[key] = []
                self.clean_sheet[key] = []
                self.failed_to_score[key] = []

    def _select_key(
        self,
        team: str,
        competition_code: Optional[str] = None,
    ) -> Tuple[str, str]:
        comp = _comp_key(competition_code)
        if comp == _GLOBAL_COMP_KEY:
            return (_GLOBAL_COMP_KEY, team)
        self._ensure(team, comp)
        specific_key = (comp, team)
        specific_count = self.matches_played.get(specific_key, 0)

        if specific_count >= _MIN_MATCHES_FOR_COMP_SPECIFIC_STATS:
            return specific_key

        if self.strict_competition:
            return specific_key

        global_key = (_GLOBAL_COMP_KEY, team)
        global_count = self.matches_played.get(global_key, 0)
        if global_count > 0:
            return global_key
        return specific_key

    def snapshot(
        self,
        team: str,
        competition_code: Optional[str] = None,
    ) -> Dict[str, Any]:
        key = self._select_key(team, competition_code)
        return {
            "gf": self.gf.get(key, []),
            "ga": self.ga.get(key, []),
            "home_gf": self.home_gf.get(key, []),
            "home_ga": self.home_ga.get(key, []),
            "away_gf": self.away_gf.get(key, []),
            "away_ga": self.away_ga.get(key, []),
            "results": self.results.get(key, []),
            "last_match_date": self.last_match_date.get(key),
            "matches_played": self.matches_played.get(key, 0),
            "ht_gf": self.ht_gf.get(key, []),
            "ht_ga": self.ht_ga.get(key, []),
            "ht_lead": self.ht_lead.get(key, []),
            "clean_sheet": self.clean_sheet.get(key, []),
            "failed_to_score": self.failed_to_score.get(key, []),
        }

    def head_to_head(
        self,
        home: str,
        away: str,
        limit: int = H2H_MAX_MATCHES,
        reference_date: Optional[pd.Timestamp] = None,
        max_age_days: int = H2H_MAX_AGE_DAYS,
        competition_code: Optional[str] = None,
    ) -> Tuple[List[Tuple[int, int]], str]:
        key1 = (home, away)
        key2 = (away, home)
        raw: List[Tuple[int, int, Optional[pd.Timestamp], Optional[str]]] = []
        for gh, ga, dt, cc in self.h2h.get(key1, []):
            raw.append((gh, ga, dt, cc))
        for gh, ga, dt, cc in self.h2h.get(key2, []):
            raw.append((ga, gh, dt, cc))

        comp_norm = _normalize_competition_code(competition_code)
        source = _H2H_SOURCE_GLOBAL if raw else _H2H_SOURCE_NEUTRAL

        if comp_norm is not None and raw:
            filtered_by_comp = [
                r for r in raw
                if r[3] is not None and str(r[3]).strip().upper() == comp_norm
            ]
            if len(filtered_by_comp) >= H2H_MIN_MATCHES_FOR_FEATURE:
                raw = filtered_by_comp
                source = _H2H_SOURCE_SPECIFIC
            elif self.strict_competition:
                raw = filtered_by_comp
                source = _H2H_SOURCE_SPECIFIC

        if reference_date is not None and not pd.isna(reference_date):
            strict_cutoff = reference_date
            age_cutoff = reference_date - pd.Timedelta(days=int(max_age_days))
            filtered: List[Tuple[int, int, pd.Timestamp]] = []
            for gh, ga, dt, _cc in raw:
                if dt is None or pd.isna(dt):
                    continue
                if dt < strict_cutoff and dt >= age_cutoff:
                    filtered.append((gh, ga, dt))
            filtered.sort(key=lambda r: r[2])
            tail = filtered[-limit:] if limit > 0 else filtered
            if not tail:
                source = _H2H_SOURCE_NEUTRAL
            return ([(gh, ga) for gh, ga, _ in tail], source)

        valid: List[Tuple[int, int, pd.Timestamp]] = [
            (gh, ga, dt) for gh, ga, dt, _cc in raw
            if dt is not None and not pd.isna(dt)
        ]
        valid.sort(key=lambda r: r[2])
        tail = valid[-limit:] if limit > 0 else valid
        if not tail:
            source = _H2H_SOURCE_NEUTRAL
        return ([(gh, ga) for gh, ga, _ in tail], source)

    def record(
        self,
        home: str,
        away: str,
        goals_home: int,
        goals_away: int,
        match_date: Optional[pd.Timestamp],
        competition_code: Optional[str] = None,
        ht_home: Optional[int] = None,
        ht_away: Optional[int] = None,
    ) -> None:
        comp = _comp_key(competition_code)
        target_keys: List[Tuple[str, str]] = []
        target_keys.append((comp, home))
        target_keys.append((comp, away))
        if comp != _GLOBAL_COMP_KEY and not self.strict_competition:
            target_keys.append((_GLOBAL_COMP_KEY, home))
            target_keys.append((_GLOBAL_COMP_KEY, away))

        for key in target_keys:
            if key not in self.gf:
                self.gf[key] = []
                self.ga[key] = []
                self.home_gf[key] = []
                self.home_ga[key] = []
                self.away_gf[key] = []
                self.away_ga[key] = []
                self.results[key] = []
                self.last_match_date[key] = None
                self.matches_played[key] = 0
                self.ht_gf[key] = []
                self.ht_ga[key] = []
                self.ht_lead[key] = []
                self.clean_sheet[key] = []
                self.failed_to_score[key] = []

        if goals_home > goals_away:
            res_home, res_away = "W", "L"
        elif goals_home == goals_away:
            res_home, res_away = "D", "D"
        else:
            res_home, res_away = "L", "W"

        home_clean_sheet = 1.0 if goals_away == 0 else 0.0
        home_failed_to_score = 1.0 if goals_home == 0 else 0.0
        away_clean_sheet = 1.0 if goals_home == 0 else 0.0
        away_failed_to_score = 1.0 if goals_away == 0 else 0.0

        ht_available = (
            ht_home is not None
            and ht_away is not None
        )
        if ht_available:
            home_ht_lead = 1.0 if ht_home > ht_away else 0.0
            away_ht_lead = 1.0 if ht_away > ht_home else 0.0
        else:
            home_ht_lead = 0.0
            away_ht_lead = 0.0

        for key in target_keys:
            is_home_slot = (key[1] == home)
            if is_home_slot:
                self.gf[key].append(goals_home)
                self.ga[key].append(goals_away)
                self.home_gf[key].append(goals_home)
                self.home_ga[key].append(goals_away)
                self.results[key].append(res_home)
                self.clean_sheet[key].append(home_clean_sheet)
                self.failed_to_score[key].append(home_failed_to_score)
                if ht_available:
                    self.ht_gf[key].append(float(ht_home))
                    self.ht_ga[key].append(float(ht_away))
                    self.ht_lead[key].append(home_ht_lead)
            else:
                self.gf[key].append(goals_away)
                self.ga[key].append(goals_home)
                self.away_gf[key].append(goals_away)
                self.away_ga[key].append(goals_home)
                self.results[key].append(res_away)
                self.clean_sheet[key].append(away_clean_sheet)
                self.failed_to_score[key].append(away_failed_to_score)
                if ht_available:
                    self.ht_gf[key].append(float(ht_away))
                    self.ht_ga[key].append(float(ht_home))
                    self.ht_lead[key].append(away_ht_lead)
            self.last_match_date[key] = match_date
            self.matches_played[key] += 1

        comp_norm = _normalize_competition_code(competition_code)
        key_h2h = (home, away)
        if key_h2h not in self.h2h:
            self.h2h[key_h2h] = []
        self.h2h[key_h2h].append(
            (int(goals_home), int(goals_away), match_date, comp_norm)
        )


def _safe_mean(values: List[float], window: int, default: float) -> float:
    if window <= 0:
        tail = values
    else:
        tail = values[-window:]
    if not tail:
        return float(default)
    return float(np.mean(tail))


def _points_rate(results: List[str], window: int, default: float) -> float:
    if window <= 0:
        tail = results
    else:
        tail = results[-window:]
    if not tail:
        return float(default)
    points = sum(3 if r == "W" else 1 if r == "D" else 0 for r in tail)
    return points / (3.0 * len(tail))


def _rest_days(
    last_date: Optional[pd.Timestamp],
    current_date: Optional[pd.Timestamp],
    default_days: float = REST_DAYS_DEFAULT,
    cap_days: float = REST_DAYS_CAP,
) -> float:
    if last_date is None or current_date is None or pd.isna(last_date) or pd.isna(current_date):
        return float(default_days)
    delta = (current_date - last_date).total_seconds() / _DAYS_PER_SECOND
    if delta < 0 or delta > _MAX_REST_DAYS_VALIDITY:
        return float(default_days)
    if delta > cap_days:
        return float(cap_days)
    return float(delta)


def _season_progress(match_date: Optional[pd.Timestamp]) -> float:
    if match_date is None:
        return float(_DEFAULT_SEASON_PROGRESS)
    try:
        if pd.isna(match_date):
            return float(_DEFAULT_SEASON_PROGRESS)
    except (TypeError, ValueError):
        return float(_DEFAULT_SEASON_PROGRESS)

    try:
        d = match_date.date() if hasattr(match_date, "date") else match_date
    except Exception:
        return float(_DEFAULT_SEASON_PROGRESS)

    if not isinstance(d, date):
        return float(_DEFAULT_SEASON_PROGRESS)

    try:
        if d.month >= DEFAULT_SEASON_START_MONTH:
            start_year = d.year
        else:
            start_year = d.year - 1
        season_start = date(
            start_year, DEFAULT_SEASON_START_MONTH, DEFAULT_SEASON_START_DAY
        )
        season_end = date(
            start_year + 1, DEFAULT_SEASON_END_MONTH, DEFAULT_SEASON_END_DAY
        )
    except (TypeError, ValueError):
        return float(_DEFAULT_SEASON_PROGRESS)

    total_days = (season_end - season_start).days
    if total_days <= 0:
        return float(_DEFAULT_SEASON_PROGRESS)

    elapsed_days = (d - season_start).days
    progress = float(elapsed_days) / float(total_days)
    return float(np.clip(progress, 0.0, 1.0))


def compute_league_defaults(
    df_past: pd.DataFrame,
    competition_code: Optional[str] = None,
) -> Tuple[float, float, float]:
    comp_norm = _normalize_competition_code(competition_code)
    ref = df_past
    if (
        comp_norm is not None
        and df_past is not None
        and not df_past.empty
        and "competition_code" in df_past.columns
    ):
        specific = df_past[df_past["competition_code"] == comp_norm]
        if len(specific) >= _MIN_MATCHES_PER_COMPETITION_FOR_DEFAULTS:
            ref = specific

    if ref is None or ref.empty:
        return _LEAGUE_DEFAULT_GF, _LEAGUE_DEFAULT_PTS, _LEAGUE_DEFAULT_HOME_GF

    home_goals = ref["goals_home"].dropna()
    default_home_gf = (
        float(home_goals.mean()) if not home_goals.empty else _LEAGUE_DEFAULT_HOME_GF
    )
    goals_all = pd.concat(
        [ref["goals_home"], ref["goals_away"]], ignore_index=True
    ).dropna()
    default_gf = float(goals_all.mean()) if not goals_all.empty else _LEAGUE_DEFAULT_GF
    if not np.isfinite(default_gf) or default_gf <= 0:
        default_gf = _LEAGUE_DEFAULT_GF
    if not np.isfinite(default_home_gf) or default_home_gf <= 0:
        default_home_gf = _LEAGUE_DEFAULT_HOME_GF
    draw_mask = (ref["goals_home"] == ref["goals_away"])
    draw_rate = float(draw_mask.mean()) if len(ref) > 0 else 0.25
    if not np.isfinite(draw_rate):
        draw_rate = 0.25
    default_pts = (3.0 - draw_rate) / 6.0
    return default_gf, default_pts, default_home_gf


def build_feature_vector(
    home: str,
    away: str,
    tracker: TeamHistoryTracker,
    elo_system: EloSystem,
    match_date: Optional[pd.Timestamp],
    competition_code: Optional[str] = None,
) -> Tuple[np.ndarray, str]:
    home_hist = tracker.snapshot(home, competition_code)
    away_hist = tracker.snapshot(away, competition_code)
    dgf = tracker.default_gf
    dga = tracker.default_ga
    dpts = tracker.default_pts

    home_gf_medium = _safe_mean(home_hist["gf"], FORM_WINDOW_MEDIUM, dgf)
    home_ga_medium = _safe_mean(home_hist["ga"], FORM_WINDOW_MEDIUM, dga)
    away_gf_medium = _safe_mean(away_hist["gf"], FORM_WINDOW_MEDIUM, dgf)
    away_ga_medium = _safe_mean(away_hist["ga"], FORM_WINDOW_MEDIUM, dga)

    home_gf_long = _safe_mean(home_hist["gf"], FORM_WINDOW_LONG, dgf)
    home_ga_long = _safe_mean(home_hist["ga"], FORM_WINDOW_LONG, dga)
    away_gf_long = _safe_mean(away_hist["gf"], FORM_WINDOW_LONG, dgf)
    away_ga_long = _safe_mean(away_hist["ga"], FORM_WINDOW_LONG, dga)

    home_home_gf = _safe_mean(home_hist["home_gf"], FORM_WINDOW_MEDIUM, dgf)
    home_home_ga = _safe_mean(home_hist["home_ga"], FORM_WINDOW_MEDIUM, dga)
    away_away_gf = _safe_mean(away_hist["away_gf"], FORM_WINDOW_MEDIUM, dgf)
    away_away_ga = _safe_mean(away_hist["away_ga"], FORM_WINDOW_MEDIUM, dga)

    home_goal_diff = home_gf_medium - home_ga_medium
    away_goal_diff = away_gf_medium - away_ga_medium

    home_points_rate = _points_rate(home_hist["results"], FORM_WINDOW_MEDIUM, dpts)
    away_points_rate = _points_rate(away_hist["results"], FORM_WINDOW_MEDIUM, dpts)

    home_elo = elo_system.get_rating(home, competition_code)
    away_elo = elo_system.get_rating(away, competition_code)
    elo_diff = home_elo - away_elo

    h2h_matches, h2h_source = tracker.head_to_head(
        home,
        away,
        limit=H2H_MAX_MATCHES,
        reference_date=match_date,
        competition_code=competition_code,
    )
    if len(h2h_matches) >= H2H_MIN_MATCHES_FOR_FEATURE:
        total = len(h2h_matches)
        h2h_home_wins = sum(1 for gh, ga in h2h_matches if gh > ga)
        h2h_draws = sum(1 for gh, ga in h2h_matches if gh == ga)
        h2h_away_wins = sum(1 for gh, ga in h2h_matches if gh < ga)
        h2h_home_win_rate = h2h_home_wins / total
        h2h_draw_rate = h2h_draws / total
        h2h_away_win_rate = h2h_away_wins / total
        h2h_avg_home_goals = float(np.mean([gh for gh, _ in h2h_matches]))
        h2h_avg_away_goals = float(np.mean([ga for _, ga in h2h_matches]))
    else:
        h2h_home_win_rate = _H2H_NEUTRAL_HOME_WINRATE
        h2h_draw_rate = _H2H_NEUTRAL_DRAW_RATE
        h2h_away_win_rate = _H2H_NEUTRAL_AWAY_WINRATE
        h2h_avg_home_goals = _H2H_NEUTRAL_HOME_GOALS
        h2h_avg_away_goals = _H2H_NEUTRAL_AWAY_GOALS
        h2h_source = _H2H_SOURCE_NEUTRAL

    home_rest_days = _rest_days(home_hist["last_match_date"], match_date)
    away_rest_days = _rest_days(away_hist["last_match_date"], match_date)

    home_matches_played = float(home_hist["matches_played"])
    away_matches_played = float(away_hist["matches_played"])

    comp_code = _normalize_competition_code(competition_code)
    if comp_code is None:
        competition_tier_index = float(_COMPETITION_UNKNOWN_INDEX)
    else:
        competition_tier_index = float(
            COMPETITIONS_TIER_INDEX.get(comp_code, _COMPETITION_UNKNOWN_INDEX)
        )

    ht_default_gf = dgf * _HT_GOAL_SHARE
    ht_default_ga = dga * _HT_GOAL_SHARE

    home_ht_gf_rate = _safe_mean(
        home_hist["ht_gf"], FORM_WINDOW_MEDIUM, ht_default_gf
    )
    home_ht_ga_rate = _safe_mean(
        home_hist["ht_ga"], FORM_WINDOW_MEDIUM, ht_default_ga
    )
    away_ht_gf_rate = _safe_mean(
        away_hist["ht_gf"], FORM_WINDOW_MEDIUM, ht_default_gf
    )
    away_ht_ga_rate = _safe_mean(
        away_hist["ht_ga"], FORM_WINDOW_MEDIUM, ht_default_ga
    )

    home_1h_lead_rate = _safe_mean(
        home_hist["ht_lead"], FORM_WINDOW_MEDIUM, _DEFAULT_HT_LEAD_RATE
    )
    away_1h_lead_rate = _safe_mean(
        away_hist["ht_lead"], FORM_WINDOW_MEDIUM, _DEFAULT_HT_LEAD_RATE
    )

    home_clean_sheet_rate = _safe_mean(
        home_hist["clean_sheet"], FORM_WINDOW_MEDIUM, _DEFAULT_CLEAN_SHEET_RATE
    )
    away_clean_sheet_rate = _safe_mean(
        away_hist["clean_sheet"], FORM_WINDOW_MEDIUM, _DEFAULT_CLEAN_SHEET_RATE
    )

    home_failed_to_score_rate = _safe_mean(
        home_hist["failed_to_score"],
        FORM_WINDOW_MEDIUM,
        _DEFAULT_FAILED_TO_SCORE_RATE,
    )
    away_failed_to_score_rate = _safe_mean(
        away_hist["failed_to_score"],
        FORM_WINDOW_MEDIUM,
        _DEFAULT_FAILED_TO_SCORE_RATE,
    )

    season_progress = _season_progress(match_date)

    feat = np.array([
        home_gf_medium, home_ga_medium, away_gf_medium, away_ga_medium,
        home_gf_long, home_ga_long, away_gf_long, away_ga_long,
        home_home_gf, home_home_ga, away_away_gf, away_away_ga,
        home_goal_diff, away_goal_diff,
        home_points_rate, away_points_rate,
        home_elo, away_elo, elo_diff,
        h2h_home_win_rate, h2h_draw_rate, h2h_away_win_rate,
        h2h_avg_home_goals, h2h_avg_away_goals,
        home_rest_days, away_rest_days,
        home_matches_played, away_matches_played,
        competition_tier_index,
        home_ht_gf_rate, home_ht_ga_rate,
        away_ht_gf_rate, away_ht_ga_rate,
        home_1h_lead_rate, away_1h_lead_rate,
        home_clean_sheet_rate, away_clean_sheet_rate,
        home_failed_to_score_rate, away_failed_to_score_rate,
        season_progress,
    ], dtype=np.float64)

    if feat.shape[0] != EXPECTED_FEATURE_COUNT:
        logger.error(
            "Vecteur de features incohérent : %d != %d",
            feat.shape[0],
            EXPECTED_FEATURE_COUNT,
        )

    if FEATURE_CLIP_ENABLED:
        np.nan_to_num(feat, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
        for name in _NON_NEGATIVE_FEATURES:
            idx = _FEATURE_INDEX.get(name)
            if idx is not None:
                feat[idx] = max(feat[idx], 0.0)
        season_idx = _FEATURE_INDEX.get("season_progress")
        if season_idx is not None:
            feat[season_idx] = float(np.clip(feat[season_idx], 0.0, 1.0))

    return feat, h2h_source


def build_tracking_state(
    df_past: pd.DataFrame,
    cutoff_date: Optional[pd.Timestamp] = None,
    competition_code: Optional[str] = None,
    strict_competition: bool = _STRICT_COMPETITION_DEFAULT,
) -> Tuple[TeamHistoryTracker, EloSystem]:
    if df_past is None or df_past.empty:
        tracker = TeamHistoryTracker(strict_competition=strict_competition)
        elo_system = EloSystem()
        return tracker, elo_system

    comp_norm = _normalize_competition_code(competition_code)

    df_source = df_past
    if comp_norm is not None and "competition_code" in df_past.columns:
        specific = df_past[df_past["competition_code"] == comp_norm]
        if not specific.empty:
            df_source = specific

    if cutoff_date is not None and "date_parsed" in df_source.columns:
        df_for_defaults = df_source[df_source["date_parsed"] < cutoff_date]
    else:
        df_for_defaults = df_source

    if df_for_defaults.empty:
        dgf = _LEAGUE_DEFAULT_GF
        dpts = _LEAGUE_DEFAULT_PTS
    else:
        dgf, dpts, _ = compute_league_defaults(df_for_defaults, comp_norm)

    tracker = TeamHistoryTracker(
        default_gf=dgf,
        default_ga=dgf,
        default_pts=dpts,
        strict_competition=strict_competition,
    )
    elo_system = EloSystem()

    if "date_parsed" in df_source.columns:
        df_sorted = df_source.sort_values("date_parsed", kind="mergesort")
    else:
        df_sorted = df_source

    if cutoff_date is not None and "date_parsed" in df_sorted.columns:
        df_sorted = df_sorted[df_sorted["date_parsed"] < cutoff_date]

    for row in df_sorted.itertuples(index=False):
        home = getattr(row, "home_key", None)
        away = getattr(row, "away_key", None)
        gh = getattr(row, "goals_home", None)
        ga = getattr(row, "goals_away", None)
        if home is None or away is None:
            continue
        gh_i = _safe_goals_or_none(gh)
        ga_i = _safe_goals_or_none(ga)
        if gh_i is None or ga_i is None:
            continue
        match_date = getattr(row, "date_parsed", None)
        comp_code = _normalize_competition_code(
            getattr(row, "competition_code", None)
        )
        ht_home = _safe_goals_or_none(getattr(row, "ht_home", None))
        ht_away = _safe_goals_or_none(getattr(row, "ht_away", None))
        tracker.record(
            home, away, gh_i, ga_i, match_date, comp_code,
            ht_home=ht_home, ht_away=ht_away,
        )
        elo_system.update(home, away, gh_i, ga_i, comp_code)
    return tracker, elo_system


def create_features_with_context(
    df_past: pd.DataFrame,
    strict_competition: bool = _STRICT_COMPETITION_DEFAULT,
) -> Tuple[
    np.ndarray,
    np.ndarray,
    List[str],
    List[str],
    List[int],
    List[int],
    List[Optional[str]],
    List[str],
]:
    empty_return: Tuple[
        np.ndarray, np.ndarray, List[str], List[str], List[int], List[int],
        List[Optional[str]], List[str]
    ] = (
        np.zeros((0, EXPECTED_FEATURE_COUNT)),
        np.zeros((0,), dtype=np.int64),
        [], [], [], [], [], [],
    )
    if df_past is None or df_past.empty:
        return empty_return

    if "date_parsed" in df_past.columns:
        df_sorted = df_past.sort_values("date_parsed", kind="mergesort").reset_index(drop=True)
    else:
        df_sorted = df_past.reset_index(drop=True)

    n_total = len(df_sorted)
    if n_total == 0:
        return empty_return

    warmup_count = max(1, int(n_total * _WARMUP_RATIO))
    warmup_count = min(warmup_count, max(0, n_total - 1))

    if warmup_count > 0:
        df_warmup = df_sorted.iloc[:warmup_count]
        dgf, dpts, _ = compute_league_defaults(df_warmup)
    else:
        dgf, dpts = _LEAGUE_DEFAULT_GF, _LEAGUE_DEFAULT_PTS

    tracker = TeamHistoryTracker(
        default_gf=dgf,
        default_ga=dgf,
        default_pts=dpts,
        strict_competition=strict_competition,
    )
    elo_system = EloSystem()
    feature_rows: List[np.ndarray] = []
    labels: List[int] = []
    home_keys: List[str] = []
    away_keys: List[str] = []
    goals_home_list: List[int] = []
    goals_away_list: List[int] = []
    comp_codes: List[Optional[str]] = []
    h2h_sources: List[str] = []
    skip_counters: Counter = Counter()

    for row in df_sorted.itertuples(index=False):
        home = getattr(row, "home_key", None)
        away = getattr(row, "away_key", None)
        gh = getattr(row, "goals_home", None)
        ga = getattr(row, "goals_away", None)
        if home is None or away is None:
            skip_counters["missing_team_key"] += 1
            continue
        gh_i = _safe_goals_or_none(gh)
        ga_i = _safe_goals_or_none(ga)
        if gh_i is None or ga_i is None:
            skip_counters["invalid_goals"] += 1
            continue
        match_date = getattr(row, "date_parsed", None)
        if match_date is None or pd.isna(match_date):
            skip_counters["invalid_date"] += 1
            continue
        comp_code = _normalize_competition_code(getattr(row, "competition_code", None))

        feat, h2h_source = build_feature_vector(
            home, away, tracker, elo_system, match_date, comp_code
        )
        if feat.shape[0] != EXPECTED_FEATURE_COUNT:
            skip_counters["wrong_feature_length"] += 1
            continue

        feature_rows.append(feat)
        if gh_i > ga_i:
            labels.append(0)
        elif gh_i == ga_i:
            labels.append(1)
        else:
            labels.append(2)
        home_keys.append(home)
        away_keys.append(away)
        goals_home_list.append(gh_i)
        goals_away_list.append(ga_i)
        comp_codes.append(comp_code)
        h2h_sources.append(h2h_source)

        ht_home = _safe_goals_or_none(getattr(row, "ht_home", None))
        ht_away = _safe_goals_or_none(getattr(row, "ht_away", None))
        tracker.record(
            home, away, gh_i, ga_i, match_date, comp_code,
            ht_home=ht_home, ht_away=ht_away,
        )
        elo_system.update(home, away, gh_i, ga_i, comp_code)

    if skip_counters:
        logger.info(
            "create_features_with_context : %d exemples générés, rejets : %s",
            len(feature_rows), dict(skip_counters),
        )

    if not feature_rows:
        return empty_return

    X = np.array(feature_rows, dtype=np.float64)
    y = np.array(labels, dtype=np.int64)

    if X.shape[0] != len(y) or X.shape[0] != len(home_keys) or X.shape[0] != len(away_keys):
        logger.error(
            "Incohérence de longueurs : X=%d, y=%d, home=%d, away=%d",
            X.shape[0], len(y), len(home_keys), len(away_keys),
        )
        return empty_return
    if X.shape[0] != len(goals_home_list) or X.shape[0] != len(goals_away_list):
        logger.error(
            "Incohérence de longueurs : X=%d, gh=%d, ga=%d",
            X.shape[0], len(goals_home_list), len(goals_away_list),
        )
        return empty_return
    if X.shape[0] != len(comp_codes) or X.shape[0] != len(h2h_sources):
        logger.error(
            "Incohérence de longueurs : X=%d, comp=%d, h2h=%d",
            X.shape[0], len(comp_codes), len(h2h_sources),
        )
        return empty_return
    if X.shape[1] != EXPECTED_FEATURE_COUNT:
        logger.error(
            "Nombre de features incohérent : %d != %d",
            X.shape[1], EXPECTED_FEATURE_COUNT,
        )
        return empty_return

    return (
        X, y, home_keys, away_keys,
        goals_home_list, goals_away_list, comp_codes, h2h_sources,
    )


if nn is not None:
    class _TorchNet(nn.Module):
        def __init__(
            self,
            input_dim: int,
            hidden_size: int = DL_HIDDEN_SIZE,
            output_dim: int = 3,
            dropout: float = DL_DROPOUT,
        ):
            super().__init__()
            self.input_dim = int(input_dim)
            h = max(8, int(hidden_size))
            h2 = max(4, h // 2)
            self.net = nn.Sequential(
                nn.Linear(input_dim, h),
                nn.LayerNorm(h),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(h, h2),
                nn.LayerNorm(h2),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(h2, output_dim),
            )

        def forward(self, x):
            return self.net(x)
else:
    _TorchNet = None


if torch is not None and nn is not None:
    class _TorchProbaWrapper:
        def __init__(self, model: Any):
            self.model = model
            self.classes_ = np.array([0, 1, 2])
            self._estimator_type = "classifier"
            n_features: Optional[int] = None
            try:
                first_linear = None
                for module in model.net:
                    if isinstance(module, nn.Linear):
                        first_linear = module
                        break
                if first_linear is not None:
                    n_features = int(first_linear.in_features)
            except Exception:
                n_features = None
            if n_features is None:
                n_features = int(getattr(model, "input_dim", 1))
            self.n_features_in_ = n_features

        def get_params(self, deep: bool = True) -> Dict[str, Any]:
            return {"model": self.model}

        def set_params(self, **params: Any) -> "_TorchProbaWrapper":
            if "model" in params:
                self.model = params["model"]
            return self

        def fit(self, X: Any, y: Any) -> "_TorchProbaWrapper":
            return self

        def __sklearn_is_fitted__(self) -> bool:
            return True

        def predict_proba(self, X: Any) -> np.ndarray:
            self.model.eval()
            with torch.no_grad():
                tensor = torch.FloatTensor(np.asarray(X, dtype=np.float32))
                logits = self.model(tensor)
                return torch.softmax(logits, dim=1).numpy()

        def predict(self, X: Any) -> np.ndarray:
            return np.argmax(self.predict_proba(X), axis=1)

    class _TorchTemperatureWrapper:
        def __init__(self, model: Any, temperature: float = 1.0):
            self.model = model
            if not np.isfinite(temperature) or temperature <= 0:
                temperature = 1.0
            self.temperature = float(temperature)
            self.classes_ = np.array([0, 1, 2])
            self._estimator_type = "classifier"
            n_features: Optional[int] = None
            try:
                first_linear = None
                for module in model.net:
                    if isinstance(module, nn.Linear):
                        first_linear = module
                        break
                if first_linear is not None:
                    n_features = int(first_linear.in_features)
            except Exception:
                n_features = None
            if n_features is None:
                n_features = int(getattr(model, "input_dim", 1))
            self.n_features_in_ = n_features

        def get_params(self, deep: bool = True) -> Dict[str, Any]:
            return {"model": self.model, "temperature": self.temperature}

        def set_params(self, **params: Any) -> "_TorchTemperatureWrapper":
            if "model" in params:
                self.model = params["model"]
            if "temperature" in params:
                self.temperature = params["temperature"]
            return self

        def fit(self, X: Any, y: Any) -> "_TorchTemperatureWrapper":
            return self

        def __sklearn_is_fitted__(self) -> bool:
            return True

        def predict_proba(self, X: Any) -> np.ndarray:
            self.model.eval()
            with torch.no_grad():
                tensor = torch.FloatTensor(np.asarray(X, dtype=np.float32))
                logits = self.model(tensor)
                if abs(self.temperature - 1.0) > 1e-6:
                    logits = logits / self.temperature
                return torch.softmax(logits, dim=1).numpy()

        def predict(self, X: Any) -> np.ndarray:
            return np.argmax(self.predict_proba(X), axis=1)
else:
    _TorchProbaWrapper = None
    _TorchTemperatureWrapper = None


def _fit_pb_model(
    class_name: str,
    gh: List[int],
    ga: List[int],
    th: List[str],
    ta: List[str],
) -> Tuple[str, Any]:
    cls = _PB_MODEL_CLASSES[class_name]
    try:
        m = cls(gh, ga, th, ta)
        m.fit()
        return "ok", m
    except Exception as exc:
        return "error", str(exc)


def _calibrate_or_keep(
    name: str,
    base_model: Any,
    X_calib: np.ndarray,
    y_calib: np.ndarray,
) -> Tuple[Any, str]:
    if X_calib is None or X_calib.shape[0] == 0:
        logger.warning("%s : set de calibration vide, non calibré conservé", name)
        return base_model, _CALIBRATION_STATUS_SKIPPED_SMALL

    if name == "DL" and _TorchProbaWrapper is not None:
        wrapped: Any = _TorchProbaWrapper(base_model)
    else:
        wrapped = base_model

    if X_calib.shape[0] < CALIBRATION_MIN_VAL_SAMPLES:
        logger.warning(
            "%s : set de calibration trop petit (%d) pour calibrer, non calibré conservé",
            name, X_calib.shape[0],
        )
        return wrapped, _CALIBRATION_STATUS_SKIPPED_SMALL

    unique_classes = np.unique(y_calib)
    if len(unique_classes) < _MIN_CLASSES_FOR_TRAINING:
        logger.warning(
            "%s : calibration ne contient que %s classes, calibration ignorée",
            name, unique_classes.tolist(),
        )
        return wrapped, _CALIBRATION_STATUS_SKIPPED_CLASSES

    if name == "DL" and _TorchTemperatureWrapper is not None:
        try:
            raw_proba = wrapped.predict_proba(X_calib)
            if raw_proba.shape[1] != 3:
                raise ValueError("DL raw proba shape invalide")
            best_t = 1.0
            best_ll = float("inf")
            for t in np.linspace(
                _DL_TEMPERATURE_GRID_MIN,
                _DL_TEMPERATURE_GRID_MAX,
                _DL_TEMPERATURE_GRID_STEPS,
            ):
                if t <= 0:
                    continue
                logits = np.log(np.clip(raw_proba, _EPS, 1.0)) / float(t)
                logits -= logits.max(axis=1, keepdims=True)
                exp_logits = np.exp(logits)
                scaled = exp_logits / exp_logits.sum(axis=1, keepdims=True)
                try:
                    ll = float(log_loss(y_calib, scaled, labels=[0, 1, 2]))
                except Exception:
                    continue
                if ll < best_ll:
                    best_ll = ll
                    best_t = float(t)
            scaled_wrapper = _TorchTemperatureWrapper(base_model, best_t)
            return scaled_wrapper, _CALIBRATION_STATUS_TEMPERATURE
        except Exception as exc:
            logger.warning(
                "DL : calibration température échouée : %s: %s",
                type(exc).__name__, exc,
            )
            return wrapped, _CALIBRATION_STATUS_FAILED

    if FrozenEstimator is not None:
        try:
            calibrated = CalibratedClassifierCV(
                FrozenEstimator(wrapped), method=CALIBRATION_METHOD
            )
            calibrated.fit(X_calib, y_calib)
            return calibrated, _CALIBRATION_STATUS_OK
        except Exception as exc:
            logger.warning(
                "%s : calibration FrozenEstimator échouée : %s: %s",
                name, type(exc).__name__, exc,
            )

    try:
        calibrated = CalibratedClassifierCV(
            wrapped, method=CALIBRATION_METHOD, cv="prefit"
        )
        calibrated.fit(X_calib, y_calib)
        return calibrated, _CALIBRATION_STATUS_OK
    except Exception as exc:
        logger.error(
            "%s : calibration échouée : %s: %s",
            name, type(exc).__name__, exc,
        )
        return wrapped, _CALIBRATION_STATUS_FAILED


def _extract_model_probabilities(grid: Any) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    try:
        hda = np.array(grid.home_draw_away, dtype=np.float64)
        if hda.shape == (3,) and np.all(np.isfinite(hda)) and hda.sum() > 0:
            result["home_draw_away"] = (hda / hda.sum()).tolist()
    except Exception:
        pass
    for line, key in ((1.5, "over15"), (2.5, "over25")):
        val = None
        try:
            val = float(grid.total_goals("over", line))
        except Exception:
            try:
                _, _, over_val = grid.totals(line)
                val = float(over_val)
            except Exception:
                try:
                    attr_name = f"over_{str(line).replace('.', '')}"
                    val = float(getattr(grid, attr_name))
                except Exception:
                    val = None
        if val is not None and np.isfinite(val):
            result[key] = float(np.clip(val, 0.0, 1.0))
    try:
        btts = float(grid.btts_yes)
        if np.isfinite(btts):
            result["btts_yes"] = float(np.clip(btts, 0.0, 1.0))
    except Exception:
        pass
    try:
        home_expected = float(np.ravel(grid.home_goal_expectation)[0])
        away_expected = float(np.ravel(grid.away_goal_expectation)[0])
        if np.isfinite(home_expected) and np.isfinite(away_expected):
            result["expected_home_goals"] = home_expected
            result["expected_away_goals"] = away_expected
            result["home_xg"] = home_expected
            result["away_xg"] = away_expected
            result["xg_source"] = _XG_MODEL_SOURCE_TAG
            result["xg_is_official"] = False
    except Exception:
        pass
    return result


_extract_market_probabilities = _extract_model_probabilities


def _walk_forward_splits(
    n_samples: int,
    n_folds: int,
    initial_train_ratio: float = 0.40,
) -> List[Tuple[int, int]]:
    if n_samples < 200 or n_folds < 2:
        cut = max(1, int(n_samples * (1.0 - MODEL_TRAIN_TEST_SPLIT)))
        cut = min(cut, n_samples - 1)
        return [(cut, n_samples)]
    initial_train = max(int(n_samples * initial_train_ratio), 100)
    initial_train = min(initial_train, n_samples - n_folds * 10)
    if initial_train < 50:
        initial_train = max(50, n_samples // 3)
    remaining = n_samples - initial_train
    fold_size = max(remaining // n_folds, 10)
    splits: List[Tuple[int, int]] = []
    for i in range(n_folds):
        train_end = initial_train + i * fold_size
        val_end = train_end + fold_size
        if i == n_folds - 1:
            val_end = n_samples
        train_end = min(train_end, n_samples - 1)
        val_end = min(val_end, n_samples)
        if val_end - train_end < 5:
            continue
        splits.append((train_end, val_end))
    if not splits:
        cut = max(1, int(n_samples * 0.80))
        cut = min(cut, n_samples - 1)
        splits.append((cut, n_samples))
    return splits


def _evaluate_ml_model_walk_forward(
    factory: Callable[[], Any],
    X_raw: np.ndarray,
    y: np.ndarray,
    n_folds: int,
) -> float:
    splits = _walk_forward_splits(len(X_raw), n_folds)
    log_losses: List[float] = []
    for train_end, val_end in splits:
        try:
            fold_scaler = StandardScaler()
            X_tr = fold_scaler.fit_transform(X_raw[:train_end])
            X_va = fold_scaler.transform(X_raw[train_end:val_end])
            y_tr = y[:train_end]
            y_va = y[train_end:val_end]
            if len(np.unique(y_va)) < 2 or len(np.unique(y_tr)) < 2:
                continue
            m = factory()
            m.fit(X_tr, y_tr)
            proba = m.predict_proba(X_va)
            if not _proba_array_is_valid(proba):
                continue
            ll = log_loss(y_va, proba, labels=[0, 1, 2])
            log_losses.append(float(ll))
        except Exception as exc:
            logger.debug("Walk-forward fold échoué : %s", exc)
            continue
    if not log_losses:
        return float("inf")
    return float(np.mean(log_losses))


def _evaluate_dl_walk_forward(
    X_raw: np.ndarray,
    y: np.ndarray,
    n_folds: int,
    input_dim: int,
) -> float:
    if torch is None or nn is None or _TorchNet is None:
        return float("inf")
    if X_raw.shape[0] < 200 or n_folds < 2:
        return float("inf")

    splits = _walk_forward_splits(len(X_raw), n_folds)
    log_losses: List[float] = []

    for train_end, val_end in splits:
        try:
            fold_scaler = StandardScaler()
            X_tr = fold_scaler.fit_transform(X_raw[:train_end])
            X_va = fold_scaler.transform(X_raw[train_end:val_end])
            y_tr = y[:train_end]
            y_va = y[train_end:val_end]

            if len(np.unique(y_tr)) < _MIN_CLASSES_FOR_TRAINING:
                continue
            if X_va.shape[0] < 5:
                continue

            torch.manual_seed(MODEL_RANDOM_SEED)
            np.random.seed(MODEL_RANDOM_SEED)

            fold_model = _TorchNet(input_dim)
            opt = torch.optim.AdamW(
                fold_model.parameters(),
                lr=DL_LEARNING_RATE,
                weight_decay=DL_WEIGHT_DECAY,
            )
            crit = nn.CrossEntropyLoss()
            Xt = torch.FloatTensor(X_tr)
            yt = torch.LongTensor(y_tr)
            Xv = torch.FloatTensor(X_va)
            yv = torch.LongTensor(y_va)

            use_drop_last = len(Xt) > DL_BATCH_SIZE
            loader = DataLoader(
                TensorDataset(Xt, yt),
                batch_size=DL_BATCH_SIZE,
                shuffle=True,
                drop_last=use_drop_last,
            )

            best_val_loss = float("inf")
            best_state = None
            patience_counter = 0
            epochs_no_early_stop = max(5, DL_EPOCHS // 4)

            for _ in range(epochs_no_early_stop):
                fold_model.train()
                for bx, by in loader:
                    opt.zero_grad()
                    loss = crit(fold_model(bx), by)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(
                        fold_model.parameters(), DL_GRAD_CLIP
                    )
                    opt.step()
                fold_model.eval()
                with torch.no_grad():
                    val_logits = fold_model(Xv)
                    val_loss = crit(val_logits, yv).item()
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    best_state = {
                        k: v.clone() for k, v in fold_model.state_dict().items()
                    }
                    patience_counter = 0
                else:
                    patience_counter += 1
                    if patience_counter >= DL_EARLY_STOPPING_PATIENCE:
                        break

            if best_state is not None:
                fold_model.load_state_dict(best_state)

            fold_model.eval()
            with torch.no_grad():
                proba = torch.softmax(fold_model(Xv), dim=1).numpy()

            if not _proba_array_is_valid(proba):
                continue

            ll = log_loss(y_va, proba, labels=[0, 1, 2])
            log_losses.append(float(ll))
        except Exception as exc:
            logger.debug("DL walk-forward fold échoué : %s", exc)
            continue

    if not log_losses:
        return float("inf")
    return float(np.mean(log_losses))


def _evaluate_pb_model_walk_forward(
    class_name: str,
    gh: List[int],
    ga: List[int],
    th: List[str],
    ta: List[str],
    n_folds: int,
) -> float:
    n_samples = len(gh)
    if n_samples < max(200, _PB_WF_MIN_TRAIN_SAMPLES) or n_folds < 2:
        return float("inf")

    splits = _walk_forward_splits(n_samples, n_folds)
    log_losses: List[float] = []

    for train_end, val_end in splits:
        if train_end < _PB_WF_MIN_TRAIN_SAMPLES:
            continue
        if (val_end - train_end) < _PB_WF_MIN_VAL_SAMPLES:
            continue
        try:
            gh_tr = gh[:train_end]
            ga_tr = ga[:train_end]
            th_tr = th[:train_end]
            ta_tr = ta[:train_end]

            gh_va = gh[train_end:val_end]
            ga_va = ga[train_end:val_end]
            th_va = th[train_end:val_end]
            ta_va = ta[train_end:val_end]

            y_va = []
            for h_g, a_g in zip(gh_va, ga_va):
                if h_g > a_g:
                    y_va.append(0)
                elif h_g == a_g:
                    y_va.append(1)
                else:
                    y_va.append(2)

            if len(np.unique(y_va)) < 2:
                continue

            status, m = _fit_pb_model(class_name, gh_tr, ga_tr, th_tr, ta_tr)
            if status != "ok":
                continue

            probas: List[List[float]] = []
            y_kept: List[int] = []
            for h, a, yv in zip(th_va, ta_va, y_va):
                try:
                    grid = m.predict(h, a)
                    markets = _extract_model_probabilities(grid)
                    hda = markets.get("home_draw_away")
                    if hda is None or len(hda) != 3:
                        continue
                    probas.append(hda)
                    y_kept.append(yv)
                except Exception:
                    continue

            if len(probas) < _PB_WF_MIN_VAL_SAMPLES:
                continue

            probas_arr = np.array(probas, dtype=np.float64)
            y_arr = np.array(y_kept, dtype=np.int64)
            if not _proba_array_is_valid(probas_arr):
                continue
            if len(np.unique(y_arr)) < 2:
                continue

            ll = log_loss(y_arr, probas_arr, labels=[0, 1, 2])
            log_losses.append(float(ll))
        except Exception as exc:
            logger.debug("PB walk-forward fold échoué : %s", exc)
            continue

    if not log_losses:
        return float("inf")
    return float(np.mean(log_losses))


def _make_xgb_factory() -> Callable[[], Any]:
    n_jobs = MODEL_N_JOBS if MODEL_N_JOBS != 0 else 1
    def factory() -> Any:
        return XGBClassifier(
            n_estimators=XGB_N_ESTIMATORS,
            max_depth=XGB_MAX_DEPTH,
            learning_rate=XGB_LEARNING_RATE,
            random_state=MODEL_RANDOM_SEED,
            eval_metric="mlogloss",
            objective="multi:softprob",
            num_class=3,
            n_jobs=n_jobs,
            subsample=XGB_SUBSAMPLE,
            colsample_bytree=XGB_COLSAMPLE,
            min_child_weight=XGB_MIN_CHILD_WEIGHT,
            reg_lambda=XGB_REG_LAMBDA,
            reg_alpha=XGB_REG_ALPHA,
            tree_method="hist",
        )
    return factory


def _make_lgbm_factory() -> Callable[[], Any]:
    n_jobs = MODEL_N_JOBS if MODEL_N_JOBS != 0 else 1
    def factory() -> Any:
        return LGBMClassifier(
            n_estimators=LGBM_N_ESTIMATORS,
            max_depth=LGBM_MAX_DEPTH,
            learning_rate=LGBM_LEARNING_RATE,
            num_leaves=LGBM_NUM_LEAVES,
            min_child_samples=LGBM_MIN_CHILD_SAMPLES,
            subsample=LGBM_SUBSAMPLE,
            colsample_bytree=LGBM_COLSAMPLE,
            reg_lambda=LGBM_REG_LAMBDA,
            random_state=MODEL_RANDOM_SEED,
            verbose=-1,
            objective="multiclass",
            num_class=3,
            n_jobs=n_jobs,
        )
    return factory


def _make_catboost_factory() -> Callable[[], Any]:
    thread_count = MODEL_N_JOBS if MODEL_N_JOBS > 0 else -1
    def factory() -> Any:
        return CatBoostClassifier(
            iterations=CATBOOST_ITERATIONS,
            depth=CATBOOST_DEPTH,
            learning_rate=CATBOOST_LEARNING_RATE,
            l2_leaf_reg=CATBOOST_L2_LEAF_REG,
            random_strength=CATBOOST_RANDOM_STRENGTH,
            random_state=MODEL_RANDOM_SEED,
            verbose=False,
            loss_function="MultiClass",
            classes_count=3,
            thread_count=thread_count,
            allow_writing_files=False,
        )
    return factory


def _make_rf_factory() -> Callable[[], Any]:
    n_jobs = MODEL_N_JOBS if MODEL_N_JOBS != 0 else 1
    max_features: Any = RF_MAX_FEATURES_RESOLVED
    def factory() -> Any:
        return RandomForestClassifier(
            n_estimators=RF_N_ESTIMATORS,
            max_depth=RF_MAX_DEPTH,
            min_samples_leaf=RF_MIN_SAMPLES_LEAF,
            min_samples_split=RF_MIN_SAMPLES_SPLIT,
            max_features=max_features,
            random_state=MODEL_RANDOM_SEED,
            n_jobs=n_jobs,
            class_weight="balanced_subsample",
        )
    return factory


def _compute_optimal_temperature(
    probas: np.ndarray,
    y_true: np.ndarray,
) -> float:
    if probas.shape[0] < 50:
        return float(TEMPERATURE_SCALING_DEFAULT)
    best_t = float(TEMPERATURE_SCALING_DEFAULT)
    best_ll = float("inf")
    lo = float(TEMPERATURE_SCALING_MIN)
    hi = float(TEMPERATURE_SCALING_MAX)
    for t in np.linspace(lo, hi, 17):
        if t <= 0:
            continue
        logits = np.log(np.clip(probas, _EPS, 1.0)) / t
        logits -= logits.max(axis=1, keepdims=True)
        exp_logits = np.exp(logits)
        softmax = exp_logits / exp_logits.sum(axis=1, keepdims=True)
        try:
            ll = log_loss(y_true, softmax, labels=[0, 1, 2])
        except Exception:
            continue
        if ll < best_ll:
            best_ll = float(ll)
            best_t = float(t)
    return best_t


def _compute_ensemble_probas(
    ml_models: Dict[str, Any],
    pb_models: List[Tuple[str, Any]],
    Xs_set: np.ndarray,
    home_keys_set: List[str],
    away_keys_set: List[str],
    weights: Dict[str, float],
) -> Optional[np.ndarray]:
    if Xs_set.shape[0] == 0:
        return None
    hda_list: List[np.ndarray] = []
    w_list: List[float] = []

    for name, model in ml_models.items():
        try:
            proba = model.predict_proba(Xs_set)
            w = float(weights.get(name, 0.0))
            if w > 0 and proba.shape[1] == 3:
                hda_list.append(proba)
                w_list.append(w)
        except Exception:
            continue

    for i, (class_name, model) in enumerate(pb_models):
        w = float(weights.get(f"pb_{i}", 0.0))
        if w <= 0:
            continue
        probas: List[List[float]] = []
        try:
            for h, a in zip(home_keys_set, away_keys_set):
                grid = model.predict(h, a)
                markets = _extract_model_probabilities(grid)
                hda = markets.get("home_draw_away")
                if hda is None:
                    raise ValueError("home_draw_away indisponible")
                probas.append(hda)
            probas_arr = np.array(probas, dtype=np.float64)
            if probas_arr.shape == (Xs_set.shape[0], 3):
                hda_list.append(probas_arr)
                w_list.append(w)
        except Exception:
            continue

    if not hda_list:
        return None

    w_arr = np.array(w_list, dtype=np.float64)
    if w_arr.sum() <= 0:
        w_arr = np.ones_like(w_arr)
    w_arr = w_arr / w_arr.sum()

    stacked = np.stack(hda_list, axis=0)
    blended = np.tensordot(w_arr, stacked, axes=(0, 0))
    blended = np.clip(blended, _EPS, 1.0)
    blended = blended / blended.sum(axis=1, keepdims=True)
    return blended


def _evaluate_ensemble_on_set(
    ml_models: Dict[str, Any],
    pb_models: List[Tuple[str, Any]],
    Xs_set: np.ndarray,
    y_set: np.ndarray,
    home_keys_set: List[str],
    away_keys_set: List[str],
    weights: Dict[str, float],
    temperature: float,
) -> Optional[Tuple[float, float]]:
    if Xs_set.shape[0] == 0 or y_set.shape[0] == 0:
        return None
    blended = _compute_ensemble_probas(
        ml_models, pb_models, Xs_set, home_keys_set, away_keys_set, weights
    )
    if blended is None:
        return None
    if (
        temperature is not None
        and np.isfinite(temperature)
        and temperature > 0
        and abs(temperature - 1.0) > 1e-6
    ):
        logits = np.log(np.clip(blended, _EPS, 1.0)) / float(temperature)
        logits -= logits.max(axis=1, keepdims=True)
        exp_logits = np.exp(logits)
        blended = exp_logits / exp_logits.sum(axis=1, keepdims=True)
    try:
        ll = log_loss(y_set, blended, labels=[0, 1, 2])
    except Exception:
        return None
    acc = float((blended.argmax(axis=1) == y_set).mean())
    return (float(ll), acc)


def _normalize_weights(
    weights: Dict[str, float],
    min_w: float,
    max_w: float,
) -> Dict[str, float]:
    keys = [k for k in weights.keys() if not k.startswith("__")]
    if not keys:
        return weights

    zero_keys = set()
    for k in keys:
        try:
            v = float(weights[k])
        except (TypeError, ValueError):
            v = 0.0
        if not np.isfinite(v) or v <= 0.0:
            zero_keys.add(k)

    positive_keys = [k for k in keys if k not in zero_keys]
    if not positive_keys:
        return weights

    n_positive = len(positive_keys)
    effective_min_w = float(min_w)
    if effective_min_w * n_positive > 1.0:
        logger.warning(
            "ENSEMBLE_MIN_WEIGHT trop élevé pour %d modèles positifs ; ajusté à %.4f",
            n_positive, 1.0 / n_positive,
        )
        effective_min_w = 1.0 / n_positive

    effective_max_w = float(max_w)
    if effective_max_w < effective_min_w:
        effective_max_w = max(effective_min_w, 1.0 / n_positive)

    vals: Dict[str, float] = {}
    for k in positive_keys:
        try:
            v = float(weights[k])
        except (TypeError, ValueError):
            v = 0.0
        if not np.isfinite(v) or v <= 0:
            v = 0.0
        vals[k] = v

    if effective_min_w > 0.0:
        for k in positive_keys:
            if vals[k] < effective_min_w:
                vals[k] = effective_min_w

    total = sum(vals.values())
    if total <= 0:
        uniform = 1.0 / n_positive
        for k in positive_keys:
            vals[k] = uniform
    else:
        for k in positive_keys:
            vals[k] = vals[k] / total

    if 0.0 < effective_max_w < 1.0:
        for _ in range(200):
            over = [k for k in positive_keys if vals[k] > effective_max_w + 1e-12]
            if not over:
                break
            under = [k for k in positive_keys if k not in over]
            capped_sum = len(over) * effective_max_w
            if capped_sum >= 1.0 - 1e-12:
                uniform = 1.0 / n_positive
                for k in positive_keys:
                    vals[k] = uniform
                break
            remaining = 1.0 - capped_sum
            under_sum = sum(vals[k] for k in under)
            if under_sum <= 1e-12:
                if under:
                    share = remaining / len(under)
                    for k in under:
                        vals[k] = share
                for k in over:
                    vals[k] = effective_max_w
                break
            for k in over:
                vals[k] = effective_max_w
            for k in under:
                vals[k] = vals[k] / under_sum * remaining

        total = sum(vals.values())
        if total > 0:
            for k in positive_keys:
                vals[k] = vals[k] / total

    if effective_min_w > 0.0:
        deficit_fixed = False
        for _ in range(200):
            under = [
                k for k in positive_keys
                if vals[k] < effective_min_w - 1e-12
            ]
            if not under:
                deficit_fixed = True
                break
            over = [
                k for k in positive_keys
                if k not in under and vals[k] > effective_min_w + 1e-12
            ]
            deficit = sum(effective_min_w - vals[k] for k in under)
            over_excess = sum(vals[k] - effective_min_w for k in over)
            if over_excess <= 1e-12:
                break
            for k in under:
                vals[k] = effective_min_w
            for k in over:
                vals[k] = vals[k] - (vals[k] - effective_min_w) / over_excess * deficit
        if not deficit_fixed:
            total = sum(vals.values())
            if total > 0:
                for k in positive_keys:
                    vals[k] = vals[k] / total

    for k in keys:
        if k in zero_keys:
            weights[k] = 0.0
        else:
            weights[k] = float(vals.get(k, 0.0))
    return weights


def _clip_outliers_signed(
    X_ref: np.ndarray,
    X_apply_list: List[np.ndarray],
    z_limit: float,
) -> Tuple[np.ndarray, List[np.ndarray]]:
    if z_limit <= 0 or X_ref.size == 0:
        return X_ref, X_apply_list

    mean = X_ref.mean(axis=0)
    std = X_ref.std(axis=0)
    std[std == 0] = 1.0

    lower = mean - z_limit * std
    upper = mean + z_limit * std

    clipped_ref = np.clip(X_ref, lower, upper)
    clipped_apply = [np.clip(X, lower, upper) for X in X_apply_list]
    return clipped_ref, clipped_apply


def _proba_array_is_valid(proba: Any) -> bool:
    if proba is None:
        return False
    try:
        arr = np.asarray(proba, dtype=np.float64)
    except Exception:
        return False
    if arr.ndim != 2:
        return False
    if arr.shape[1] != 3:
        return False
    if arr.shape[0] == 0:
        return False
    if not np.all(np.isfinite(arr)):
        return False
    if np.any(arr < 0.0):
        return False
    if np.any(arr > 1.0 + _PROBA_ATOL):
        return False
    row_sums = arr.sum(axis=1)
    if not np.allclose(row_sums, 1.0, atol=_PROBA_ATOL):
        return False
    return True


def _model_produces_three_classes(
    model: Any,
    X_probe: np.ndarray,
) -> bool:
    if X_probe is None or X_probe.shape[0] == 0:
        return False
    try:
        proba = model.predict_proba(X_probe[:1])
    except Exception:
        return False
    return _proba_array_is_valid(proba)


def _filter_valid_weights(
    weights: Dict[str, float],
) -> Dict[str, float]:
    filtered: Dict[str, float] = {}
    for k, v in weights.items():
        if k.startswith("__"):
            filtered[k] = v
            continue
        try:
            fv = float(v)
        except (TypeError, ValueError):
            continue
        if np.isfinite(fv) and fv > 0.0:
            filtered[k] = fv
    return filtered


def _select_fallback_uniform_models(
    ml_models: Dict[str, Any],
    pb_models: List[Tuple[str, Any]],
    wf_ll_by_key: Dict[str, float],
) -> List[str]:
    valid_keys: List[str] = []
    for k, ll in wf_ll_by_key.items():
        try:
            ll_f = float(ll)
        except (TypeError, ValueError):
            continue
        if not np.isfinite(ll_f) or ll_f <= 0:
            continue
        if ll_f > _MAX_ACCEPTABLE_LOGLOSS:
            continue
        if k in ml_models:
            valid_keys.append(k)
        elif k.startswith("pb_"):
            try:
                idx = int(k.split("_", 1)[1])
            except (ValueError, IndexError):
                continue
            if 0 <= idx < len(pb_models):
                valid_keys.append(k)
    return valid_keys


def _apply_quality_filter_on_weights(
    weights: Dict[str, float],
    wf_ll_by_key: Dict[str, float],
) -> Dict[str, float]:
    valid_lls: List[float] = []
    for k in weights.keys():
        if k.startswith("__"):
            continue
        ll = wf_ll_by_key.get(k, None)
        if ll is None:
            continue
        try:
            ll_f = float(ll)
        except (TypeError, ValueError):
            continue
        if np.isfinite(ll_f) and ll_f > 0:
            valid_lls.append(ll_f)

    if not valid_lls:
        return weights

    best_ll = min(valid_lls)
    threshold = best_ll * _QUALITY_RELATIVE_THRESHOLD

    filtered: Dict[str, float] = {}
    for k, v in weights.items():
        if k.startswith("__"):
            filtered[k] = v
            continue
        ll = wf_ll_by_key.get(k, None)
        if ll is None:
            continue
        try:
            ll_f = float(ll)
        except (TypeError, ValueError):
            continue
        if not np.isfinite(ll_f) or ll_f <= 0:
            continue
        if ll_f > threshold:
            logger.info(
                "Modèle %s exclu (WF LogLoss %.4f > seuil qualité %.4f)",
                k, ll_f, threshold,
            )
            continue
        filtered[k] = v
    if not any(not k.startswith("__") for k in filtered.keys()):
        return weights
    return filtered


def _validate_splits(
    y_train: np.ndarray,
    y_val: np.ndarray,
    y_calib: np.ndarray,
    y_test: np.ndarray,
) -> bool:
    ok = True
    for label, arr in (("train", y_train), ("val", y_val), ("calib", y_calib), ("test", y_test)):
        if arr is None or arr.shape[0] == 0:
            logger.error("Split %s vide", label)
            ok = False
            continue
        if label == "train" and len(np.unique(arr)) < _MIN_CLASSES_FOR_TRAINING:
            logger.error(
                "Split %s ne contient pas les %d classes requises : %s",
                label, _MIN_CLASSES_FOR_TRAINING, np.unique(arr).tolist(),
            )
            ok = False
            continue
        if len(np.unique(arr)) < _MIN_CLASSES_FOR_TRAINING:
            logger.warning(
                "Split %s ne contient que %s classes",
                label, np.unique(arr).tolist(),
            )
    if y_test is not None and y_test.shape[0] < _MIN_TEST_SAMPLES:
        logger.warning(
            "Jeu de test trop petit (%d < %d) ; évaluation finale peu fiable",
            y_test.shape[0], _MIN_TEST_SAMPLES,
        )
    return ok


def _compute_calibration_log_loss(
    model: Any,
    X_calib: np.ndarray,
    y_calib: np.ndarray,
) -> float:
    if X_calib.shape[0] == 0:
        return float("inf")
    try:
        proba = model.predict_proba(X_calib)
        if not _proba_array_is_valid(proba):
            return float("inf")
        return float(log_loss(y_calib, proba, labels=[0, 1, 2]))
    except Exception as exc:
        logger.debug("Calibration LogLoss échouée : %s", exc)
        return float("inf")


def train_models(
    df_past: pd.DataFrame,
) -> Tuple[
    Optional[Dict[str, Any]],
    Optional[List[Tuple[str, Any]]],
    Optional[StandardScaler],
    Dict[str, float],
]:
    if df_past is None or len(df_past) < MIN_MATCHES_FOR_TRAINING:
        logger.warning(
            "Données insuffisantes pour l'entraînement : %d < %d",
            len(df_past) if df_past is not None else 0, MIN_MATCHES_FOR_TRAINING,
        )
        return None, None, None, {}

    (
        X, y, home_keys, away_keys, gh_all, ga_all, _, h2h_sources_all
    ) = create_features_with_context(
        df_past, strict_competition=_STRICT_COMPETITION_DEFAULT
    )
    if X.shape[0] < MIN_MATCHES_FOR_TRAINING or X.shape[0] != len(y):
        logger.warning("Échec de la construction des features pour l'entraînement")
        return None, None, None, {}

    if X.shape[1] != EXPECTED_FEATURE_COUNT:
        logger.error(
            "X.shape[1] = %d ≠ EXPECTED_FEATURE_COUNT = %d",
            X.shape[1], EXPECTED_FEATURE_COUNT,
        )
        return None, None, None, {}

    if not (
        X.shape[0] == len(home_keys) == len(away_keys)
        == len(gh_all) == len(ga_all) == len(h2h_sources_all) == len(y)
    ):
        logger.error("Longueurs incohérentes après construction des features")
        return None, None, None, {}

    class_counts = np.bincount(y, minlength=3)
    if np.count_nonzero(class_counts) < _MIN_CLASSES_FOR_TRAINING:
        logger.error(
            "Moins de %d classes présentes dans le dataset global : %s",
            _MIN_CLASSES_FOR_TRAINING, class_counts.tolist(),
        )
        return None, None, None, {}

    n = len(X)
    cut_train = int(n * _TRAIN_RATIO)
    cut_val = int(n * (_TRAIN_RATIO + _VAL_RATIO))
    cut_calib = int(n * (_TRAIN_RATIO + _VAL_RATIO + _CALIB_RATIO))

    cut_train = max(1, min(cut_train, n - 4))
    cut_val = max(cut_train + 1, min(cut_val, n - 3))
    cut_calib = max(cut_val + 1, min(cut_calib, n - 2))

    X_train_raw = X[:cut_train].astype(np.float64, copy=True)
    X_val_raw = X[cut_train:cut_val].astype(np.float64, copy=True)
    X_calib_raw = X[cut_val:cut_calib].astype(np.float64, copy=True)
    X_test_raw = X[cut_calib:].astype(np.float64, copy=True)

    y_train = y[:cut_train]
    y_val = y[cut_train:cut_val]
    y_calib = y[cut_val:cut_calib]
    y_test = y[cut_calib:]

    if not _validate_splits(y_train, y_val, y_calib, y_test):
        logger.error("Splits invalides ; entraînement annulé.")
        stage_print("❌ Splits d'entraînement invalides ; entraînement annulé.")
        return None, None, None, {}

    home_keys_train = home_keys[:cut_train]
    away_keys_train = away_keys[:cut_train]
    home_keys_calib = home_keys[cut_val:cut_calib]
    away_keys_calib = away_keys[cut_val:cut_calib]
    home_keys_test = home_keys[cut_calib:]
    away_keys_test = away_keys[cut_calib:]
    gh_train = gh_all[:cut_train]
    ga_train = ga_all[:cut_train]

    stage_print("🤖 ENTRAÎNEMENT")

    if FEATURE_OUTLIER_ZSCORE > 0:
        X_train_raw, [X_val_raw, X_calib_raw, X_test_raw] = _clip_outliers_signed(
            X_train_raw,
            [X_val_raw, X_calib_raw, X_test_raw],
            float(FEATURE_OUTLIER_ZSCORE),
        )

    scaler = StandardScaler()
    Xs_train = scaler.fit_transform(X_train_raw)
    Xs_val = scaler.transform(X_val_raw)
    Xs_calib = scaler.transform(X_calib_raw)
    Xs_test = scaler.transform(X_test_raw)

    ml_models: Dict[str, Any] = {}
    weights: Dict[str, float] = {}
    calib_ll_by_key: Dict[str, float] = {}
    wf_ll_by_key: Dict[str, float] = {}
    ll_source_by_key: Dict[str, str] = {}
    calibration_status_by_key: Dict[str, str] = {}

    factories: List[Tuple[str, Callable[[], Any], str]] = []
    if XGBClassifier is not None:
        factories.append(("XGB", _make_xgb_factory(), "XGBOOST"))
    if LGBMClassifier is not None:
        factories.append(("LGBM", _make_lgbm_factory(), "LIGHTGBM"))
    if CatBoostClassifier is not None:
        factories.append(("CatBoost", _make_catboost_factory(), "CATBOOST"))
    if RandomForestClassifier is not None:
        factories.append(("RF", _make_rf_factory(), "RANDOM FOREST"))

    for name, factory, display in factories:
        try:
            m = factory()
            m.fit(Xs_train, y_train)
            if not _model_produces_three_classes(m, Xs_train):
                logger.warning(
                    "%s ignoré : probabilités invalides après entraînement", name
                )
                stage_print(f"❌ {display} : probabilités invalides")
                continue

            calibrated, calib_status = _calibrate_or_keep(
                name, m, Xs_calib, y_calib
            )
            if not _model_produces_three_classes(calibrated, Xs_calib):
                calibrated = m
                calib_status = _CALIBRATION_STATUS_RAW_KEPT
            ml_models[name] = calibrated
            calibration_status_by_key[name] = calib_status

            ll_calib = _compute_calibration_log_loss(calibrated, Xs_calib, y_calib)
            calib_ll_by_key[name] = float(ll_calib)

            ll_wf = _evaluate_ml_model_walk_forward(
                factory, X_train_raw, y_train, MODEL_WALK_FORWARD_FOLDS
            )
            wf_ll_by_key[name] = float(ll_wf)
            ll_source_by_key[name] = _LL_SOURCE_WALK_FORWARD

            if np.isfinite(ll_calib):
                stage_print(f"✅ {display} : LogLoss {float(ll_calib):.4f}")
            else:
                stage_print(f"⚠️ {display} : LogLoss invalide")
        except Exception as exc:
            logger.error("%s : %s", display, exc)
            stage_print(f"❌ {display} : échec")

    if DL_ENABLED and torch is not None and nn is not None and _TorchNet is not None:
        if len(Xs_val) < _MIN_VAL_SAMPLES_FOR_DL or len(np.unique(y_val)) < 2:
            stage_print(
                "⚠️ DEEP LEARNING : données de validation insuffisantes, ignoré"
            )
        else:
            try:
                torch.manual_seed(MODEL_RANDOM_SEED)
                np.random.seed(MODEL_RANDOM_SEED)
                model = _TorchNet(Xs_train.shape[1])
                opt = torch.optim.AdamW(
                    model.parameters(), lr=DL_LEARNING_RATE, weight_decay=DL_WEIGHT_DECAY
                )
                scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                    opt, mode="min", factor=0.5, patience=5
                )
                crit = nn.CrossEntropyLoss()
                Xt = torch.FloatTensor(Xs_train)
                yt = torch.LongTensor(y_train)
                Xv = torch.FloatTensor(Xs_val)
                yv = torch.LongTensor(y_val)
                use_drop_last = len(Xt) > DL_BATCH_SIZE
                loader = DataLoader(
                    TensorDataset(Xt, yt),
                    batch_size=DL_BATCH_SIZE,
                    shuffle=True,
                    drop_last=use_drop_last,
                )
                best_val_loss = float("inf")
                best_state = None
                patience_counter = 0
                for _ in range(DL_EPOCHS):
                    model.train()
                    for bx, by in loader:
                        opt.zero_grad()
                        loss = crit(model(bx), by)
                        loss.backward()
                        torch.nn.utils.clip_grad_norm_(model.parameters(), DL_GRAD_CLIP)
                        opt.step()
                    model.eval()
                    with torch.no_grad():
                        val_logits = model(Xv)
                        val_loss = crit(val_logits, yv).item()
                    scheduler.step(val_loss)
                    if val_loss < best_val_loss:
                        best_val_loss = val_loss
                        best_state = {k: v.clone() for k, v in model.state_dict().items()}
                        patience_counter = 0
                    else:
                        patience_counter += 1
                        if patience_counter >= DL_EARLY_STOPPING_PATIENCE:
                            break
                if best_state is not None:
                    model.load_state_dict(best_state)

                calibrated, calib_status = _calibrate_or_keep(
                    "DL", model, Xs_calib, y_calib
                )
                if not _model_produces_three_classes(calibrated, Xs_calib):
                    calibrated = _TorchProbaWrapper(model)
                    calib_status = _CALIBRATION_STATUS_RAW_KEPT
                ml_models["DL"] = calibrated
                calibration_status_by_key["DL"] = calib_status

                if calib_status == _CALIBRATION_STATUS_FAILED:
                    stage_print("❌ DL : calibration échouée, modèle brut conservé")

                ll_dl_calib = _compute_calibration_log_loss(
                    calibrated, Xs_calib, y_calib
                )
                calib_ll_by_key["DL"] = float(ll_dl_calib)

                ll_dl_wf = _evaluate_dl_walk_forward(
                    X_train_raw, y_train, MODEL_WALK_FORWARD_FOLDS,
                    Xs_train.shape[1],
                )
                wf_ll_by_key["DL"] = float(ll_dl_wf)
                ll_source_by_key["DL"] = _LL_SOURCE_WALK_FORWARD

                if np.isfinite(ll_dl_calib):
                    stage_print(
                        f"✅ DEEP LEARNING : LogLoss {float(ll_dl_calib):.4f}"
                    )
                else:
                    stage_print("⚠️ DEEP LEARNING : LogLoss invalide")
            except Exception as exc:
                logger.error("Deep Learning : %s", exc)
                stage_print("❌ DEEP LEARNING : échec")

    stage_print("🤖 PENALTY BLOG MODELS")
    pb_candidates: List[Tuple[str, Any]] = []
    for class_name in _PB_MODEL_ORDER:
        status, payload = _fit_pb_model(
            class_name, gh_train, ga_train, home_keys_train, away_keys_train
        )
        if status == "ok":
            pb_candidates.append((class_name, payload))
            logger.info("penaltyblog %s entraîné", class_name)
            stage_print(f"✅ {class_name.upper()} : entraîné")
        else:
            logger.error("penaltyblog %s : %s", class_name, payload)
            stage_print(f"❌ {class_name.upper()} : échec")

    pb_models: List[Tuple[str, Any]] = []
    for class_name, model in pb_candidates:
        try:
            probas: List[List[float]] = []
            y_kept: List[int] = []
            for h, a, yv in zip(home_keys_calib, away_keys_calib, y_calib):
                try:
                    grid = model.predict(h, a)
                    markets = _extract_model_probabilities(grid)
                    hda = markets.get("home_draw_away")
                    if hda is None or len(hda) != 3:
                        continue
                    hda_arr = np.asarray(hda, dtype=np.float64)
                    if hda_arr.shape != (3,) or not np.all(np.isfinite(hda_arr)):
                        continue
                    if hda_arr.sum() <= 0:
                        continue
                    hda_arr = hda_arr / hda_arr.sum()
                    probas.append(hda_arr.tolist())
                    y_kept.append(int(yv))
                except Exception:
                    continue

            if len(probas) < _PB_CALIB_MIN_VALID_SAMPLES:
                logger.warning(
                    "penaltyblog %s : trop peu de prédictions valides (%d)",
                    class_name, len(probas),
                )
                continue

            probas_arr = np.array(probas, dtype=np.float64)
            y_arr = np.array(y_kept, dtype=np.int64)
            if not _proba_array_is_valid(probas_arr):
                logger.warning(
                    "penaltyblog %s : probabilités invalides", class_name
                )
                continue
            if len(np.unique(y_arr)) < 2:
                logger.warning(
                    "penaltyblog %s : une seule classe dans les prédictions valides",
                    class_name,
                )
                continue

            ll_calib = float(log_loss(y_arr, probas_arr, labels=[0, 1, 2]))
            if not np.isfinite(ll_calib) or ll_calib <= 0:
                logger.warning(
                    "penaltyblog %s : LogLoss calibration invalide", class_name
                )
                continue

            ll_wf_pb = _evaluate_pb_model_walk_forward(
                class_name,
                gh_train, ga_train, home_keys_train, away_keys_train,
                MODEL_WALK_FORWARD_FOLDS,
            )
            if not np.isfinite(ll_wf_pb) or ll_wf_pb <= 0:
                logger.warning(
                    "penaltyblog %s : WF indisponible, repli calibration (%.4f)",
                    class_name, ll_calib,
                )
                ll_wf_pb = ll_calib

            if ll_wf_pb > _MAX_ACCEPTABLE_LOGLOSS:
                logger.warning(
                    "penaltyblog %s : WF LogLoss %.4f > %.4f, poids réduit",
                    class_name, ll_wf_pb, _MAX_ACCEPTABLE_LOGLOSS,
                )
                ll_wf_pb = _MAX_ACCEPTABLE_LOGLOSS + 0.20

            pb_index = len(pb_models)
            pb_models.append((class_name, model))
            calib_ll_by_key[f"pb_{pb_index}"] = ll_calib
            wf_ll_by_key[f"pb_{pb_index}"] = float(ll_wf_pb)
            ll_source_by_key[f"pb_{pb_index}"] = _LL_SOURCE_WALK_FORWARD
            calibration_status_by_key[f"pb_{pb_index}"] = _CALIBRATION_STATUS_OK
            stage_print(
                f"✅ {class_name.upper()} — CALIB: {ll_calib:.4f} | "
                f"WF: {ll_wf_pb:.4f}"
            )
        except Exception as exc:
            logger.error("Pondération penaltyblog %s : %s", class_name, exc)

    for k, ll in wf_ll_by_key.items():
        try:
            ll_f = float(ll)
        except (TypeError, ValueError):
            ll_f = float("inf")
        if (
            np.isfinite(ll_f)
            and ll_f > 0
            and ll_f <= _MAX_ACCEPTABLE_LOGLOSS
        ):
            weights[k] = 1.0 / (ll_f + _EPS_WEIGHT)
        else:
            weights[k] = 0.0

    if not ml_models and not pb_models:
        logger.error("Aucun modèle n'a pu être entraîné")
        stage_print("❌ Aucun modèle n'a pu être entraîné")
        return None, None, None, {}

    filtered_weights = _filter_valid_weights(weights)
    valid_model_keys = [k for k in filtered_weights.keys() if not k.startswith("__")]
    if not valid_model_keys:
        fallback_keys = _select_fallback_uniform_models(
            ml_models, pb_models, wf_ll_by_key
        )
        if not fallback_keys:
            logger.error(
                "Aucun modèle n'a de WF LogLoss valide ; entraînement conservé sans "
                "pondération fiable."
            )
            stage_print("❌ Aucun modèle valide disponible pour l'ensemble")
            return None, None, None, {}
        uniform = 1.0 / len(fallback_keys)
        for k in fallback_keys:
            filtered_weights[k] = uniform
    else:
        filtered_weights = _apply_quality_filter_on_weights(
            filtered_weights, wf_ll_by_key
        )

    weights = _normalize_weights(
        filtered_weights, ENSEMBLE_MIN_WEIGHT, ENSEMBLE_MAX_WEIGHT
    )

    if TEMPERATURE_SCALING_ENABLED:
        try:
            calib_blend = _compute_ensemble_probas(
                ml_models, pb_models, Xs_calib,
                home_keys_calib, away_keys_calib, weights,
            )
            if calib_blend is not None:
                temp = _compute_optimal_temperature(calib_blend, y_calib)
                weights["__temperature__"] = float(temp)
            else:
                weights["__temperature__"] = float(TEMPERATURE_SCALING_DEFAULT)
        except Exception:
            weights["__temperature__"] = float(TEMPERATURE_SCALING_DEFAULT)

    weights["__ll_source_map__"] = ll_source_by_key
    weights["__calibration_status_map__"] = calibration_status_by_key
    weights["__walk_forward_ll_map__"] = wf_ll_by_key
    weights["__calibration_ll_map__"] = calib_ll_by_key
    weights["__strict_competition__"] = bool(_STRICT_COMPETITION_DEFAULT)
    weights["__feature_names__"] = list(FEATURE_NAMES)
    weights["__feature_count__"] = int(EXPECTED_FEATURE_COUNT)

    final_temperature = float(weights.get("__temperature__", 1.0))
    test_metrics = _evaluate_ensemble_on_set(
        ml_models, pb_models, Xs_test, y_test,
        home_keys_test, away_keys_test,
        weights, final_temperature,
    )
    if test_metrics is not None:
        ll_test, acc_test = test_metrics
        stage_print(
            f"📊 TEST FINAL : LogLoss {ll_test:.4f} | Accuracy {acc_test * 100:.1f}%"
        )

    return ml_models, pb_models, scaler, weights

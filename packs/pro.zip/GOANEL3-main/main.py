import os
import sys
import signal
import logging
import argparse
import traceback
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from config import (
    COMPETITIONS_DETAILS,
    COMPETITIONS_BY_CODE,
    COMPETITIONS,
    CACHE_DIR,
    CACHE_NEVER_EXPIRES,
    MIN_MATCHES_FOR_TRAINING,
    MANIFEST_FILE,
    CONFIG_FINGERPRINT,
    ARTIFACT_SCHEMA_VERSION,
    EXPECTED_FEATURE_COUNT_REFERENCE,
    EXPECTED_CLASS_COUNT,
    now_local,
    stage_print,
)
from predict import load_or_build_data_and_models, predict_for_date

logger = logging.getLogger("goangel.main")

RESET: str = "\033[0m"
BOLD: str = "\033[1m"
DIM: str = "\033[2m"
ITALIC: str = "\033[3m"

RED: str = "\033[1;31m"
GREEN: str = "\033[1;32m"
YELLOW: str = "\033[1;33m"
BLUE: str = "\033[1;34m"
MAGENTA: str = "\033[1;35m"
CYAN: str = "\033[1;36m"
WHITE: str = "\033[1;37m"
GREY: str = "\033[0;90m"
ORANGE: str = "\033[38;5;208m"
LIME: str = "\033[38;5;154m"
PINK: str = "\033[38;5;213m"
VIOLET: str = "\033[38;5;135m"
SKY: str = "\033[38;5;117m"
GOLD: str = "\033[38;5;220m"

_BANNER_LOGO: List[str] = [
    r"   ██████╗  ██████╗  █████╗ ███╗   ██╗ ██████╗ ███████╗██╗     ",
    r"  ██╔════╝ ██╔═══██╗██╔══██╗████╗  ██║██╔════╝ ██╔════╝██║     ",
    r"  ██║  ███╗██║   ██║███████║██╔██╗ ██║██║  ███╗█████╗  ██║     ",
    r"  ██║   ██║██║   ██║██╔══██║██║╚██╗██║██║   ██║██╔══╝  ██║     ",
    r"  ╚██████╔╝╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝███████╗███████╗",
    r"   ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚══════╝",
]

_BANNER_COLORS: List[str] = [RED, ORANGE, GOLD, LIME, SKY, VIOLET]

_TITLE: str = "GOANGEL SYSTEM"
_SUBTITLE: str = "Moteur de prédictions footballistiques multi-modèles"
_VERSION: str = f"v18 — Football-Data.org — {EXPECTED_FEATURE_COUNT_REFERENCE} features"
_TAGLINE: str = "Analyse · Statistiques · Ensemble Learning · Calibration"

_SHUTDOWN_FLAG: Dict[str, bool] = {"requested": False}

_MIN_YEAR: int = 1990
_MAX_YEAR: int = 2100

_TUPLE_LEN_EXPECTED: int = 5

_BANNER_WIDTH_MIN: int = 68
_BANNER_WIDTH_MAX: int = 100
_SEPARATOR_LEN: int = 60

_DATE_FORMAT_USER: str = "%d/%m/%Y"
_DATE_FORMAT_ISO: str = "%Y-%m-%d"

_QUIT_COMMANDS: frozenset = frozenset({"quit", "exit", "q"})
_HELP_COMMANDS: frozenset = frozenset({"help", "h", "?"})
_COMPETITIONS_COMMANDS: frozenset = frozenset({"competitions", "comps", "c"})
_CLEAR_COMMANDS: frozenset = frozenset({"clear", "cls"})
_REFRESH_COMMANDS: frozenset = frozenset({"refresh", "reload", "r"})
_STATUS_COMMANDS: frozenset = frozenset({"status", "info"})
_TODAY_COMMANDS: frozenset = frozenset({"today", "aujourd'hui", "aujourdhui"})
_YESTERDAY_COMMANDS: frozenset = frozenset({"yesterday", "hier"})
_TOMORROW_COMMANDS: frozenset = frozenset({"tomorrow", "demain"})


def _visible_len(text: str) -> int:
    result = 0
    i = 0
    while i < len(text):
        if text[i] == "\033":
            j = text.find("m", i)
            if j == -1:
                break
            i = j + 1
            continue
        result += 1
        i += 1
    return result


def _center_colored(text: str, width: int) -> str:
    visible = _visible_len(text)
    if visible >= width:
        return text
    left = (width - visible) // 2
    right = width - visible - left
    return (" " * left) + text + (" " * right)


def print_banner() -> None:
    try:
        term_width = os.get_terminal_size().columns
    except OSError:
        term_width = _BANNER_WIDTH_MIN + 8

    banner_width = max(_BANNER_WIDTH_MIN, min(term_width, _BANNER_WIDTH_MAX))
    left_pad = max(0, (term_width - banner_width) // 2)

    print()
    print(" " * left_pad + f"{GREY}╔" + "═" * (banner_width - 2) + f"╗{RESET}")

    for i, line in enumerate(_BANNER_LOGO):
        color = _BANNER_COLORS[i % len(_BANNER_COLORS)]
        inner = _center_colored(f"{color}{BOLD}{line}{RESET}", banner_width - 4)
        print(" " * left_pad + f"{GREY}║{RESET} " + inner + f" {GREY}║{RESET}")

    print(" " * left_pad + f"{GREY}╠" + "═" * (banner_width - 2) + f"╣{RESET}")

    title_line = (
        f"{GOLD}{BOLD}★ {_TITLE} ★{RESET}  "
        f"{DIM}{GREY}({_VERSION}){RESET}"
    )
    print(
        " " * left_pad
        + f"{GREY}║{RESET} "
        + _center_colored(title_line, banner_width - 4)
        + f" {GREY}║{RESET}"
    )

    subtitle_line = f"{CYAN}{_SUBTITLE}{RESET}"
    print(
        " " * left_pad
        + f"{GREY}║{RESET} "
        + _center_colored(subtitle_line, banner_width - 4)
        + f" {GREY}║{RESET}"
    )

    tagline_line = f"{DIM}{ITALIC}{LIME}{_TAGLINE}{RESET}"
    print(
        " " * left_pad
        + f"{GREY}║{RESET} "
        + _center_colored(tagline_line, banner_width - 4)
        + f" {GREY}║{RESET}"
    )

    print(" " * left_pad + f"{GREY}╠" + "═" * (banner_width - 2) + f"╣{RESET}")

    cache_label = "PERMANENT" if CACHE_NEVER_EXPIRES else "avec expiration"
    cache_color = GREEN if CACHE_NEVER_EXPIRES else YELLOW
    cache_line = (
        f"{SKY}💾 Cache {cache_color}{BOLD}{cache_label}{RESET}"
        f"{SKY} : {CACHE_DIR}{RESET}"
    )
    print(
        " " * left_pad
        + f"{GREY}║{RESET} "
        + _center_colored(cache_line, banner_width - 4)
        + f" {GREY}║{RESET}"
    )

    comp_line = (
        f"{PINK}🏆 Compétitions suivies : {BOLD}{len(COMPETITIONS_DETAILS)}{RESET}"
    )
    print(
        " " * left_pad
        + f"{GREY}║{RESET} "
        + _center_colored(comp_line, banner_width - 4)
        + f" {GREY}║{RESET}"
    )

    try:
        now_str = now_local().strftime("%d/%m/%Y %H:%M:%S")
    except Exception:
        now_str = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    time_line = f"{SKY}🕒 {now_str}{RESET}"
    print(
        " " * left_pad
        + f"{GREY}║{RESET} "
        + _center_colored(time_line, banner_width - 4)
        + f" {GREY}║{RESET}"
    )

    print(" " * left_pad + f"{GREY}╚" + "═" * (banner_width - 2) + f"╝{RESET}")
    print()


def print_section(title: str, color: str = CYAN) -> None:
    print()
    padding = max(0, _SEPARATOR_LEN - len(title))
    print(f"{color}── {title} " + "─" * padding + f"{RESET}")


def clear_screen() -> None:
    try:
        os.system("clear" if os.name == "posix" else "cls")
    except Exception:
        pass
    print_banner()


def _now_local() -> datetime:
    return now_local()


def _ddmmyyyy_to_iso(date_str: str) -> str:
    return datetime.strptime(date_str.strip(), _DATE_FORMAT_USER).strftime(
        _DATE_FORMAT_ISO
    )


def _iso_to_ddmmyyyy(date_str: str) -> str:
    return datetime.strptime(date_str, _DATE_FORMAT_ISO).strftime(
        _DATE_FORMAT_USER
    )


def validate_date_ddmmyyyy(date_str: str) -> bool:
    if not isinstance(date_str, str):
        return False
    s = date_str.strip()
    if len(s) != 10:
        return False
    try:
        parsed = datetime.strptime(s, _DATE_FORMAT_USER)
    except (TypeError, ValueError):
        return False
    if parsed.year < _MIN_YEAR or parsed.year > _MAX_YEAR:
        return False
    return True


def display_competitions() -> None:
    print_section(f"Compétitions suivies ({len(COMPETITIONS_DETAILS)})", CYAN)
    for comp in COMPETITIONS_DETAILS:
        group_color = {
            "EUROPE_TOP5": LIME,
            "EUROPE_CUP": GOLD,
            "INTERNATIONAL": PINK,
            "SOUTH_AMERICA": ORANGE,
            "OTHER": SKY,
        }.get(comp.group, GREY)
        print(
            f"  {comp.flag}  {WHITE}{comp.code:4s}{RESET} "
            f"{comp.name:<26s} "
            f"{GREY}({comp.country}){RESET} "
            f"Tier {comp.tier} — {group_color}{comp.group}{RESET}"
        )


def display_help() -> None:
    print_section("Commandes disponibles", CYAN)
    rows = [
        ("<DD/MM/YYYY>", "Prédire les matchs de la date indiquée"),
        ("today", "Prédire les matchs du jour"),
        ("yesterday", "Prédire les matchs d'hier"),
        ("tomorrow", "Prédire les matchs de demain"),
        ("refresh", "Reconstruire les données et réentraîner les modèles"),
        ("status", "Afficher l'état du cache et des modèles chargés"),
        ("competitions", "Afficher les compétitions suivies"),
        ("clear", "Effacer l'écran"),
        ("help", "Afficher cette aide"),
        ("quit / exit / q", "Quitter le programme"),
    ]
    for cmd, desc in rows:
        print(f"  {YELLOW}{cmd:<22s}{RESET} {desc}")


def display_status(state: Dict[str, Any]) -> None:
    print_section("État du système", CYAN)

    cache_files = [
        ("historical.pkl", state.get("df_past")),
        ("models.pkl", state.get("ml_models")),
        ("scaler.pkl", state.get("scaler")),
        ("weights.pkl", state.get("weights")),
    ]

    ml_models = state.get("ml_models")
    pb_models = state.get("pb_models")
    df_past = state.get("df_past")
    scaler = state.get("scaler")
    weights = state.get("weights") or {}

    n_ml = len(ml_models) if isinstance(ml_models, dict) else 0
    n_pb = len(pb_models) if isinstance(pb_models, list) else 0
    n_rows = len(df_past) if isinstance(df_past, (list, dict)) is False and df_past is not None and hasattr(df_past, "__len__") else 0

    try:
        n_rows = int(len(df_past)) if df_past is not None else 0
    except Exception:
        n_rows = 0

    print(f"  {SKY}Cache :{RESET} {CACHE_DIR}")
    print(f"  {SKY}Persistance :{RESET} {'PERMANENTE' if CACHE_NEVER_EXPIRES else 'temporaire'}")
    print(f"  {SKY}Manifest :{RESET} {'présent' if MANIFEST_FILE.exists() else 'absent'}")
    print(f"  {SKY}Schema :{RESET} {ARTIFACT_SCHEMA_VERSION}")
    print(f"  {SKY}Fingerprint :{RESET} {CONFIG_FINGERPRINT[:16]}...")

    print()
    print(f"  {LIME}Matchs historiques :{RESET} {n_rows}")
    print(f"  {LIME}Modèles ML :{RESET} {n_ml}")
    print(f"  {LIME}Modèles Penaltyblog :{RESET} {n_pb}")
    print(f"  {LIME}Scaler :{RESET} {'OK' if scaler is not None else 'absent'}")

    if isinstance(weights, dict) and weights:
        temperature = weights.get("__temperature__")
        if temperature is not None:
            try:
                print(f"  {LIME}Température :{RESET} {float(temperature):.4f}")
            except (TypeError, ValueError):
                pass

    print()
    if n_rows >= MIN_MATCHES_FOR_TRAINING and (n_ml > 0 or n_pb > 0):
        print(f"  {GREEN}Statut : prêt pour la prédiction{RESET}")
    else:
        print(f"  {YELLOW}Statut : mode dégradé (données ou modèles insuffisants){RESET}")


def _handle_sigint(signum: int, frame: Any) -> None:
    if _SHUTDOWN_FLAG["requested"]:
        print(f"\n{RED}Arrêt forcé.{RESET}")
        os._exit(130)
    _SHUTDOWN_FLAG["requested"] = True
    print(
        f"\n{YELLOW}Interruption détectée. "
        f"Appuyez de nouveau sur Ctrl+C pour forcer, ou tapez 'quit'.{RESET}"
    )


def _handle_sigterm(signum: int, frame: Any) -> None:
    logger.info("SIGTERM reçu, arrêt propre.")
    print(f"\n{YELLOW}Arrêt demandé.{RESET}")
    sys.exit(0)


def _install_signal_handlers() -> None:
    try:
        signal.signal(signal.SIGINT, _handle_sigint)
    except (ValueError, OSError):
        pass
    try:
        signal.signal(signal.SIGTERM, _handle_sigterm)
    except (ValueError, OSError, AttributeError):
        pass


def _safe_reload_models(state: Dict[str, Any], force_refresh: bool) -> bool:
    try:
        result = load_or_build_data_and_models(force_refresh=force_refresh)
    except TypeError as exc:
        logger.error(
            "Signature de load_or_build_data_and_models incompatible : %s", exc
        )
        logger.debug(traceback.format_exc())
        print(
            f"{RED}Signature incompatible de load_or_build_data_and_models : "
            f"{exc}{RESET}"
        )
        return False
    except Exception as exc:
        logger.error("Échec du chargement des modèles : %s", exc)
        logger.debug(traceback.format_exc())
        print(f"{RED}Échec du chargement des modèles : {exc}{RESET}")
        return False

    if not isinstance(result, tuple) or len(result) != _TUPLE_LEN_EXPECTED:
        logger.error(
            "Signature inattendue de load_or_build_data_and_models : %r",
            type(result),
        )
        print(f"{RED}Signature de chargement invalide.{RESET}")
        return False

    ml_models, pb_models, scaler, df_past, weights = result

    df_empty = df_past is None or getattr(df_past, "empty", True)
    if df_empty:
        logger.warning("Historique vide, les prédictions seront dégradées.")
        print(f"{YELLOW}⚠️  Aucun historique exploitable.{RESET}")
    else:
        try:
            n_rows = int(len(df_past))
        except Exception:
            n_rows = -1
        if 0 <= n_rows < MIN_MATCHES_FOR_TRAINING:
            logger.warning(
                "Historique trop petit pour l'entraînement (%d < %d).",
                n_rows,
                MIN_MATCHES_FOR_TRAINING,
            )
            print(
                f"{YELLOW}⚠️  Historique limité "
                f"({n_rows} matchs < {MIN_MATCHES_FOR_TRAINING}).{RESET}"
            )
        else:
            print(f"{GREEN}📚 Historique chargé : {n_rows} matchs.{RESET}")

    if not ml_models and not pb_models:
        logger.warning("Aucun modèle entraîné disponible.")
        print(f"{YELLOW}⚠️  Aucun modèle entraîné.{RESET}")
    else:
        n_ml = len(ml_models) if isinstance(ml_models, dict) else 0
        n_pb = len(pb_models) if isinstance(pb_models, list) else 0
        print(f"{GREEN}🤖 Modèles actifs : {n_ml} ML + {n_pb} Penaltyblog.{RESET}")

    if weights is None:
        weights = {}

    state["ml_models"] = ml_models
    state["pb_models"] = pb_models
    state["scaler"] = scaler
    state["df_past"] = df_past
    state["weights"] = weights
    return True


def _predict_date(state: Dict[str, Any], date_iso: str) -> bool:
    try:
        predict_for_date(
            date_iso,
            state.get("ml_models"),
            state.get("pb_models"),
            state.get("scaler"),
            state.get("df_past"),
            state.get("weights", {}),
        )
        return True
    except TypeError as exc:
        logger.error(
            "Signature de predict_for_date incompatible pour %s : %s",
            date_iso,
            exc,
        )
        logger.debug(traceback.format_exc())
        print(
            f"{RED}Signature incompatible de predict_for_date : {exc}{RESET}"
        )
        return False
    except Exception as exc:
        logger.error("Erreur de prédiction pour %s : %s", date_iso, exc)
        logger.debug(traceback.format_exc())
        print(f"{RED}Erreur lors de la prédiction : {exc}{RESET}")
        return False


def _resolve_date_command(user_input: str) -> Optional[str]:
    ui = user_input.strip().lower()
    now = _now_local()
    if ui in _TODAY_COMMANDS:
        return now.strftime(_DATE_FORMAT_ISO)
    if ui in _YESTERDAY_COMMANDS:
        return (now - timedelta(days=1)).strftime(_DATE_FORMAT_ISO)
    if ui in _TOMORROW_COMMANDS:
        return (now + timedelta(days=1)).strftime(_DATE_FORMAT_ISO)
    return None


def run_interactive(state: Dict[str, Any]) -> int:
    stage_print(
        f"{CYAN}🤖 MOTEUR GOANGEL PRÊT — SAISISSEZ UNE DATE (DD/MM/YYYY) "
        f"OU UNE COMMANDE ({YELLOW}help{RESET}{CYAN} pour la liste).{RESET}"
    )
    while True:
        try:
            user_input = input(
                f"\n{GOLD}📅 Date (DD/MM/YYYY) ou commande "
                f"({YELLOW}quit{RESET}{GOLD} pour quitter) : {RESET}"
            )
        except (EOFError, KeyboardInterrupt):
            print(f"\n{GREY}Au revoir.{RESET}")
            return 0

        if _SHUTDOWN_FLAG["requested"]:
            print(f"{YELLOW}Arrêt demandé.{RESET}")
            return 0

        if user_input is None:
            continue

        user_input = user_input.strip()
        if not user_input:
            continue

        ui = user_input.lower()

        if ui in _QUIT_COMMANDS:
            print(f"{GREY}Fermeture de GOANGEL.{RESET}")
            return 0

        if ui in _CLEAR_COMMANDS:
            clear_screen()
            continue

        if ui in _HELP_COMMANDS:
            display_help()
            continue

        if ui in _COMPETITIONS_COMMANDS:
            display_competitions()
            continue

        if ui in _STATUS_COMMANDS:
            display_status(state)
            continue

        if ui in _REFRESH_COMMANDS:
            print(
                f"{CYAN}♻️  Reconstruction complète des données et modèles "
                f"en cours...{RESET}"
            )
            ok = _safe_reload_models(state, force_refresh=True)
            if ok:
                print(f"{GREEN}✅ Reconstruction terminée.{RESET}")
            continue

        resolved = _resolve_date_command(ui)
        if resolved is not None:
            date_iso = resolved
        else:
            if not validate_date_ddmmyyyy(user_input):
                print(
                    f"{RED}❌ Format de date invalide. Utilisez DD/MM/YYYY.{RESET}"
                )
                continue
            try:
                date_iso = _ddmmyyyy_to_iso(user_input)
            except Exception:
                print(f"{RED}❌ Date impossible à convertir.{RESET}")
                continue

        try:
            pretty = _iso_to_ddmmyyyy(date_iso)
        except Exception:
            pretty = date_iso

        print(f"\n{CYAN}🔍 Recherche des matchs du {BOLD}{pretty}{RESET}...")
        _predict_date(state, date_iso)
        print()
        print(f"{GREY}" + "═" * _SEPARATOR_LEN + f"{RESET}")


def run_single_date(date_ddmmyyyy: str, state: Dict[str, Any]) -> int:
    if not validate_date_ddmmyyyy(date_ddmmyyyy):
        logger.error("Format de date invalide : %s", date_ddmmyyyy)
        print(f"{RED}❌ Format de date invalide. Utilisez DD/MM/YYYY.{RESET}")
        return 2
    try:
        date_iso = _ddmmyyyy_to_iso(date_ddmmyyyy)
    except Exception:
        print(f"{RED}❌ Date impossible à convertir.{RESET}")
        return 2
    ok = _predict_date(state, date_iso)
    return 0 if ok else 1


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="goangel",
        description="GOANGEL — Moteur de prédictions sportives multi-modèles",
    )
    parser.add_argument(
        "--date",
        type=str,
        default=None,
        help="Date au format DD/MM/YYYY pour une exécution non interactive",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Force la reconstruction complète du cache et des modèles",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Affiche l'état du cache et des modèles puis quitte",
    )
    parser.add_argument(
        "--no-banner",
        action="store_true",
        help="N'affiche pas la bannière",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Réduit la sortie console au strict minimum",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    _install_signal_handlers()
    args = _parse_args(argv)

    if not args.no_banner and not args.quiet:
        print_banner()
    if not args.quiet:
        stage_print(f"{CYAN}🚀 DÉMARRAGE INITIAL{RESET}")
    logger.info(
        "Démarrage de GOANGEL (argv=%s)",
        argv if argv is not None else sys.argv[1:],
    )

    state: Dict[str, Any] = {
        "ml_models": None,
        "pb_models": None,
        "scaler": None,
        "df_past": None,
        "weights": {},
    }

    if not _safe_reload_models(state, force_refresh=args.refresh):
        logger.critical("Arrêt : impossible de charger les modèles.")
        if not args.quiet:
            stage_print(
                f"{RED}❌ Erreur fatale lors du chargement des modèles.{RESET}"
            )
        return 1

    if args.status:
        display_status(state)
        return 0

    if args.date:
        return run_single_date(args.date, state)

    try:
        return run_interactive(state)
    except KeyboardInterrupt:
        print(f"\n{GREY}Au revoir.{RESET}")
        return 130
    except Exception as exc:
        logger.critical("Erreur non gérée : %s", exc)
        logger.debug(traceback.format_exc())
        print(f"{RED}Erreur inattendue : {exc}{RESET}")
        return 1


if __name__ == "__main__":
    sys.exit(main())

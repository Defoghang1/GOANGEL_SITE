import time
import logging
import threading
import random
from datetime import date, datetime, timedelta, timezone
from itertools import cycle
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import (
    tokens,
    COMPETITIONS,
    API_BASE_URL,
    API_TIMEOUT_SECONDS,
    API_MAX_RETRIES,
    API_RETRY_BACKOFF_SECONDS,
    API_RATE_LIMIT_SLEEP_SECONDS,
    API_COMPETITION_SLEEP_SECONDS,
    API_MAX_CONCURRENT_REQUESTS,
    API_CHUNK_DAYS,
    API_CIRCUIT_BREAKER_FAILURES,
    API_CIRCUIT_BREAKER_COOLDOWN,
    HISTORICAL_SEASONS_LOOKBACK,
    DEFAULT_SEASON_START_MONTH,
    DEFAULT_SEASON_START_DAY,
    DEFAULT_SEASON_END_MONTH,
    DEFAULT_SEASON_END_DAY,
    ODDS_API_KEY,
    ODDS_API_BASE_URL,
    ODDS_API_ENABLED,
    ODDS_REGIONS,
    ODDS_MARKETS,
    ODDS_ODDS_FORMAT,
    ODDS_REQUESTS_PER_MINUTE,
)

logger = logging.getLogger("goangel.api")


class FootballDataAPIError(Exception):
    pass


class TokenManager:
    def __init__(self, token_list: List[str]):
        if not token_list:
            raise FootballDataAPIError("Aucun token disponible pour TokenManager")
        self._lock = threading.Lock()
        self.tokens = list(token_list)
        self._pool = cycle(self.tokens)
        self._current = next(self._pool)
        self._cooldowns: Dict[str, float] = {t: 0.0 for t in self.tokens}
        self._usage: Dict[str, int] = {t: 0 for t in self.tokens}

    def get_next(self) -> str:
        while True:
            wait_seconds = 0.0
            with self._lock:
                now = time.monotonic()
                token = next(self._pool)
                if self._cooldowns.get(token, 0.0) <= now:
                    self._current = token
                    self._usage[token] = self._usage.get(token, 0) + 1
                    return self._current
                attempts = 1
                chosen = token
                while attempts < len(self.tokens):
                    candidate = next(self._pool)
                    if self._cooldowns.get(candidate, 0.0) <= now:
                        self._current = candidate
                        self._usage[candidate] = self._usage.get(candidate, 0) + 1
                        return self._current
                    if self._cooldowns.get(candidate, 0.0) < self._cooldowns.get(chosen, 0.0):
                        chosen = candidate
                    attempts += 1
                wait_seconds = max(0.0, self._cooldowns.get(chosen, 0.0) - now)
            if wait_seconds > 0:
                time.sleep(min(wait_seconds, 60.0))
            else:
                time.sleep(0.5)

    def mark_rate_limited(self, token: str, retry_after_seconds: float) -> None:
        with self._lock:
            self._cooldowns[token] = time.monotonic() + max(retry_after_seconds, 1.0)

    def get_headers(self) -> Dict[str, str]:
        return {"X-Auth-Token": self.get_next()}

    def current_token(self) -> str:
        with self._lock:
            return self._current

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            now = time.monotonic()
            return {
                "tokens": len(self.tokens),
                "cooldowns": {
                    t[:6] + "***": max(0.0, cd - now)
                    for t, cd in self._cooldowns.items()
                },
                "usage": {t[:6] + "***": u for t, u in self._usage.items()},
            }


class CircuitBreaker:
    def __init__(self, threshold: int, cooldown: float):
        self._threshold = max(1, int(threshold))
        self._cooldown = max(1.0, float(cooldown))
        self._failures = 0
        self._opened_at = 0.0
        self._lock = threading.Lock()

    def is_open(self) -> bool:
        with self._lock:
            if self._opened_at <= 0.0:
                return False
            if time.monotonic() - self._opened_at >= self._cooldown:
                self._failures = 0
                self._opened_at = 0.0
                return False
            return True

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            self._opened_at = 0.0

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._opened_at = time.monotonic()

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            now = time.monotonic()
            remaining = (
                max(0.0, self._cooldown - (now - self._opened_at))
                if self._opened_at > 0
                else 0.0
            )
            return {
                "failures": self._failures,
                "open": self._opened_at > 0.0,
                "cooldown_remaining": remaining,
            }


token_manager = TokenManager(tokens)

_circuit_breakers: Dict[str, CircuitBreaker] = {}
_cb_lock = threading.Lock()


def _get_circuit_breaker(host: str) -> CircuitBreaker:
    with _cb_lock:
        if host not in _circuit_breakers:
            _circuit_breakers[host] = CircuitBreaker(
                API_CIRCUIT_BREAKER_FAILURES, API_CIRCUIT_BREAKER_COOLDOWN
            )
        return _circuit_breakers[host]


def _host_from_url(url: str) -> str:
    try:
        parsed = urlparse(url)
        return parsed.netloc or "unknown"
    except Exception:
        return "unknown"


_session = requests.Session()
_adapter = HTTPAdapter(
    pool_connections=max(10, API_MAX_CONCURRENT_REQUESTS * 2),
    pool_maxsize=max(10, API_MAX_CONCURRENT_REQUESTS * 2),
    max_retries=Retry(total=0, connect=0, read=0, redirect=2, status=0),
)
_session.mount("https://", _adapter)
_session.mount("http://", _adapter)

_odds_session = requests.Session()
_odds_adapter = HTTPAdapter(
    pool_connections=max(4, API_MAX_CONCURRENT_REQUESTS * 2),
    pool_maxsize=max(4, API_MAX_CONCURRENT_REQUESTS * 2),
    max_retries=Retry(total=0, connect=0, read=0, redirect=2, status=0),
)
_odds_session.mount("https://", _odds_adapter)
_odds_session.mount("http://", _odds_adapter)

_odds_rate_lock = threading.Lock()
_odds_last_request: Dict[str, float] = {}


def _parse_retry_after(resp: requests.Response, default_seconds: float) -> float:
    header_value = (
        resp.headers.get("Retry-After")
        or resp.headers.get("X-RequestCounter-Reset")
        or resp.headers.get("X-RateLimit-Reset")
    )
    if header_value is None:
        return default_seconds
    try:
        return max(float(header_value), 0.0)
    except (TypeError, ValueError):
        return default_seconds


def _backoff_seconds(attempt: int) -> float:
    base = max(0.1, float(API_RETRY_BACKOFF_SECONDS))
    delay = base * (2 ** attempt)
    jitter = delay * random.uniform(0.0, 0.25)
    return min(delay + jitter, 60.0)


def make_request(
    url: str,
    params: Optional[Dict[str, Any]] = None,
    retries: int = API_MAX_RETRIES,
    session: Optional[requests.Session] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = None,
) -> Optional[Dict[str, Any]]:
    if retries < 1:
        retries = 1
    if session is None:
        session = _session
    if timeout is None:
        timeout = float(API_TIMEOUT_SECONDS)

    host = _host_from_url(url)
    breaker = _get_circuit_breaker(host)
    if breaker.is_open():
        snap = breaker.snapshot()
        logger.warning(
            "Circuit breaker ouvert pour %s (cooldown restant %.1fs)",
            host,
            snap["cooldown_remaining"],
        )
        return None

    last_error: Optional[str] = None
    for attempt in range(retries):
        current_token = token_manager.get_next()
        headers = {"X-Auth-Token": current_token, "Accept": "application/json"}
        if extra_headers:
            headers.update(extra_headers)

        try:
            resp = session.get(
                url,
                headers=headers,
                params=params,
                timeout=timeout,
            )
        except requests.exceptions.Timeout as exc:
            last_error = f"Timeout: {exc}"
            breaker.record_failure()
            logger.warning("Timeout sur %s (tentative %d/%d)", url, attempt + 1, retries)
            if attempt < retries - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break
        except requests.exceptions.ConnectionError as exc:
            last_error = f"ConnectionError: {exc}"
            breaker.record_failure()
            logger.warning(
                "Erreur de connexion sur %s (tentative %d/%d)",
                url,
                attempt + 1,
                retries,
            )
            if attempt < retries - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break
        except requests.exceptions.RequestException as exc:
            last_error = f"RequestException: {exc}"
            breaker.record_failure()
            logger.error("Erreur requête sur %s : %s", url, exc)
            if attempt < retries - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break

        if resp.status_code == 200:
            try:
                payload = resp.json()
            except ValueError as exc:
                last_error = f"JSONDecodeError: {exc}"
                logger.error("Réponse JSON invalide depuis %s : %s", url, exc)
                if attempt < retries - 1:
                    time.sleep(_backoff_seconds(attempt))
                    continue
                break
            breaker.record_success()
            return payload

        if resp.status_code == 429:
            retry_after = _parse_retry_after(resp, API_RATE_LIMIT_SLEEP_SECONDS)
            token_manager.mark_rate_limited(current_token, retry_after)
            logger.warning(
                "Rate limit atteint sur %s, attente %.1fs (tentative %d/%d)",
                url,
                retry_after,
                attempt + 1,
                retries,
            )
            time.sleep(retry_after)
            continue

        if resp.status_code in (401, 403):
            last_error = f"Auth error {resp.status_code}: {resp.text[:200]}"
            logger.error(
                "Erreur d'authentification (%d) sur %s avec token %s***",
                resp.status_code,
                url,
                current_token[:6],
            )
            token_manager.mark_rate_limited(current_token, 60.0)
            if attempt < retries - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break

        if resp.status_code == 404:
            breaker.record_success()
            logger.info("Ressource introuvable (404) : %s", url)
            return None

        if 500 <= resp.status_code < 600:
            last_error = f"ServerError {resp.status_code}: {resp.text[:200]}"
            breaker.record_failure()
            logger.warning(
                "Erreur serveur %d sur %s (tentative %d/%d)",
                resp.status_code,
                url,
                attempt + 1,
                retries,
            )
            if attempt < retries - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break

        last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
        logger.error(
            "Réponse inattendue %d sur %s : %s",
            resp.status_code,
            url,
            resp.text[:200],
        )
        if attempt < retries - 1:
            time.sleep(_backoff_seconds(attempt))
            continue
        break

    logger.error(
        "Échec définitif de la requête vers %s après %d tentatives : %s",
        url,
        retries,
        last_error,
    )
    return None


def _validate_date_str(date_str: str) -> bool:
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except (TypeError, ValueError):
        return False


def get_matches_global(date_str: str) -> List[Dict[str, Any]]:
    if not _validate_date_str(date_str):
        raise FootballDataAPIError(f"Format de date invalide : {date_str}")
    url = f"{API_BASE_URL}/matches"
    data = make_request(url, params={"date": date_str})
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_matches_by_competition(
    code: str,
    date_from: str,
    date_to: Optional[str] = None,
) -> List[Dict[str, Any]]:
    if not _validate_date_str(date_from):
        raise FootballDataAPIError(f"Format de date_from invalide : {date_from}")
    if date_to is None:
        date_to = date_from
    if not _validate_date_str(date_to):
        raise FootballDataAPIError(f"Format de date_to invalide : {date_to}")
    if date_from > date_to:
        raise FootballDataAPIError(f"Plage de dates invalide : {date_from} > {date_to}")
    url = f"{API_BASE_URL}/competitions/{code}/matches"
    params = {"dateFrom": date_from, "dateTo": date_to}
    data = make_request(url, params=params)
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_all_matches_for_date(date_str: str) -> Tuple[List[Dict[str, Any]], str]:
    if not _validate_date_str(date_str):
        raise FootballDataAPIError(f"Format de date invalide : {date_str}")

    matches = get_matches_global(date_str)
    if matches:
        target_codes = set(COMPETITIONS)
        filtered = [
            m
            for m in matches
            if isinstance(m.get("competition"), dict)
            and m["competition"].get("code") in target_codes
        ]
        if filtered:
            return filtered, "global"
        logger.info(
            "Aucun match des compétitions suivies trouvé dans la réponse globale "
            "du %s — repli sur récupération par compétition.",
            date_str,
        )

    all_matches: List[Dict[str, Any]] = []
    seen_ids: set = set()
    for code in COMPETITIONS:
        try:
            fetched = get_matches_by_competition(code, date_str)
        except FootballDataAPIError as exc:
            logger.error("Erreur récupération compétition %s : %s", code, exc)
            fetched = []
        for m in fetched:
            if not isinstance(m, dict):
                continue
            match_id = m.get("id")
            if match_id is not None and match_id in seen_ids:
                continue
            if match_id is not None:
                seen_ids.add(match_id)
            all_matches.append(m)
        time.sleep(API_COMPETITION_SLEEP_SECONDS)
    return all_matches, "competitions"


def _season_date_ranges(seasons_lookback: int) -> List[Tuple[str, str]]:
    today = datetime.now(timezone.utc).date()
    ranges: List[Tuple[str, str]] = []
    if today.month >= DEFAULT_SEASON_START_MONTH:
        first_start_year = today.year
    else:
        first_start_year = today.year - 1
    for offset in range(seasons_lookback):
        start_year = first_start_year - offset
        try:
            season_start = date(
                start_year, DEFAULT_SEASON_START_MONTH, DEFAULT_SEASON_START_DAY
            )
            season_end = date(
                start_year + 1, DEFAULT_SEASON_END_MONTH, DEFAULT_SEASON_END_DAY
            )
        except ValueError:
            continue
        if season_end > today:
            season_end = today
        if season_start > today:
            continue
        if season_end < season_start:
            continue
        ranges.append((season_start.isoformat(), season_end.isoformat()))
    return ranges


def _iter_date_chunks(
    date_from: str, date_to: str, chunk_days: int
) -> List[Tuple[str, str]]:
    try:
        start = datetime.strptime(date_from, "%Y-%m-%d").date()
        end = datetime.strptime(date_to, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return []
    if start > end:
        return []
    chunk_days = max(1, int(chunk_days))
    chunks: List[Tuple[str, str]] = []
    current = start
    while current <= end:
        chunk_end = current + timedelta(days=chunk_days - 1)
        if chunk_end > end:
            chunk_end = end
        chunks.append((current.isoformat(), chunk_end.isoformat()))
        current = chunk_end + timedelta(days=1)
    return chunks


def get_historical_matches(
    seasons_lookback: int = HISTORICAL_SEASONS_LOOKBACK,
) -> List[Dict[str, Any]]:
    all_matches: List[Dict[str, Any]] = []
    seen_ids: set = set()
    date_ranges = _season_date_ranges(seasons_lookback)
    if not date_ranges:
        logger.warning("Aucune plage de saisons à récupérer")
        return all_matches

    for code in COMPETITIONS:
        competition_count = 0
        competition_failed_chunks = 0
        for date_from, date_to in date_ranges:
            chunks = _iter_date_chunks(date_from, date_to, API_CHUNK_DAYS)
            for chunk_from, chunk_to in chunks:
                url = f"{API_BASE_URL}/competitions/{code}/matches"
                params = {"dateFrom": chunk_from, "dateTo": chunk_to}
                data = make_request(url, params=params)
                if not data:
                    competition_failed_chunks += 1
                    continue
                chunk_matches = data.get("matches", [])
                if not isinstance(chunk_matches, list):
                    continue
                for m in chunk_matches:
                    if not isinstance(m, dict):
                        continue
                    match_id = m.get("id")
                    if match_id is not None and match_id in seen_ids:
                        continue
                    if match_id is not None:
                        seen_ids.add(match_id)
                    all_matches.append(m)
                    competition_count += 1
                time.sleep(API_COMPETITION_SLEEP_SECONDS)
        logger.info(
            "Compétition %s : %d matchs historiques récupérés (%d chunks échoués)",
            code,
            competition_count,
            competition_failed_chunks,
        )
    logger.info("Total matchs historiques récupérés : %d", len(all_matches))
    return all_matches


def get_competition_standings(code: str) -> Optional[Dict[str, Any]]:
    if not isinstance(code, str) or not code.strip():
        raise FootballDataAPIError(f"Code compétition invalide : {code}")
    url = f"{API_BASE_URL}/competitions/{code.strip().upper()}/standings"
    return make_request(url)


def get_head_to_head(match_id: int, limit: int = 20) -> List[Dict[str, Any]]:
    if not isinstance(match_id, int) or match_id <= 0:
        raise FootballDataAPIError(f"match_id invalide : {match_id}")
    limit = max(1, min(int(limit), 100))
    url = f"{API_BASE_URL}/matches/{match_id}/head2head"
    data = make_request(url, params={"limit": limit})
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_team_matches(
    team_id: int,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    if not isinstance(team_id, int) or team_id <= 0:
        raise FootballDataAPIError(f"team_id invalide : {team_id}")
    limit = max(1, min(int(limit), 500))
    url = f"{API_BASE_URL}/teams/{team_id}/matches"
    params: Dict[str, Any] = {"limit": limit}
    if date_from is not None:
        if not _validate_date_str(date_from):
            raise FootballDataAPIError(f"Format de date_from invalide : {date_from}")
        params["dateFrom"] = date_from
    if date_to is not None:
        if not _validate_date_str(date_to):
            raise FootballDataAPIError(f"Format de date_to invalide : {date_to}")
        params["dateTo"] = date_to
    if date_from is not None and date_to is not None and date_from > date_to:
        raise FootballDataAPIError(f"Plage invalide : {date_from} > {date_to}")
    if status is not None:
        params["status"] = str(status)
    data = make_request(url, params=params)
    if not data:
        return []
    matches = data.get("matches", [])
    return matches if isinstance(matches, list) else []


def get_competition_teams(code: str) -> List[Dict[str, Any]]:
    if not isinstance(code, str) or not code.strip():
        raise FootballDataAPIError(f"Code compétition invalide : {code}")
    url = f"{API_BASE_URL}/competitions/{code.strip().upper()}/teams"
    data = make_request(url)
    if not data:
        return []
    teams = data.get("teams", [])
    return teams if isinstance(teams, list) else []


def _respect_odds_rate_limit() -> None:
    per_minute = max(1, int(ODDS_REQUESTS_PER_MINUTE))
    min_interval = 60.0 / float(per_minute)
    with _odds_rate_lock:
        now = time.monotonic()
        last = _odds_last_request.get("global", 0.0)
        wait = min_interval - (now - last)
        if wait > 0:
            time.sleep(wait)
        _odds_last_request["global"] = time.monotonic()


def fetch_odds_h2h(sport_key: str) -> List[Dict[str, Any]]:
    if not ODDS_API_ENABLED or not ODDS_API_KEY:
        return []
    if not isinstance(sport_key, str) or not sport_key.strip():
        return []

    host = _host_from_url(ODDS_API_BASE_URL)
    breaker = _get_circuit_breaker(host)
    if breaker.is_open():
        snap = breaker.snapshot()
        logger.warning(
            "Circuit breaker odds-api ouvert (cooldown restant %.1fs)",
            snap["cooldown_remaining"],
        )
        return []

    url = f"{ODDS_API_BASE_URL}/sports/{sport_key.strip()}/odds"
    params = {
        "apiKey": ODDS_API_KEY,
        "regions": ODDS_REGIONS,
        "markets": ODDS_MARKETS,
        "oddsFormat": ODDS_ODDS_FORMAT,
    }

    attempts = max(1, int(API_MAX_RETRIES))
    last_error: Optional[str] = None
    for attempt in range(attempts):
        _respect_odds_rate_limit()
        try:
            resp = _odds_session.get(
                url, params=params, timeout=float(API_TIMEOUT_SECONDS)
            )
        except requests.exceptions.Timeout as exc:
            last_error = f"Timeout: {exc}"
            breaker.record_failure()
            if attempt < attempts - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break
        except requests.exceptions.ConnectionError as exc:
            last_error = f"ConnectionError: {exc}"
            breaker.record_failure()
            if attempt < attempts - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break
        except requests.exceptions.RequestException as exc:
            last_error = f"RequestException: {exc}"
            breaker.record_failure()
            if attempt < attempts - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break

        if resp.status_code == 200:
            try:
                payload = resp.json()
            except ValueError as exc:
                last_error = f"JSONDecodeError: {exc}"
                if attempt < attempts - 1:
                    time.sleep(_backoff_seconds(attempt))
                    continue
                break
            breaker.record_success()
            return payload if isinstance(payload, list) else []

        if resp.status_code == 401:
            breaker.record_failure()
            logger.warning("odds-api : clé invalide ou quota dépassé (401)")
            return []

        if resp.status_code == 422:
            breaker.record_success()
            logger.debug("odds-api : sport_key inconnu (%s)", sport_key)
            return []

        if resp.status_code == 429:
            retry_after = _parse_retry_after(resp, API_RATE_LIMIT_SLEEP_SECONDS)
            logger.warning(
                "odds-api : rate limit, attente %.1fs (tentative %d/%d)",
                retry_after,
                attempt + 1,
                attempts,
            )
            time.sleep(retry_after)
            continue

        if 500 <= resp.status_code < 600:
            last_error = f"ServerError {resp.status_code}"
            breaker.record_failure()
            if attempt < attempts - 1:
                time.sleep(_backoff_seconds(attempt))
                continue
            break

        last_error = f"HTTP {resp.status_code}"
        logger.debug(
            "odds-api : réponse inattendue %d pour %s", resp.status_code, sport_key
        )
        if attempt < attempts - 1:
            time.sleep(_backoff_seconds(attempt))
            continue
        break

    logger.debug("odds-api : échec définitif pour %s — %s", sport_key, last_error)
    return []


def get_api_diagnostics() -> Dict[str, Any]:
    return {
        "tokens": token_manager.snapshot(),
        "circuit_breakers": {
            host: cb.snapshot() for host, cb in _circuit_breakers.items()
        },
        "odds_enabled": bool(ODDS_API_ENABLED and ODDS_API_KEY),
    }

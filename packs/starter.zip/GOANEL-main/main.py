import os
import sys
import signal
import logging
import argparse
import traceback
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from config import (
    COMPETITIONS_DETAILS,
    COMPETITIONS,
    CACHE_DIR,
    stage_print,
    now_local,
)
from predict import load_or_build_data_and_models, predict_for_date

logger = logging.getLogger("goangel.main")

BANNER_LINES: List[str] = [
    r"  ██████   ██████  █████   ███    ██ ███████ ██      ",
    r" ██       ██    ██ ██   ██ ████   ██ ██      ██      ",
    r" ██   ███ ██    ██ ███████ ██ ██  ██ █████   ██      ",
    r" ██    ██ ██    ██ ██   ██ ██  ██ ██ ██      ██      ",
    r"  ██████   ██████  ██   ██ ██   ████ ███████ ███████ ",
]

COLORS: List[str] = [
    "\033[31m",
    "\033[33m",
    "\033[32m",
    "\033[36m",
    "\033[34m",
    "\033[35m",
]
RESET: str = "\033[0m"
BOLD: str = "\033[1m"
RED: str = "\033[1;31m"
GREEN: str = "\033[1;32m"
YELLOW: str = "\033[1;33m"
CYAN: str = "\033[1;36m"

_SHUTDOWN_FLAG: Dict[str, bool] = {"requested": False}


def _colorize(text: str, color: str) -> str:
    return f"{color}{text}{RESET}"


def print_banner() -> None:
    for i, line in enumerate(BANNER_LINES):
        print(f"{COLORS[i % len(COLORS)]}{line}{RESET}")
    print(f"{YELLOW}Prédictions sportives — Tous modèles{RESET}")
    print()


def clear_screen() -> None:
    try:
        os.system("clear" if os.name == "posix" else "cls")
    except Exception:
        pass
    print_banner()


def _now_local() -> datetime:
    return now_local()


def _ddmmyyyy_to_iso(date_str: str) -> str:
    return datetime.strptime(date_str.strip(), "%d/%m/%Y").strftime("%Y-%m-%d")


def _iso_to_ddmmyyyy(date_str: str) -> str:
    return datetime.strptime(date_str, "%Y-%m-%d").strftime("%d/%m/%Y")


def validate_date_ddmmyyyy(date_str: str) -> bool:
    if not isinstance(date_str, str):
        return False
    s = date_str.strip()
    if len(s) != 10:
        return False
    try:
        parsed = datetime.strptime(s, "%d/%m/%Y")
    except (TypeError, ValueError):
        return False
    if parsed.year < 1990 or parsed.year > 2100:
        return False
    return True


def display_competitions() -> None:
    print(f"\n{CYAN}Compétitions suivies ({len(COMPETITIONS_DETAILS)}) :{RESET}")
    for comp in COMPETITIONS_DETAILS:
        print(
            f"  {comp.flag} {comp.code:4s} "
            f"{comp.name} ({comp.country}) Tier {comp.tier} — groupe {comp.group}"
        )


def display_help() -> None:
    print(f"\n{CYAN}Commandes disponibles :{RESET}")
    print("  <DD/MM/YYYY>   Prédire les matchs de la date indiquée")
    print("  today          Prédire les matchs du jour")
    print("  yesterday      Prédire les matchs d'hier")
    print("  tomorrow       Prédire les matchs de demain")
    print("  refresh        Reconstruire les données et réentraîner les modèles")
    print("  competitions   Afficher les compétitions suivies")
    print("  clear          Effacer l'écran")
    print("  help           Afficher cette aide")
    print("  quit / exit    Quitter le programme")


def _handle_sigint(signum: int, frame: Any) -> None:
    if _SHUTDOWN_FLAG["requested"]:
        print(f"\n{RED}Arrêt forcé.{RESET}")
        os._exit(130)
    _SHUTDOWN_FLAG["requested"] = True
    print(
        f"\n{YELLOW}Interruption détectée. "
        f"Appuyez de nouveau sur Ctrl+C pour forcer, ou tapez 'quit'.{RESET}"
    )


def _handle_sigterm(signum: int, frame: Any) -> None:
    logger.info("SIGTERM reçu, arrêt propre.")
    print(f"\n{YELLOW}Arrêt demandé.{RESET}")
    sys.exit(0)


def _install_signal_handlers() -> None:
    try:
        signal.signal(signal.SIGINT, _handle_sigint)
    except (ValueError, OSError):
        pass
    try:
        signal.signal(signal.SIGTERM, _handle_sigterm)
    except (ValueError, OSError, AttributeError):
        pass


def _safe_reload_models(state: Dict[str, Any], force_refresh: bool) -> bool:
    try:
        result = load_or_build_data_and_models(force_refresh=force_refresh)
    except Exception as exc:
        logger.error("Échec du chargement des modèles : %s", exc)
        logger.debug(traceback.format_exc())
        print(f"{RED}Échec du chargement des modèles : {exc}{RESET}")
        return False

    if not isinstance(result, tuple) or len(result) != 5:
        logger.error(
            "Signature inattendue de load_or_build_data_and_models : %r",
            type(result),
        )
        print(f"{RED}Signature de chargement invalide.{RESET}")
        return False

    ml_models, pb_models, scaler, df_past, weights = result

    if df_past is None or getattr(df_past, "empty", True):
        logger.warning("Historique vide, les prédictions seront dégradées.")
        print(f"{YELLOW}Attention : aucun historique exploitable.{RESET}")

    if not ml_models and not pb_models:
        logger.warning("Aucun modèle entraîné disponible.")
        print(f"{YELLOW}Attention : aucun modèle entraîné.{RESET}")

    state["ml_models"] = ml_models
    state["pb_models"] = pb_models
    state["scaler"] = scaler
    state["df_past"] = df_past
    state["weights"] = weights
    return True


def _predict_date(state: Dict[str, Any], date_iso: str) -> bool:
    try:
        predict_for_date(
            date_iso,
            state.get("ml_models"),
            state.get("pb_models"),
            state.get("scaler"),
            state.get("df_past"),
            state.get("weights"),
        )
        return True
    except Exception as exc:
        logger.error("Erreur de prédiction pour %s : %s", date_iso, exc)
        logger.debug(traceback.format_exc())
        print(f"{RED}Erreur lors de la prédiction : {exc}{RESET}")
        return False


def _resolve_date_command(user_input: str) -> Optional[str]:
    ui = user_input.strip().lower()
    now = _now_local()
    if ui == "today":
        return now.strftime("%Y-%m-%d")
    if ui == "yesterday":
        return (now - timedelta(days=1)).strftime("%Y-%m-%d")
    if ui == "tomorrow":
        return (now + timedelta(days=1)).strftime("%Y-%m-%d")
    return None


def run_interactive(state: Dict[str, Any]) -> int:
    stage_print(
        "🤖 MOTEUR GOANGEL PRÊT — SAISISSEZ UNE DATE (DD/MM/YYYY) "
        "OU UNE COMMANDE (help pour la liste)."
    )
    while True:
        try:
            user_input = input(
                f"\n📅 Date (DD/MM/YYYY) ou commande "
                f"({YELLOW}quit{RESET} pour quitter) : "
            )
        except (EOFError, KeyboardInterrupt):
            print("\nAu revoir.")
            return 0

        if _SHUTDOWN_FLAG["requested"]:
            print(f"{YELLOW}Arrêt demandé.{RESET}")
            return 0

        if user_input is None:
            continue

        user_input = user_input.strip()
        if not user_input:
            continue

        ui = user_input.lower()

        if ui in ("quit", "exit", "q"):
            print("Fermeture de GOANGEL.")
            return 0

        if ui == "clear":
            clear_screen()
            continue

        if ui == "help":
            display_help()
            continue

        if ui == "competitions":
            display_competitions()
            continue

        if ui == "refresh":
            print(
                f"{CYAN}Reconstruction complète des données et modèles "
                f"en cours...{RESET}"
            )
            ok = _safe_reload_models(state, force_refresh=True)
            if ok:
                print(f"{GREEN}Reconstruction terminée.{RESET}")
            continue

        resolved = _resolve_date_command(ui)
        if resolved is not None:
            date_iso = resolved
        else:
            if not validate_date_ddmmyyyy(user_input):
                print(f"{RED}Format de date invalide. Utilisez DD/MM/YYYY.{RESET}")
                continue
            try:
                date_iso = _ddmmyyyy_to_iso(user_input)
            except Exception:
                print(f"{RED}Date impossible à convertir.{RESET}")
                continue

        try:
            pretty = _iso_to_ddmmyyyy(date_iso)
        except Exception:
            pretty = date_iso

        print(f"\n🔍 Recherche des matchs du {pretty}...")
        _predict_date(state, date_iso)
        print("\n" + "=" * 60)


def run_single_date(date_ddmmyyyy: str, state: Dict[str, Any]) -> int:
    if not validate_date_ddmmyyyy(date_ddmmyyyy):
        logger.error("Format de date invalide : %s", date_ddmmyyyy)
        print(f"{RED}Format de date invalide. Utilisez DD/MM/YYYY.{RESET}")
        return 2
    try:
        date_iso = _ddmmyyyy_to_iso(date_ddmmyyyy)
    except Exception:
        print(f"{RED}Date impossible à convertir.{RESET}")
        return 2
    ok = _predict_date(state, date_iso)
    return 0 if ok else 1


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="goangel",
        description="GOANGEL — Moteur de prédictions sportives multi-modèles",
    )
    parser.add_argument(
        "--date",
        type=str,
        default=None,
        help="Date au format DD/MM/YYYY pour une exécution non interactive",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Force la reconstruction complète du cache et des modèles",
    )
    parser.add_argument(
        "--no-banner",
        action="store_true",
        help="N'affiche pas la bannière",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Réduit la sortie console au strict minimum",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    _install_signal_handlers()
    args = _parse_args(argv)

    if not args.no_banner and not args.quiet:
        print_banner()
    if not args.quiet:
        stage_print("🤖 DÉMARRAGE INITIAL")
    logger.info(
        "Démarrage de GOANGEL (argv=%s)",
        argv if argv is not None else sys.argv[1:],
    )

    state: Dict[str, Any] = {
        "ml_models": None,
        "pb_models": None,
        "scaler": None,
        "df_past": None,
        "weights": {},
    }

    if not _safe_reload_models(state, force_refresh=args.refresh):
        logger.critical("Arrêt : impossible de charger les modèles.")
        if not args.quiet:
            stage_print("❌ Erreur fatale lors du chargement des modèles.")
        return 1

    if args.date:
        return run_single_date(args.date, state)

    try:
        return run_interactive(state)
    except KeyboardInterrupt:
        print("\nAu revoir.")
        return 130
    except Exception as exc:
        logger.critical("Erreur non gérée : %s", exc)
        logger.debug(traceback.format_exc())
        print(f"{RED}Erreur inattendue : {exc}{RESET}")
        return 1


if __name__ == "__main__":
    sys.exit(main())

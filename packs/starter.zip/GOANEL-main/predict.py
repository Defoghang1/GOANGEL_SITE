import os
import time
import pickle
import logging
import difflib
import unicodedata
from datetime import datetime as dt, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.stats import poisson

try:
    import torch
except ImportError:
    torch = None

from features import (
    process_matches,
    train_models,
    build_feature_vector,
    build_tracking_state,
    TeamHistoryTracker,
    EloSystem,
    EXPECTED_FEATURE_COUNT,
    _extract_market_probabilities,
)
from api import get_all_matches_for_date, get_historical_matches, fetch_odds_h2h
from config import (
    CACHE_DIR,
    HISTORICAL_FILE,
    MODELS_FILE,
    SCALER_FILE,
    WEIGHTS_FILE,
    CACHE_TTL_HOURS,
    CACHE_NEVER_EXPIRES,
    CACHE_ATOMIC_WRITE,
    MIN_MATCHES_FOR_TRAINING,
    MIN_REALISTIC_LAMBDA,
    MAX_REALISTIC_LAMBDA,
    DEFAULT_HOME_LAMBDA,
    DEFAULT_AWAY_LAMBDA,
    MAX_GOALS_GRID,
    DIXON_COLES_RHO,
    TEMPERATURE_SCALING_ENABLED,
    TEMPERATURE_SCALING_DEFAULT,
    TEMPERATURE_SCALING_MIN,
    TEMPERATURE_SCALING_MAX,
    ODDS_BLEND_WEIGHT,
    MODEL_BLEND_WEIGHT,
    ODDS_API_ENABLED,
    ODDS_API_SPORT_KEYS,
    ODDS_CACHE_TTL_MINUTES,
    ODDS_MATCH_NAME_MIN_SCORE,
    ENSEMBLE_DISAGREEMENT_THRESHOLD,
    REALISTIC_HOME_LAMBDA_BY_GROUP,
    REALISTIC_AWAY_LAMBDA_BY_GROUP,
    get_competition_group,
    stage_print,
)

logger = logging.getLogger("goangel.predict")

_odds_cache: Dict[str, Tuple[float, List[Dict[str, Any]]]] = {}

_MIN_TEAM_MATCH_SCORE: float = max(0.55, float(ODDS_MATCH_NAME_MIN_SCORE) - 0.10)
_MIN_OUTCOME_MATCH_SCORE: float = 0.65


def _cache_is_fresh(path: Path) -> bool:
    if CACHE_NEVER_EXPIRES:
        return path.exists()
    if not path.exists():
        return False
    mtime = dt.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    age_hours = (dt.now(timezone.utc) - mtime).total_seconds() / 3600.0
    return age_hours < CACHE_TTL_HOURS


def _atomic_write_pickle(path: Path, obj: Any) -> None:
    if not CACHE_ATOMIC_WRITE:
        with open(path, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
        return
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        with open(tmp_path, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_path, path)
    except Exception as exc:
        logger.error("Échec écriture atomique %s : %s", path, exc)
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass
        raise


def _strip_accents(text: str) -> str:
    try:
        normalized = unicodedata.normalize("NFKD", text)
        return normalized.encode("ASCII", "ignore").decode("ASCII")
    except Exception:
        return text


def _normalize_for_match(name: Any) -> str:
    if not isinstance(name, str):
        return ""
    s = _strip_accents(name).lower().strip()
    for suffix in (" fc", " cf", " ud", " cd", " sc", " ac", " afc", " cfc", " sk", " fk"):
        if s.endswith(suffix):
            s = s[: -len(suffix)]
    for token in (" de ", " la ", " el ", " los ", " ca ", " aa ", " rc ", " do ", " da ", " the "):
        s = s.replace(token, " ")
    s = "".join(ch if (ch.isalnum() or ch.isspace()) else " " for ch in s)
    return " ".join(s.split())


def _name_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    ratio = difflib.SequenceMatcher(None, a, b).ratio()
    tokens_a = set(a.split())
    tokens_b = set(b.split())
    if tokens_a and tokens_b:
        jaccard = len(tokens_a & tokens_b) / len(tokens_a | tokens_b)
    else:
        jaccard = 0.0
    return max(ratio, jaccard)


def _get_odds_events(sport_key: str) -> List[Dict[str, Any]]:
    now = time.monotonic()
    cached = _odds_cache.get(sport_key)
    if cached is not None and (now - cached[0]) < float(ODDS_CACHE_TTL_MINUTES) * 60.0:
        return cached[1]
    try:
        events = fetch_odds_h2h(sport_key)
    except Exception as exc:
        logger.debug("Erreur récupération cotes pour %s : %s", sport_key, exc)
        events = []
    if not isinstance(events, list):
        events = []
    _odds_cache[sport_key] = (now, events)
    return events


def _find_best_event(
    events: List[Dict[str, Any]],
    target_home: str,
    target_away: str,
) -> Optional[Dict[str, Any]]:
    best_score = 0.0
    best_event: Optional[Dict[str, Any]] = None
    for event in events:
        if not isinstance(event, dict):
            continue
        ev_home = _normalize_for_match(str(event.get("home_team", "")))
        ev_away = _normalize_for_match(str(event.get("away_team", "")))
        if not ev_home or not ev_away:
            continue
        score_home = _name_similarity(target_home, ev_home)
        score_away = _name_similarity(target_away, ev_away)
        if score_home < _MIN_TEAM_MATCH_SCORE or score_away < _MIN_TEAM_MATCH_SCORE:
            continue
        combined = (score_home + score_away) / 2.0
        if combined > best_score:
            best_score = combined
            best_event = event
    return best_event


def _match_outcome_odds(
    odds_map: Dict[str, float],
    target_home: str,
    target_away: str,
) -> Optional[Tuple[float, float, float]]:
    if not odds_map:
        return None
    home_best_name: Optional[str] = None
    home_best_score = 0.0
    away_best_name: Optional[str] = None
    away_best_score = 0.0
    for name in odds_map.keys():
        s_home = _name_similarity(target_home, name)
        if s_home > home_best_score:
            home_best_score = s_home
            home_best_name = name
        s_away = _name_similarity(target_away, name)
        if s_away > away_best_score:
            away_best_score = s_away
            away_best_name = name

    if home_best_name is None or away_best_name is None:
        return None
    if home_best_score < _MIN_OUTCOME_MATCH_SCORE:
        return None
    if away_best_score < _MIN_OUTCOME_MATCH_SCORE:
        return None
    if home_best_name == away_best_name:
        return None

    draw_name: Optional[str] = None
    for name in odds_map.keys():
        if name in (home_best_name, away_best_name):
            continue
        if name in ("draw", "tie", "x", "nul", "empate", "gleichstand"):
            draw_name = name
            break
    if draw_name is None:
        remaining = [n for n in odds_map.keys() if n not in (home_best_name, away_best_name)]
        if remaining:
            draw_name = remaining[0]
    if draw_name is None:
        return None

    home_odds = odds_map.get(home_best_name)
    away_odds = odds_map.get(away_best_name)
    draw_odds = odds_map.get(draw_name)
    if not home_odds or not away_odds or not draw_odds:
        return None
    if home_odds <= 1.0 or away_odds <= 1.0 or draw_odds <= 1.0:
        return None

    inv_home = 1.0 / home_odds
    inv_draw = 1.0 / draw_odds
    inv_away = 1.0 / away_odds
    total = inv_home + inv_draw + inv_away
    if total <= 0 or not np.isfinite(total):
        return None
    return (inv_home / total, inv_draw / total, inv_away / total)


def _extract_h2h_probs_from_event(
    event: Dict[str, Any],
    target_home: str,
    target_away: str,
) -> List[Tuple[float, float, float]]:
    results: List[Tuple[float, float, float]] = []
    bookmakers = event.get("bookmakers", [])
    if not isinstance(bookmakers, list):
        return results
    for bookmaker in bookmakers:
        if not isinstance(bookmaker, dict):
            continue
        markets = bookmaker.get("markets", [])
        if not isinstance(markets, list):
            continue
        for market in markets:
            if not isinstance(market, dict) or market.get("key") != "h2h":
                continue
            outcomes = market.get("outcomes", [])
            if not isinstance(outcomes, list) or len(outcomes) < 3:
                continue
            odds_map: Dict[str, float] = {}
            for outcome in outcomes:
                if not isinstance(outcome, dict):
                    continue
                name = outcome.get("name")
                price = outcome.get("price")
                if name is None or price is None:
                    continue
                norm = _normalize_for_match(str(name))
                try:
                    odds_map[norm] = float(price)
                except (TypeError, ValueError):
                    continue
            triple = _match_outcome_odds(odds_map, target_home, target_away)
            if triple is not None:
                results.append(triple)
    return results


def _aggregate_bookmaker_probs(
    triples: List[Tuple[float, float, float]],
) -> Optional[Tuple[float, float, float]]:
    if not triples:
        return None
    if len(triples) == 1:
        return triples[0]
    arr = np.array(triples, dtype=np.float64)
    arr = arr[np.all(np.isfinite(arr), axis=1)]
    if arr.shape[0] == 0:
        return None
    if arr.shape[0] >= 3:
        median = np.median(arr, axis=0)
        abs_dev = np.abs(arr - median)
        mad = np.median(abs_dev, axis=0)
        mad[mad == 0] = 1.0
        z = np.abs((arr - median) / mad)
        keep = np.all(z <= 3.5, axis=1)
        if keep.sum() >= 1:
            arr = arr[keep]
    avg = arr.mean(axis=0)
    total = avg.sum()
    if total <= 0 or not np.isfinite(total):
        return None
    avg = avg / total
    return (float(avg[0]), float(avg[1]), float(avg[2]))


def get_odds_probabilities(
    home_raw: str,
    away_raw: str,
    competition_code: Optional[str],
) -> Optional[Tuple[float, float, float]]:
    if not ODDS_API_ENABLED or not competition_code:
        return None
    sport_key = ODDS_API_SPORT_KEYS.get(competition_code)
    if not sport_key:
        return None
    events = _get_odds_events(sport_key)
    if not events:
        return None

    target_home = _normalize_for_match(home_raw)
    target_away = _normalize_for_match(away_raw)
    if not target_home or not target_away:
        return None

    event = _find_best_event(events, target_home, target_away)
    if event is None:
        return None

    triples = _extract_h2h_probs_from_event(event, target_home, target_away)
    if not triples:
        return None

    return _aggregate_bookmaker_probs(triples)


def _load_full_history() -> pd.DataFrame:
    stage_print("⚽ RÉCUPÉRATION DE L'HISTORIQUE COMPLET DES MATCHS")
    logger.info("Récupération de l'historique complet des matchs...")
    try:
        historical = get_historical_matches()
    except Exception as exc:
        logger.error("Erreur lors de la récupération historique : %s", exc)
        return pd.DataFrame()
    if not historical:
        logger.error("Aucun match historique récupéré depuis l'API")
        stage_print("🏆 TOTAL MATCHS HISTORIQUES RÉCUPÉRÉS : 0")
        return pd.DataFrame()
    df_hist = process_matches(historical)
    if df_hist.empty:
        logger.error("Le traitement des matchs historiques a produit un DataFrame vide")
        stage_print("🏆 TOTAL MATCHS HISTORIQUES RÉCUPÉRÉS : 0")
        return df_hist
    df_past = df_hist[df_hist["status"] == "FINISHED"].dropna(subset=["goals_home", "goals_away"]).copy()
    df_past = df_past.drop_duplicates(subset=["match_id"]).reset_index(drop=True)
    logger.info("%d matchs terminés valides récupérés sur %d matchs bruts", len(df_past), len(df_hist))
    stage_print(f"🏆 TOTAL MATCHS HISTORIQUES RÉCUPÉRÉS : {len(df_past)}")
    return df_past


def load_or_build_data_and_models(
    force_refresh: bool = False,
) -> Tuple[
    Optional[Dict[str, Any]],
    Optional[List[Tuple[str, Any]]],
    Any,
    pd.DataFrame,
    Dict[str, float],
]:
    cache_files = [HISTORICAL_FILE, MODELS_FILE, SCALER_FILE, WEIGHTS_FILE]
    if not force_refresh and all(f.exists() for f in cache_files) and _cache_is_fresh(HISTORICAL_FILE):
        try:
            with open(HISTORICAL_FILE, "rb") as f:
                df_past = pickle.load(f)
            with open(MODELS_FILE, "rb") as f:
                ml_models, pb_models = pickle.load(f)
            with open(SCALER_FILE, "rb") as f:
                scaler = pickle.load(f)
            with open(WEIGHTS_FILE, "rb") as f:
                weights = pickle.load(f)
            if hasattr(scaler, "n_features_in_") and scaler.n_features_in_ != EXPECTED_FEATURE_COUNT:
                logger.warning("Dimensions du scaler obsolètes. Reconstruction forcée.")
                force_refresh = True
            elif not isinstance(df_past, pd.DataFrame) or df_past.empty or "home_key" not in df_past.columns:
                logger.warning("Cache historique vide ou incompatible. Reconstruction forcée.")
                force_refresh = True
            else:
                logger.info("Données et modèles chargés depuis le cache.")
                stage_print("✅ Données et modèles chargés depuis le cache.")
                return ml_models, pb_models, scaler, df_past, weights
        except (pickle.PickleError, EOFError, AttributeError, ImportError, ValueError) as exc:
            logger.error("Erreur de chargement du cache : %s. Reconstruction forcée.", exc)
            force_refresh = True

    stage_print("⚙️ CONSTRUCTION INITIALE DES DONNÉES & MODÈLES")
    logger.info("Construction initiale des données et modèles...")
    df_past = _load_full_history()
    ml_models: Optional[Dict[str, Any]] = None
    pb_models: Optional[List[Tuple[str, Any]]] = None
    scaler: Any = None
    weights: Dict[str, float] = {}

    if not df_past.empty and len(df_past) >= MIN_MATCHES_FOR_TRAINING:
        try:
            ml_models, pb_models, scaler, weights = train_models(df_past)
        except Exception as exc:
            logger.error("Échec de l'entraînement : %s", exc)
            ml_models, pb_models, scaler, weights = None, None, None, {}
    else:
        logger.error("Historique insuffisant pour l'entraînement : %d matchs", len(df_past))
        stage_print("❌ Historique insuffisant pour entraîner les modèles")

    stage_print("🤖 FIN DE CHARGEMENT DES MODÈLES & DE L'ENTRAÎNEMENT")

    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _atomic_write_pickle(HISTORICAL_FILE, df_past)
        _atomic_write_pickle(MODELS_FILE, (ml_models, pb_models))
        _atomic_write_pickle(SCALER_FILE, scaler)
        _atomic_write_pickle(WEIGHTS_FILE, weights)
        logger.info("Cache sauvegardé.")
        stage_print(
            f"✅ MODÈLES ET DONNÉES SAUVEGARDÉS DANS ({CACHE_DIR}) "
            f"POUR ÉVITER LE RÉENTRAÎNEMENT COMPLET À CHAQUE LANCEMENT."
        )
    except OSError as exc:
        logger.error("Erreur lors de la sauvegarde du cache : %s", exc)
        stage_print("❌ Erreur lors de la sauvegarde du cache")

    return ml_models, pb_models, scaler, df_past, weights


def _dixon_coles_tau(i: int, j: int, lh: float, la: float, rho: float) -> float:
    if rho == 0.0:
        return 1.0
    if i == 0 and j == 0:
        tau = 1.0 - lh * la * rho
    elif i == 0 and j == 1:
        tau = 1.0 + lh * rho
    elif i == 1 and j == 0:
        tau = 1.0 + la * rho
    elif i == 1 and j == 1:
        tau = 1.0 - rho
    else:
        tau = 1.0
    if tau < 0.01:
        tau = 0.01
    return tau


def _poisson_matrix(
    lambda_home: float,
    lambda_away: float,
    rho: float = DIXON_COLES_RHO,
    max_goals: int = MAX_GOALS_GRID,
) -> np.ndarray:
    lambda_home = float(np.clip(lambda_home, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    lambda_away = float(np.clip(lambda_away, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    mat = np.zeros((max_goals, max_goals), dtype=np.float64)
    for i in range(max_goals):
        pi = poisson.pmf(i, lambda_home)
        for j in range(max_goals):
            pj = poisson.pmf(j, lambda_away)
            tau = _dixon_coles_tau(i, j, lambda_home, lambda_away, rho)
            mat[i, j] = pi * pj * tau
    total = mat.sum()
    if total > 0:
        mat = mat / total
    else:
        mat[0, 0] = 1.0
    return mat


def _markets_from_matrix(mat: np.ndarray) -> Dict[str, float]:
    n = mat.shape[0]
    prob_home = float(np.sum(np.triu(mat, k=1)))
    prob_draw = float(np.trace(mat))
    prob_away = float(np.sum(np.tril(mat, k=-1)))
    total = prob_home + prob_draw + prob_away
    if total > 0:
        prob_home /= total
        prob_draw /= total
        prob_away /= total
    over15 = float(sum(mat[i, j] for i in range(n) for j in range(n) if i + j > 1))
    over25 = float(sum(mat[i, j] for i in range(n) for j in range(n) if i + j > 2))
    btts_yes = float(sum(mat[i, j] for i in range(n) for j in range(n) if i > 0 and j > 0))
    return {
        "home_draw_away": [prob_home, prob_draw, prob_away],
        "over15": float(np.clip(over15, 0.0, 1.0)),
        "over25": float(np.clip(over25, 0.0, 1.0)),
        "btts_yes": float(np.clip(btts_yes, 0.0, 1.0)),
    }


def _estimate_lambdas_from_history(
    home_key: str,
    away_key: str,
    tracker: TeamHistoryTracker,
    elo_system: EloSystem,
    competition_code: Optional[str],
    avg_h: float,
    avg_a: float,
) -> Tuple[float, float]:
    home_hist = tracker.snapshot(home_key)
    away_hist = tracker.snapshot(away_key)

    group = get_competition_group(competition_code)
    prior_home = float(REALISTIC_HOME_LAMBDA_BY_GROUP.get(group, avg_h if avg_h > 0 else DEFAULT_HOME_LAMBDA))
    prior_away = float(REALISTIC_AWAY_LAMBDA_BY_GROUP.get(group, avg_a if avg_a > 0 else DEFAULT_AWAY_LAMBDA))

    def _mean(values: List[float]) -> Optional[float]:
        if not values:
            return None
        arr = np.asarray(values, dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return None
        return float(arr.mean())

    home_gf = _mean(home_hist["gf"])
    home_ga = _mean(home_hist["ga"])
    away_gf = _mean(away_hist["gf"])
    away_ga = _mean(away_hist["ga"])

    home_home_gf = _mean(home_hist["home_gf"])
    home_home_ga = _mean(home_hist["home_ga"])
    away_away_gf = _mean(away_hist["away_gf"])
    away_away_ga = _mean(away_hist["away_ga"])

    home_elo = elo_system.get_rating(home_key)
    away_elo = elo_system.get_rating(away_key)
    elo_diff = home_elo - away_elo
    elo_scale = float(np.clip(elo_diff / 400.0, -1.5, 1.5))
    elo_factor_home = float(np.exp(0.20 * elo_scale))
    elo_factor_away = float(np.exp(-0.20 * elo_scale))

    attack_home_components: List[float] = []
    if home_gf is not None:
        attack_home_components.append(home_gf * 0.6 + prior_home * 0.4)
    if home_home_gf is not None:
        attack_home_components.append(home_home_gf * 0.5 + prior_home * 0.5)
    if away_ga is not None:
        attack_home_components.append(away_ga * 0.6 + prior_home * 0.4)
    if away_away_ga is not None:
        attack_home_components.append(away_away_ga * 0.5 + prior_home * 0.5)

    attack_away_components: List[float] = []
    if away_gf is not None:
        attack_away_components.append(away_gf * 0.6 + prior_away * 0.4)
    if away_away_gf is not None:
        attack_away_components.append(away_away_gf * 0.5 + prior_away * 0.5)
    if home_ga is not None:
        attack_away_components.append(home_ga * 0.6 + prior_away * 0.4)
    if home_home_ga is not None:
        attack_away_components.append(home_home_ga * 0.5 + prior_away * 0.5)

    base_home = float(np.mean(attack_home_components)) if attack_home_components else prior_home
    base_away = float(np.mean(attack_away_components)) if attack_away_components else prior_away

    lambda_home = base_home * elo_factor_home
    lambda_away = base_away * elo_factor_away

    matches_home = home_hist["matches_played"]
    matches_away = away_hist["matches_played"]
    reliability_home = float(np.clip(matches_home / 20.0, 0.0, 1.0))
    reliability_away = float(np.clip(matches_away / 20.0, 0.0, 1.0))

    lambda_home = reliability_home * lambda_home + (1.0 - reliability_home) * prior_home
    lambda_away = reliability_away * lambda_away + (1.0 - reliability_away) * prior_away

    lambda_home = float(np.clip(lambda_home, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    lambda_away = float(np.clip(lambda_away, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    return lambda_home, lambda_away


def _estimate_lambdas_from_feat(
    feat: np.ndarray,
    avg_h: float,
    avg_a: float,
) -> Tuple[float, float]:
    lambda_home = DEFAULT_HOME_LAMBDA if avg_h <= 0 else avg_h
    lambda_away = DEFAULT_AWAY_LAMBDA if avg_a <= 0 else avg_a
    if feat.size > 0 and feat.shape[1] > 3:
        try:
            home_gf_medium = float(feat[0][0])
            home_ga_medium = float(feat[0][1])
            away_gf_medium = float(feat[0][2])
            away_ga_medium = float(feat[0][3])
            if home_gf_medium > 0 and away_ga_medium > 0:
                lambda_home = (home_gf_medium + away_ga_medium) / 2.0
            if away_gf_medium > 0 and home_ga_medium > 0:
                lambda_away = (away_gf_medium + home_ga_medium) / 2.0
        except Exception:
            pass
    lambda_home = float(np.clip(lambda_home, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    lambda_away = float(np.clip(lambda_away, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    return lambda_home, lambda_away


def _sanitize_weights(weights: List[float]) -> np.ndarray:
    if not weights:
        return np.array([], dtype=np.float64)
    arr = np.asarray(weights, dtype=np.float64)
    arr = np.where(np.isfinite(arr), arr, 0.0)
    arr = np.where(arr < 0.0, 0.0, arr)
    total = arr.sum()
    if total <= 0:
        return np.ones_like(arr) / float(arr.size)
    return arr / total


def _apply_temperature(proba: np.ndarray, temperature: float) -> np.ndarray:
    if temperature is None or temperature <= 0:
        return proba
    if abs(temperature - 1.0) < 1e-6:
        return proba
    clipped = np.clip(proba, 1e-9, 1.0)
    logits = np.log(clipped) / float(temperature)
    logits -= logits.max()
    exp_logits = np.exp(logits)
    total = exp_logits.sum()
    if total <= 0:
        return proba
    return exp_logits / total


def _blend_with_odds(
    model_proba: np.ndarray,
    odds_proba: Optional[Tuple[float, float, float]],
) -> np.ndarray:
    if odds_proba is None:
        return model_proba
    odds_arr = np.array(odds_proba, dtype=np.float64)
    if odds_arr.shape != (3,) or not np.all(np.isfinite(odds_arr)):
        return model_proba
    if odds_arr.sum() <= 0:
        return model_proba
    odds_arr = odds_arr / odds_arr.sum()

    o_w = float(ODDS_BLEND_WEIGHT)
    m_w = float(MODEL_BLEND_WEIGHT)
    if o_w + m_w <= 0:
        return model_proba
    total_w = o_w + m_w
    o_w = o_w / total_w
    m_w = m_w / total_w

    blended = o_w * odds_arr + m_w * model_proba
    total = blended.sum()
    if total <= 0:
        return model_proba
    return blended / total


def _finalize_probabilities(proba: np.ndarray) -> np.ndarray:
    arr = np.array(proba, dtype=np.float64)
    if arr.shape != (3,) or not np.all(np.isfinite(arr)):
        return np.array([1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0])
    arr = np.clip(arr, 0.0, 1.0)
    total = arr.sum()
    if total <= 0:
        return np.array([1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0])
    return arr / total


def _model_predict_proba(
    model: Any,
    name: str,
    feat_scaled: np.ndarray,
) -> Optional[np.ndarray]:
    if model is None:
        return None

    predict_proba = getattr(model, "predict_proba", None)
    if callable(predict_proba):
        try:
            proba = predict_proba(feat_scaled)
            proba = np.asarray(proba, dtype=np.float64)
            if proba.ndim == 2 and proba.shape[0] >= 1:
                proba = proba[0]
            if proba.shape == (3,) and np.all(np.isfinite(proba)):
                return proba
        except Exception as exc:
            logger.debug("predict_proba a échoué pour %s : %s", name, exc)

    if torch is not None and isinstance(model, torch.nn.Module):
        try:
            model.eval()
            with torch.no_grad():
                tensor = torch.as_tensor(feat_scaled, dtype=torch.float32)
                logits = model(tensor)
                proba = torch.softmax(logits, dim=1).cpu().numpy()
                if proba.ndim == 2 and proba.shape[0] >= 1:
                    proba = proba[0]
                proba = np.asarray(proba, dtype=np.float64)
                if proba.shape == (3,) and np.all(np.isfinite(proba)):
                    return proba
        except Exception as exc:
            logger.debug("forward PyTorch a échoué pour %s : %s", name, exc)

    logger.debug("Aucune méthode de prédiction exploitable pour %s", name)
    return None


def _build_fallback_output(
    avg_h: float,
    avg_a: float,
    feat: np.ndarray,
    lambda_home: Optional[float],
    lambda_away: Optional[float],
    odds_probs: Optional[Tuple[float, float, float]] = None,
) -> Dict[str, Any]:
    if lambda_home is None or lambda_away is None:
        lambda_home, lambda_away = _estimate_lambdas_from_feat(feat, avg_h, avg_a)
    mat = _poisson_matrix(lambda_home, lambda_away)
    markets = _markets_from_matrix(mat)

    proba = np.array(markets["home_draw_away"], dtype=np.float64)
    proba = _blend_with_odds(proba, odds_probs)
    proba = _finalize_probabilities(proba)
    markets["home_draw_away"] = proba.tolist()

    markets["home_xg"] = float(lambda_home)
    markets["away_xg"] = float(lambda_away)
    markets["uncertainty"] = None
    markets["odds_used"] = odds_probs is not None
    markets["temperature"] = 1.0
    markets["fallback"] = True
    return markets


def predict_match(
    home_key: str,
    away_key: str,
    home_raw: str,
    away_raw: str,
    competition_code: Optional[str],
    ml_models: Optional[Dict[str, Any]],
    pb_models: Optional[List[Tuple[str, Any]]],
    scaler: Any,
    df_past: pd.DataFrame,
    tracker: TeamHistoryTracker,
    elo_system: EloSystem,
    weights: Dict[str, float],
    match_date: Optional[pd.Timestamp] = None,
) -> Dict[str, Any]:
    avg_h = float(df_past["goals_home"].mean()) if not df_past.empty else DEFAULT_HOME_LAMBDA
    avg_a = float(df_past["goals_away"].mean()) if not df_past.empty else DEFAULT_AWAY_LAMBDA

    odds_probs = get_odds_probabilities(home_raw, away_raw, competition_code)

    feat = build_feature_vector(
        home_key, away_key, tracker, elo_system, match_date,
        competition_code, odds_probs,
    )

    feat_arr = np.asarray(feat, dtype=np.float64)
    if feat_arr.ndim == 1:
        feat_arr = feat_arr.reshape(1, -1)

    if feat_arr.shape[1] != EXPECTED_FEATURE_COUNT:
        logger.warning(
            "Feature count inattendu : %d (attendu %d). Repli sur fallback pour %s vs %s.",
            feat_arr.shape[1], EXPECTED_FEATURE_COUNT, home_raw, away_raw,
        )
        return _build_fallback_output(
            avg_h, avg_a, feat_arr,
            None, None,
            odds_probs,
        )

    history_lambda_home, history_lambda_away = _estimate_lambdas_from_history(
        home_key, away_key, tracker, elo_system,
        competition_code, avg_h, avg_a,
    )

    if scaler is None or (not ml_models and not pb_models):
        return _build_fallback_output(
            avg_h, avg_a, feat_arr,
            history_lambda_home, history_lambda_away,
            odds_probs,
        )

    try:
        feat_scaled = scaler.transform(feat_arr)
    except Exception as exc:
        logger.error(
            "Erreur de transformation des features pour %s vs %s : %s",
            home_raw, away_raw, exc,
        )
        return _build_fallback_output(
            avg_h, avg_a, feat_arr,
            history_lambda_home, history_lambda_away,
            odds_probs,
        )

    hda_probas: List[np.ndarray] = []
    hda_weights: List[float] = []
    over15_list: List[float] = []
    over15_weights: List[float] = []
    over25_list: List[float] = []
    over25_weights: List[float] = []
    btts_list: List[float] = []
    btts_weights: List[float] = []
    xg_home_list: List[float] = []
    xg_away_list: List[float] = []
    xg_weights: List[float] = []

    if pb_models:
        n_pb = len(pb_models)
        for i, (class_name, m) in enumerate(pb_models):
            try:
                grid = m.predict(home_key, away_key)
                markets = _extract_market_probabilities(grid)
                w = float(weights.get(f"pb_{i}", 1.0 / n_pb))
                if not np.isfinite(w) or w < 0:
                    w = 0.0
                hda = markets.get("home_draw_away")
                if hda is not None:
                    hda_arr = np.array(hda, dtype=np.float64)
                    if hda_arr.shape == (3,) and np.all(np.isfinite(hda_arr)):
                        hda_probas.append(hda_arr)
                        hda_weights.append(w)
                if "over15" in markets:
                    over15_list.append(markets["over15"])
                    over15_weights.append(w)
                if "over25" in markets:
                    over25_list.append(markets["over25"])
                    over25_weights.append(w)
                if "btts_yes" in markets:
                    btts_list.append(markets["btts_yes"])
                    btts_weights.append(w)
                if "home_xg" in markets and "away_xg" in markets:
                    xg_home_list.append(markets["home_xg"])
                    xg_away_list.append(markets["away_xg"])
                    xg_weights.append(w)
            except Exception as exc:
                logger.debug(
                    "Modèle penaltyblog[%d=%s] a échoué pour %s vs %s : %s",
                    i, class_name, home_raw, away_raw, exc,
                )

    if ml_models:
        for name, m in ml_models.items():
            proba = _model_predict_proba(m, name, feat_scaled)
            if proba is None:
                continue
            w = float(weights.get(name, 0.0))
            if not np.isfinite(w) or w < 0:
                w = 0.0
            hda_probas.append(proba)
            hda_weights.append(w)

    if not hda_probas:
        return _build_fallback_output(
            avg_h, avg_a, feat_arr,
            history_lambda_home, history_lambda_away,
            odds_probs,
        )

    probas_matrix = np.array(hda_probas, dtype=np.float64)
    uncertainty: Optional[List[float]] = None
    if probas_matrix.shape[0] > 1:
        uncertainty = probas_matrix.std(axis=0).tolist()

    w_arr = _sanitize_weights(hda_weights)
    if w_arr.size == 0 or w_arr.size != probas_matrix.shape[0]:
        w_arr = np.ones(probas_matrix.shape[0]) / float(probas_matrix.shape[0])
    avg_hda = np.average(probas_matrix, axis=0, weights=w_arr)
    avg_hda = _finalize_probabilities(avg_hda)

    temperature = float(weights.get("__temperature__", TEMPERATURE_SCALING_DEFAULT))
    if not np.isfinite(temperature):
        temperature = float(TEMPERATURE_SCALING_DEFAULT)
    if TEMPERATURE_SCALING_ENABLED:
        temperature = float(np.clip(temperature, TEMPERATURE_SCALING_MIN, TEMPERATURE_SCALING_MAX))
    else:
        temperature = 1.0

    avg_hda = _apply_temperature(avg_hda, temperature)
    avg_hda = _blend_with_odds(avg_hda, odds_probs)
    avg_hda = _finalize_probabilities(avg_hda)

    if xg_home_list and xg_away_list:
        xg_weight_arr = _sanitize_weights(xg_weights)
        if xg_weight_arr.size != len(xg_home_list):
            xg_weight_arr = np.ones(len(xg_home_list)) / float(len(xg_home_list))
        lambda_home = float(np.average(xg_home_list, weights=xg_weight_arr))
        lambda_away = float(np.average(xg_away_list, weights=xg_weight_arr))
        lambda_home = 0.5 * lambda_home + 0.5 * history_lambda_home
        lambda_away = 0.5 * lambda_away + 0.5 * history_lambda_away
    else:
        lambda_home = history_lambda_home
        lambda_away = history_lambda_away

    lambda_home = float(np.clip(lambda_home, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))
    lambda_away = float(np.clip(lambda_away, MIN_REALISTIC_LAMBDA, MAX_REALISTIC_LAMBDA))

    fallback_markets = _markets_from_matrix(_poisson_matrix(lambda_home, lambda_away))

    if over15_list:
        over15_weight_arr = _sanitize_weights(over15_weights)
        if over15_weight_arr.size != len(over15_list):
            over15_weight_arr = np.ones(len(over15_list)) / float(len(over15_list))
        avg_over15 = float(np.average(over15_list, weights=over15_weight_arr))
    else:
        avg_over15 = fallback_markets["over15"]

    if over25_list:
        over25_weight_arr = _sanitize_weights(over25_weights)
        if over25_weight_arr.size != len(over25_list):
            over25_weight_arr = np.ones(len(over25_list)) / float(len(over25_list))
        avg_over25 = float(np.average(over25_list, weights=over25_weight_arr))
    else:
        avg_over25 = fallback_markets["over25"]

    if btts_list:
        btts_weight_arr = _sanitize_weights(btts_weights)
        if btts_weight_arr.size != len(btts_list):
            btts_weight_arr = np.ones(len(btts_list)) / float(len(btts_list))
        avg_btts = float(np.average(btts_list, weights=btts_weight_arr))
    else:
        avg_btts = fallback_markets["btts_yes"]

    return {
        "home_draw_away": avg_hda.tolist(),
        "over15": float(np.clip(avg_over15, 0.0, 1.0)),
        "over25": float(np.clip(avg_over25, 0.0, 1.0)),
        "btts_yes": float(np.clip(avg_btts, 0.0, 1.0)),
        "home_xg": lambda_home,
        "away_xg": lambda_away,
        "uncertainty": uncertainty,
        "odds_used": odds_probs is not None,
        "temperature": temperature,
        "fallback": False,
    }


def _print_match_prediction(
    row: pd.Series,
    markets: Dict[str, Any],
) -> None:
    home_display = row["home_raw"]
    away_display = row["away_raw"]
    comp = row.get("competition", "")
    proba = markets["home_draw_away"]

    print(f"\n{home_display} vs {away_display}  ({comp})")
    print(f"  Buts attendus : {markets['home_xg']:.2f} - {markets['away_xg']:.2f}")
    print(f"  Victoire {home_display} : {proba[0] * 100:.1f}%")
    print(f"  Nul : {proba[1] * 100:.1f}%")
    print(f"  Victoire {away_display} : {proba[2] * 100:.1f}%")
    print(f"  +1.5 buts : {markets['over15'] * 100:.1f}%")
    print(f"  +2.5 buts : {markets['over25'] * 100:.1f}%")
    print(f"  BTTS (les deux marquent) : {markets['btts_yes'] * 100:.1f}%")

    uncertainty = markets.get("uncertainty")
    if uncertainty is not None and len(uncertainty) == 3:
        max_std = max(uncertainty)
        print(
            f"  Incertitude inter-modèles (écart-type brut) : "
            f"{uncertainty[0]:.3f} / {uncertainty[1]:.3f} / {uncertainty[2]:.3f}"
        )
        if max_std > ENSEMBLE_DISAGREEMENT_THRESHOLD:
            print("  ⚠️  Fort désaccord entre modèles — prédiction peu fiable")

    if markets.get("odds_used"):
        print("  (cotes bookmaker en temps réel intégrées à cette prédiction)")

    temp = markets.get("temperature", 1.0)
    if TEMPERATURE_SCALING_ENABLED and abs(float(temp) - 1.0) > 1e-6:
        print(f"  (température de calibration appliquée : {float(temp):.3f})")

    if markets.get("fallback"):
        print("  (mode dégradé — estimation par Poisson enrichi)")


def predict_for_date(
    date_str: str,
    ml_models: Optional[Dict[str, Any]],
    pb_models: Optional[List[Tuple[str, Any]]],
    scaler: Any,
    df_past: pd.DataFrame,
    weights: Dict[str, float],
) -> None:
    try:
        matches, source = get_all_matches_for_date(date_str)
    except Exception as exc:
        logger.error("Erreur lors de la récupération des matchs du %s : %s", date_str, exc)
        print("\033[1;31mErreur lors de la récupération des matchs.\033[0m")
        return

    if not matches:
        print("❌ Aucun match trouvé.")
        return

    df_today = process_matches(matches)
    if df_today.empty:
        print("❌ Aucun match exploitable trouvé.")
        return

    df_future = df_today[
        (df_today["status"] != "FINISHED")
        & df_today["home_raw"].notna()
        & df_today["away_raw"].notna()
    ].copy()

    print(f"✅ {len(df_future)} matchs à venir (source: {source})")
    if len(df_future) == 0:
        print("Aucun match à venir.")
        return

    if df_past is None or df_past.empty or len(df_past) < MIN_MATCHES_FOR_TRAINING:
        avg_h = float(df_past["goals_home"].mean()) if df_past is not None and not df_past.empty else DEFAULT_HOME_LAMBDA
        avg_a = float(df_past["goals_away"].mean()) if df_past is not None and not df_past.empty else DEFAULT_AWAY_LAMBDA
        logger.warning("Historique insuffisant, estimation via Poisson enrichi par compétition.")
        tracker_empty = TeamHistoryTracker(default_gf=avg_h, default_ga=avg_a)
        elo_empty = EloSystem()
        if df_past is not None and not df_past.empty:
            tracker_empty, elo_empty = build_tracking_state(df_past)
        print("\n🔮 PRÉDICTIONS (mode dégradé) :")
        for _, row in df_future.iterrows():
            home_key = row["home_key"]
            away_key = row["away_key"]
            comp_code = row.get("competition_code")
            home_raw = row["home_raw"]
            away_raw = row["away_raw"]
            odds_probs = get_odds_probabilities(home_raw, away_raw, comp_code)
            feat = build_feature_vector(
                home_key, away_key, tracker_empty, elo_empty,
                row.get("date_parsed"), comp_code, odds_probs,
            )
            feat_arr = np.asarray(feat, dtype=np.float64)
            if feat_arr.ndim == 1:
                feat_arr = feat_arr.reshape(1, -1)
            lambda_home, lambda_away = _estimate_lambdas_from_history(
                home_key, away_key, tracker_empty, elo_empty,
                comp_code, avg_h, avg_a,
            )
            markets = _build_fallback_output(
                avg_h, avg_a, feat_arr,
                lambda_home, lambda_away,
                odds_probs,
            )
            _print_match_prediction(row, markets)
        return

    tracker, elo_system = build_tracking_state(df_past)

    print("\n🔮 PRÉDICTIONS :")
    for _, row in df_future.iterrows():
        home_display = row["home_raw"]
        away_display = row["away_raw"]
        home_key = row["home_key"]
        away_key = row["away_key"]
        comp = row.get("competition", "")
        comp_code = row.get("competition_code")
        match_date = row.get("date_parsed")
        try:
            markets = predict_match(
                home_key, away_key, home_display, away_display, comp_code,
                ml_models, pb_models, scaler, df_past,
                tracker, elo_system, weights, match_date,
            )
        except Exception as exc:
            logger.error(
                "Erreur de prédiction pour %s vs %s : %s",
                home_display, away_display, exc,
            )
            print(f"\n{home_display} vs {away_display}  ({comp})")
            print("  \033[1;31mErreur lors du calcul de la prédiction.\033[0m")
            continue

        _print_match_prediction(row, markets)

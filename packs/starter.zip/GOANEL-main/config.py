import os
import sys
import logging
import warnings
from pathlib import Path
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any, Callable
from functools import lru_cache
from dotenv import load_dotenv

try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

warnings.filterwarnings("ignore", message="X does not have valid feature names.*")
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn")

logger = logging.getLogger("goangel.config")

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH, override=False)
else:
    load_dotenv(override=False)

_ENV_LOADED = True


class ConfigError(Exception):
    pass


class ConfigValidationError(ConfigError):
    pass


class ConfigMissingError(ConfigError):
    pass


def _parse_tokens() -> List[str]:
    tokens_str = os.getenv("FOOTBALL_DATA_TOKENS", "").strip()
    tokens: List[str] = []
    if tokens_str:
        tokens = [
            t.strip().strip('"').strip("'")
            for t in tokens_str.split(",")
            if t.strip()
        ]
    if not tokens:
        single = os.getenv("FOOTBALL_DATA_TOKEN", "").strip().strip('"').strip("'")
        if single:
            tokens = [single]
    if not tokens:
        single = os.getenv("FOOTBALL_DATA_API_KEY", "").strip().strip('"').strip("'")
        if single:
            tokens = [single]
    seen: set = set()
    unique: List[str] = []
    for t in tokens:
        if len(t) < 10:
            logger.warning(
                "Token ignoré car trop court (%s caractères) : %s***",
                len(t), t[:4] if len(t) >= 4 else "?",
            )
            continue
        if t not in seen:
            seen.add(t)
            unique.append(t)
    if not unique:
        raise ConfigMissingError(
            "Aucun token API valide trouvé. Définissez FOOTBALL_DATA_TOKENS "
            "(séparés par des virgules), FOOTBALL_DATA_TOKEN ou "
            "FOOTBALL_DATA_API_KEY dans le fichier .env ou l'environnement."
        )
    return unique


def _parse_int_env(
    name: str,
    default: int,
    min_value: Optional[int] = None,
    max_value: Optional[int] = None,
) -> int:
    raw = os.getenv(name)
    if raw is None or not str(raw).strip():
        value = default
    else:
        try:
            value = int(str(raw).strip())
        except (TypeError, ValueError):
            raise ConfigValidationError(
                f"Variable d'environnement {name} invalide : {raw!r} n'est pas un entier"
            )
    if min_value is not None and value < min_value:
        raise ConfigValidationError(
            f"Variable d'environnement {name} doit être >= {min_value} (reçu {value})"
        )
    if max_value is not None and value > max_value:
        raise ConfigValidationError(
            f"Variable d'environnement {name} doit être <= {max_value} (reçu {value})"
        )
    return value


def _parse_float_env(
    name: str,
    default: float,
    min_value: Optional[float] = None,
    max_value: Optional[float] = None,
) -> float:
    raw = os.getenv(name)
    if raw is None or not str(raw).strip():
        value = default
    else:
        try:
            value = float(str(raw).strip())
        except (TypeError, ValueError):
            raise ConfigValidationError(
                f"Variable d'environnement {name} invalide : {raw!r} n'est pas un nombre"
            )
    if min_value is not None and value < min_value:
        raise ConfigValidationError(
            f"Variable d'environnement {name} doit être >= {min_value} (reçu {value})"
        )
    if max_value is not None and value > max_value:
        raise ConfigValidationError(
            f"Variable d'environnement {name} doit être <= {max_value} (reçu {value})"
        )
    return value


def _parse_bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not str(raw).strip():
        return default
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "y", "o")


def _parse_log_level(name: str, default: str) -> int:
    raw = os.getenv(name, default).strip().upper()
    level = getattr(logging, raw, None)
    if not isinstance(level, int):
        raise ConfigValidationError(
            f"Niveau de log invalide pour {name} : {raw!r}"
        )
    return level


def _parse_choice_env(name: str, default: str, choices: Tuple[str, ...]) -> str:
    raw = os.getenv(name, default).strip()
    if raw not in choices:
        raise ConfigValidationError(
            f"Variable {name} doit être l'une de {choices} (reçu {raw!r})"
        )
    return raw


@dataclass(frozen=True)
class Competition:
    code: str
    name: str
    country: str
    flag: str
    tier: int
    group: str = "OTHER"


@dataclass(frozen=True)
class ModelHyperparams:
    name: str
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True


_COMPETITIONS_DEFINITIONS: List[Competition] = [
    Competition("WC",  "Coupe du Monde",         "Monde",           "🌍", 1, "EUROPE_CUP"),
    Competition("EC",  "Championnat d'Europe",   "Europe",          "🇪🇺", 1, "EUROPE_CUP"),
    Competition("CL",  "Ligue des Champions",    "Europe",          "🏆", 1, "EUROPE_CUP"),
    Competition("EL",  "Ligue Europa",           "Europe",          "🥈", 1, "EUROPE_CUP"),
    Competition("PL",  "Premier League",         "Angleterre",      "🏴", 1, "EUROPE_TOP5"),
    Competition("PD",  "La Liga",                "Espagne",         "🇪🇸", 1, "EUROPE_TOP5"),
    Competition("BL1", "Bundesliga",             "Allemagne",       "🇩🇪", 1, "EUROPE_TOP5"),
    Competition("SA",  "Serie A",                "Italie",          "🇮🇹", 1, "EUROPE_TOP5"),
    Competition("FL1", "Ligue 1",                "France",          "🇫🇷", 1, "EUROPE_TOP5"),
    Competition("DED", "Eredivisie",             "Pays-Bas",        "🇳🇱", 2, "OTHER"),
    Competition("PPL", "Primeira Liga",          "Portugal",        "🇵🇹", 2, "OTHER"),
    Competition("ELC", "Championship",           "Angleterre",      "🏴", 2, "OTHER"),
    Competition("BSA", "Brasileirão",            "Brésil",          "🇧🇷", 2, "SOUTH_AMERICA"),
    Competition("CLI", "Copa Libertadores",      "Amérique du Sud", "🌎", 1, "SOUTH_AMERICA"),
]

COMPETITIONS: List[str] = [c.code for c in _COMPETITIONS_DEFINITIONS]
COMPETITIONS_DETAILS: List[Competition] = _COMPETITIONS_DEFINITIONS
COMPETITIONS_BY_CODE: Dict[str, Competition] = {c.code: c for c in _COMPETITIONS_DEFINITIONS}

COMPETITIONS_CATEGORICAL_INDEX: Dict[str, int] = {
    c.code: i for i, c in enumerate(_COMPETITIONS_DEFINITIONS)
}

COMPETITIONS_TIER_LEVEL: Dict[str, int] = {
    c.code: c.tier for c in _COMPETITIONS_DEFINITIONS
}

COMPETITIONS_TIER_INDEX: Dict[str, int] = COMPETITIONS_CATEGORICAL_INDEX

COMPETITION_GROUPS: Dict[str, List[str]] = {
    "EUROPE_TOP5":   ["PL", "PD", "BL1", "SA", "FL1"],
    "EUROPE_CUP":    ["CL", "EL", "EC", "WC"],
    "SOUTH_AMERICA": ["BSA", "CLI"],
    "OTHER":         ["DED", "PPL", "ELC"],
}

COMPETITION_GROUP_ORDER: Tuple[str, ...] = (
    "EUROPE_TOP5",
    "EUROPE_CUP",
    "SOUTH_AMERICA",
    "OTHER",
)

COMPETITION_GROUP_INDEX: Dict[str, int] = {
    name: idx for idx, name in enumerate(COMPETITION_GROUP_ORDER)
}

CODE_TO_GROUP: Dict[str, str] = {
    code: group
    for group, codes in COMPETITION_GROUPS.items()
    for code in codes
}


def get_competition_group(code: Optional[str]) -> str:
    if not code:
        return "OTHER"
    return CODE_TO_GROUP.get(code, "OTHER")


REALISTIC_HOME_LAMBDA_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   1.55,
    "EUROPE_CUP":    1.42,
    "SOUTH_AMERICA": 1.32,
    "OTHER":         1.50,
}

REALISTIC_AWAY_LAMBDA_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   1.25,
    "EUROPE_CUP":    1.18,
    "SOUTH_AMERICA": 0.98,
    "OTHER":         1.18,
}

REALISTIC_DRAW_RATE_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   0.24,
    "EUROPE_CUP":    0.25,
    "SOUTH_AMERICA": 0.29,
    "OTHER":         0.26,
}

REALISTIC_HOME_ADVANTAGE_BY_GROUP: Dict[str, float] = {
    "EUROPE_TOP5":   60.0,
    "EUROPE_CUP":    55.0,
    "SOUTH_AMERICA": 75.0,
    "OTHER":         60.0,
}


try:
    tokens: List[str] = _parse_tokens()
except ConfigError as exc:
    logger.critical("Erreur critique de configuration des tokens : %s", exc)
    raise

HEADERS: Dict[str, str] = {"X-Auth-Token": tokens[0]}

API_BASE_URL: str = os.getenv(
    "FOOTBALL_DATA_BASE_URL", "https://api.football-data.org/v4"
).rstrip("/")

API_TIMEOUT_SECONDS: float = _parse_float_env(
    "API_TIMEOUT_SECONDS", 15.0, min_value=1.0, max_value=120.0
)
API_MAX_RETRIES: int = _parse_int_env("API_MAX_RETRIES", 3, min_value=1, max_value=10)
API_RETRY_BACKOFF_SECONDS: float = _parse_float_env(
    "API_RETRY_BACKOFF_SECONDS", 0.6, min_value=0.0, max_value=30.0
)
API_RATE_LIMIT_SLEEP_SECONDS: float = _parse_float_env(
    "API_RATE_LIMIT_SLEEP_SECONDS", 6.0, min_value=0.0, max_value=120.0
)
API_COMPETITION_SLEEP_SECONDS: float = _parse_float_env(
    "API_COMPETITION_SLEEP_SECONDS", 0.7, min_value=0.0, max_value=30.0
)
API_MAX_CONCURRENT_REQUESTS: int = _parse_int_env(
    "API_MAX_CONCURRENT_REQUESTS", 1, min_value=1, max_value=10
)
API_CHUNK_DAYS: int = _parse_int_env(
    "API_CHUNK_DAYS", 180, min_value=30, max_value=365
)
API_CIRCUIT_BREAKER_FAILURES: int = _parse_int_env(
    "API_CIRCUIT_BREAKER_FAILURES", 5, min_value=1, max_value=20
)
API_CIRCUIT_BREAKER_COOLDOWN: float = _parse_float_env(
    "API_CIRCUIT_BREAKER_COOLDOWN", 60.0, min_value=5.0, max_value=3600.0
)

CACHE_DIR: Path = Path(
    os.getenv("GOANGEL_CACHE_DIR", str(BASE_DIR / "cache"))
).expanduser().resolve()
CACHE_DIR.mkdir(parents=True, exist_ok=True)

HISTORICAL_FILE: Path = CACHE_DIR / "historical.pkl"
MODELS_FILE: Path = CACHE_DIR / "models.pkl"
SCALER_FILE: Path = CACHE_DIR / "scaler.pkl"
WEIGHTS_FILE: Path = CACHE_DIR / "weights.pkl"
NAME_TO_ID_FILE: Path = CACHE_DIR / "name_to_id.pkl"
CALIBRATION_STATE_FILE: Path = CACHE_DIR / "calibration.pkl"
TEMPERATURE_STATE_FILE: Path = CACHE_DIR / "temperature.pkl"
BACKTEST_STATE_FILE: Path = CACHE_DIR / "backtest.pkl"

CACHE_TTL_HOURS: int = _parse_int_env(
    "CACHE_TTL_HOURS", 0, min_value=0, max_value=8760
)
CACHE_NEVER_EXPIRES: bool = CACHE_TTL_HOURS == 0
CACHE_ATOMIC_WRITE: bool = _parse_bool_env("CACHE_ATOMIC_WRITE", True)

HISTORICAL_SEASONS_LOOKBACK: int = _parse_int_env(
    "HISTORICAL_SEASONS_LOOKBACK", 5, min_value=1, max_value=15
)
HISTORICAL_MIN_MATCHES_PER_TEAM: int = _parse_int_env(
    "HISTORICAL_MIN_MATCHES_PER_TEAM", 3, min_value=0, max_value=50
)
MIN_MATCHES_FOR_TRAINING: int = _parse_int_env(
    "MIN_MATCHES_FOR_TRAINING", 500, min_value=50, max_value=500000
)
MIN_MATCHES_PER_CLASS: int = _parse_int_env(
    "MIN_MATCHES_PER_CLASS", 50, min_value=5, max_value=100000
)

FORM_WINDOW_SHORT: int = _parse_int_env(
    "FORM_WINDOW_SHORT", 5, min_value=1, max_value=50
)
FORM_WINDOW_MEDIUM: int = _parse_int_env(
    "FORM_WINDOW_MEDIUM", 10, min_value=1, max_value=50
)
FORM_WINDOW_LONG: int = _parse_int_env(
    "FORM_WINDOW_LONG", 20, min_value=1, max_value=100
)

ELO_INITIAL_RATING: float = _parse_float_env(
    "ELO_INITIAL_RATING", 1500.0, min_value=0.0
)
ELO_K_FACTOR: float = _parse_float_env(
    "ELO_K_FACTOR", 20.0, min_value=1.0, max_value=100.0
)
ELO_HOME_ADVANTAGE: float = _parse_float_env(
    "ELO_HOME_ADVANTAGE", 65.0, min_value=0.0, max_value=200.0
)
ELO_SEASON_REGRESSION: float = _parse_float_env(
    "ELO_SEASON_REGRESSION", 0.15, min_value=0.0, max_value=1.0
)

TRAIN_RATIO: float = _parse_float_env(
    "TRAIN_RATIO", 0.70, min_value=0.50, max_value=0.90
)
CALIB_RATIO: float = _parse_float_env(
    "CALIB_RATIO", 0.15, min_value=0.05, max_value=0.30
)
TEST_RATIO: float = _parse_float_env(
    "TEST_RATIO", 0.15, min_value=0.05, max_value=0.30
)

MODEL_TRAIN_TEST_SPLIT: float = _parse_float_env(
    "MODEL_TRAIN_TEST_SPLIT", 0.20, min_value=0.05, max_value=0.40
)
MODEL_WALK_FORWARD_FOLDS: int = _parse_int_env(
    "MODEL_WALK_FORWARD_FOLDS", 5, min_value=2, max_value=20
)
MODEL_RANDOM_SEED: int = _parse_int_env(
    "MODEL_RANDOM_SEED", 42, min_value=0, max_value=2**31 - 1
)
MODEL_RETRAIN_INTERVAL_HOURS: int = _parse_int_env(
    "MODEL_RETRAIN_INTERVAL_HOURS", 24, min_value=1, max_value=720
)
MODEL_N_JOBS: int = _parse_int_env("MODEL_N_JOBS", -1, min_value=-1, max_value=128)

CALIBRATION_METHOD: str = _parse_choice_env(
    "CALIBRATION_METHOD", "isotonic", ("isotonic", "sigmoid")
)
CALIBRATION_MIN_VAL_SAMPLES: int = _parse_int_env(
    "CALIBRATION_MIN_VAL_SAMPLES", 300, min_value=50, max_value=100000
)
CALIBRATION_CV_FOLDS: int = _parse_int_env(
    "CALIBRATION_CV_FOLDS", 5, min_value=2, max_value=10
)

TEMPERATURE_SCALING_ENABLED: bool = _parse_bool_env(
    "TEMPERATURE_SCALING_ENABLED", True
)
TEMPERATURE_SCALING_DEFAULT: float = _parse_float_env(
    "TEMPERATURE_SCALING_DEFAULT", 1.15, min_value=0.5, max_value=3.0
)
TEMPERATURE_SCALING_MIN: float = _parse_float_env(
    "TEMPERATURE_SCALING_MIN", 0.70, min_value=0.3, max_value=2.0
)
TEMPERATURE_SCALING_MAX: float = _parse_float_env(
    "TEMPERATURE_SCALING_MAX", 2.50, min_value=1.0, max_value=5.0
)

ODDS_BLEND_WEIGHT: float = _parse_float_env(
    "ODDS_BLEND_WEIGHT", 0.65, min_value=0.0, max_value=1.0
)
MODEL_BLEND_WEIGHT: float = _parse_float_env(
    "MODEL_BLEND_WEIGHT", 0.35, min_value=0.0, max_value=1.0
)
ODDS_ENABLED_IN_TRAINING: bool = _parse_bool_env(
    "ODDS_ENABLED_IN_TRAINING", False
)

MAX_CONFIDENT_PROBABILITY: float = _parse_float_env(
    "MAX_CONFIDENT_PROBABILITY", 0.78, min_value=0.50, max_value=0.99
)
MIN_CONFIDENT_PROBABILITY: float = _parse_float_env(
    "MIN_CONFIDENT_PROBABILITY", 0.03, min_value=0.0, max_value=0.30
)
DRAW_FLOOR_PROBABILITY: float = _parse_float_env(
    "DRAW_FLOOR_PROBABILITY", 0.20, min_value=0.10, max_value=0.40
)

PROBABILITY_CLIP_EPS: float = _parse_float_env(
    "PROBABILITY_CLIP_EPS", 0.005, min_value=1e-6, max_value=0.05
)

XGB_N_ESTIMATORS: int = _parse_int_env(
    "XGB_N_ESTIMATORS", 400, min_value=10, max_value=10000
)
XGB_MAX_DEPTH: int = _parse_int_env(
    "XGB_MAX_DEPTH", 5, min_value=1, max_value=32
)
XGB_LEARNING_RATE: float = _parse_float_env(
    "XGB_LEARNING_RATE", 0.04, min_value=1e-5, max_value=1.0
)
XGB_SUBSAMPLE: float = _parse_float_env(
    "XGB_SUBSAMPLE", 0.80, min_value=0.3, max_value=1.0
)
XGB_COLSAMPLE: float = _parse_float_env(
    "XGB_COLSAMPLE", 0.80, min_value=0.3, max_value=1.0
)
XGB_MIN_CHILD_WEIGHT: float = _parse_float_env(
    "XGB_MIN_CHILD_WEIGHT", 5.0, min_value=0.0, max_value=100.0
)
XGB_REG_LAMBDA: float = _parse_float_env(
    "XGB_REG_LAMBDA", 1.5, min_value=0.0, max_value=100.0
)
XGB_REG_ALPHA: float = _parse_float_env(
    "XGB_REG_ALPHA", 0.5, min_value=0.0, max_value=100.0
)

LGBM_N_ESTIMATORS: int = _parse_int_env(
    "LGBM_N_ESTIMATORS", 400, min_value=10, max_value=10000
)
LGBM_MAX_DEPTH: int = _parse_int_env("LGBM_MAX_DEPTH", -1, min_value=-1, max_value=32)
LGBM_LEARNING_RATE: float = _parse_float_env(
    "LGBM_LEARNING_RATE", 0.04, min_value=1e-5, max_value=1.0
)
LGBM_NUM_LEAVES: int = _parse_int_env(
    "LGBM_NUM_LEAVES", 31, min_value=4, max_value=256
)
LGBM_MIN_CHILD_SAMPLES: int = _parse_int_env(
    "LGBM_MIN_CHILD_SAMPLES", 25, min_value=1, max_value=500
)
LGBM_SUBSAMPLE: float = _parse_float_env(
    "LGBM_SUBSAMPLE", 0.80, min_value=0.3, max_value=1.0
)
LGBM_COLSAMPLE: float = _parse_float_env(
    "LGBM_COLSAMPLE", 0.80, min_value=0.3, max_value=1.0
)
LGBM_REG_LAMBDA: float = _parse_float_env(
    "LGBM_REG_LAMBDA", 1.5, min_value=0.0, max_value=100.0
)

CATBOOST_ITERATIONS: int = _parse_int_env(
    "CATBOOST_ITERATIONS", 400, min_value=10, max_value=10000
)
CATBOOST_DEPTH: int = _parse_int_env(
    "CATBOOST_DEPTH", 6, min_value=1, max_value=16
)
CATBOOST_LEARNING_RATE: float = _parse_float_env(
    "CATBOOST_LEARNING_RATE", 0.04, min_value=1e-5, max_value=1.0
)
CATBOOST_L2_LEAF_REG: float = _parse_float_env(
    "CATBOOST_L2_LEAF_REG", 3.0, min_value=0.0, max_value=100.0
)
CATBOOST_RANDOM_STRENGTH: float = _parse_float_env(
    "CATBOOST_RANDOM_STRENGTH", 1.0, min_value=0.0, max_value=10.0
)

RF_N_ESTIMATORS: int = _parse_int_env(
    "RF_N_ESTIMATORS", 400, min_value=10, max_value=5000
)
RF_MAX_DEPTH: int = _parse_int_env(
    "RF_MAX_DEPTH", 10, min_value=1, max_value=100
)
RF_MIN_SAMPLES_LEAF: int = _parse_int_env(
    "RF_MIN_SAMPLES_LEAF", 5, min_value=1, max_value=100
)
RF_MIN_SAMPLES_SPLIT: int = _parse_int_env(
    "RF_MIN_SAMPLES_SPLIT", 10, min_value=2, max_value=200
)
RF_MAX_FEATURES: str = _parse_choice_env(
    "RF_MAX_FEATURES", "sqrt", ("sqrt", "log2", "None")
)

DL_ENABLED: bool = _parse_bool_env("DL_ENABLED", False)
DL_HIDDEN_SIZE: int = _parse_int_env(
    "DL_HIDDEN_SIZE", 64, min_value=8, max_value=1024
)
DL_EPOCHS: int = _parse_int_env("DL_EPOCHS", 60, min_value=1, max_value=2000)
DL_BATCH_SIZE: int = _parse_int_env(
    "DL_BATCH_SIZE", 32, min_value=1, max_value=4096
)
DL_LEARNING_RATE: float = _parse_float_env(
    "DL_LEARNING_RATE", 1e-3, min_value=1e-6, max_value=1.0
)
DL_WEIGHT_DECAY: float = _parse_float_env(
    "DL_WEIGHT_DECAY", 1e-4, min_value=0.0, max_value=0.1
)
DL_DROPOUT: float = _parse_float_env(
    "DL_DROPOUT", 0.30, min_value=0.0, max_value=0.9
)
DL_EARLY_STOPPING_PATIENCE: int = _parse_int_env(
    "DL_EARLY_STOPPING_PATIENCE", 12, min_value=1, max_value=100
)
DL_GRAD_CLIP: float = _parse_float_env(
    "DL_GRAD_CLIP", 1.0, min_value=0.1, max_value=10.0
)

MIN_REALISTIC_LAMBDA: float = _parse_float_env(
    "MIN_REALISTIC_LAMBDA", 0.35, min_value=0.05, max_value=2.0
)
MAX_REALISTIC_LAMBDA: float = _parse_float_env(
    "MAX_REALISTIC_LAMBDA", 4.5, min_value=1.0, max_value=10.0
)
DEFAULT_HOME_LAMBDA: float = _parse_float_env(
    "DEFAULT_HOME_LAMBDA", 1.45, min_value=0.3, max_value=4.0
)
DEFAULT_AWAY_LAMBDA: float = _parse_float_env(
    "DEFAULT_AWAY_LAMBDA", 1.20, min_value=0.3, max_value=4.0
)
MAX_GOALS_GRID: int = _parse_int_env(
    "MAX_GOALS_GRID", 12, min_value=6, max_value=20
)
DIXON_COLES_RHO: float = _parse_float_env(
    "DIXON_COLES_RHO", -0.05, min_value=-0.5, max_value=0.5
)

H2H_MAX_MATCHES: int = _parse_int_env(
    "H2H_MAX_MATCHES", 8, min_value=2, max_value=30
)
H2H_MAX_AGE_DAYS: int = _parse_int_env(
    "H2H_MAX_AGE_DAYS", 1825, min_value=180, max_value=5475
)
H2H_MIN_MATCHES_FOR_FEATURE: int = _parse_int_env(
    "H2H_MIN_MATCHES_FOR_FEATURE", 2, min_value=1, max_value=10
)

REST_DAYS_DEFAULT: float = _parse_float_env(
    "REST_DAYS_DEFAULT", 7.0, min_value=1.0, max_value=30.0
)
REST_DAYS_CAP: float = _parse_float_env(
    "REST_DAYS_CAP", 21.0, min_value=5.0, max_value=60.0
)

ODDS_API_KEY: str = os.getenv("ODDS_API_KEY", "").strip()
ODDS_API_BASE_URL: str = os.getenv(
    "ODDS_API_BASE_URL", "https://api.the-odds-api.com/v4"
).rstrip("/")
ODDS_API_ENABLED: bool = _parse_bool_env(
    "ODDS_API_ENABLED", bool(ODDS_API_KEY)
)
ODDS_CACHE_TTL_MINUTES: int = _parse_int_env(
    "ODDS_CACHE_TTL_MINUTES", 30, min_value=1, max_value=1440
)
ODDS_MATCH_NAME_MIN_SCORE: float = _parse_float_env(
    "ODDS_MATCH_NAME_MIN_SCORE", 0.72, min_value=0.0, max_value=1.0
)
ODDS_REGIONS: str = os.getenv("ODDS_REGIONS", "eu").strip()
ODDS_MARKETS: str = os.getenv("ODDS_MARKETS", "h2h").strip()
ODDS_ODDS_FORMAT: str = _parse_choice_env(
    "ODDS_ODDS_FORMAT", "decimal", ("decimal", "american")
)
ODDS_REMOVE_VIG: bool = _parse_bool_env("ODDS_REMOVE_VIG", True)
ODDS_REQUESTS_PER_MINUTE: int = _parse_int_env(
    "ODDS_REQUESTS_PER_MINUTE", 20, min_value=1, max_value=600
)

ODDS_API_SPORT_KEYS: Dict[str, str] = {
    "PL":  "soccer_epl",
    "PD":  "soccer_spain_la_liga",
    "BL1": "soccer_germany_bundesliga",
    "SA":  "soccer_italy_serie_a",
    "FL1": "soccer_france_ligue_one",
    "CL":  "soccer_uefa_champs_league",
    "EL":  "soccer_uefa_europa_league",
    "DED": "soccer_netherlands_eredivisie",
    "PPL": "soccer_portugal_primeira_liga",
    "ELC": "soccer_efl_champ",
    "BSA": "soccer_brazil_campeonato",
    "CLI": "soccer_conmebol_copa_libertadores",
}

INJURIES_API_KEY: str = os.getenv("INJURIES_API_KEY", "").strip()
INJURIES_API_ENABLED: bool = _parse_bool_env(
    "INJURIES_API_ENABLED", bool(INJURIES_API_KEY)
)
INJURIES_CACHE_TTL_HOURS: int = _parse_int_env(
    "INJURIES_CACHE_TTL_HOURS", 6, min_value=1, max_value=168
)

BACKTEST_LAST_N_MATCHES: int = _parse_int_env(
    "BACKTEST_LAST_N_MATCHES", 500, min_value=50, max_value=50000
)
BACKTEST_MIN_LOG_LOSS: float = _parse_float_env(
    "BACKTEST_MIN_LOG_LOSS", 1.05, min_value=0.5, max_value=2.0
)
BACKTEST_MIN_ACCURACY: float = _parse_float_env(
    "BACKTEST_MIN_ACCURACY", 0.45, min_value=0.20, max_value=0.80
)
BACKTEST_MIN_BRIER: float = _parse_float_env(
    "BACKTEST_MIN_BRIER", 0.20, min_value=0.10, max_value=0.35
)
BACKTEST_WALK_FORWARD_STEPS: int = _parse_int_env(
    "BACKTEST_WALK_FORWARD_STEPS", 5, min_value=2, max_value=20
)
BACKTEST_SAVE_REPORT: bool = _parse_bool_env("BACKTEST_SAVE_REPORT", True)

ENSEMBLE_MIN_WEIGHT: float = _parse_float_env(
    "ENSEMBLE_MIN_WEIGHT", 0.02, min_value=0.0, max_value=0.5
)
ENSEMBLE_MAX_WEIGHT: float = _parse_float_env(
    "ENSEMBLE_MAX_WEIGHT", 0.60, min_value=0.1, max_value=1.0
)
ENSEMBLE_DISAGREEMENT_THRESHOLD: float = _parse_float_env(
    "ENSEMBLE_DISAGREEMENT_THRESHOLD", 0.10, min_value=0.01, max_value=0.5
)

FEATURE_MIN_COVERAGE: float = _parse_float_env(
    "FEATURE_MIN_COVERAGE", 0.60, min_value=0.1, max_value=1.0
)
FEATURE_OUTLIER_ZSCORE: float = _parse_float_env(
    "FEATURE_OUTLIER_ZSCORE", 5.0, min_value=2.0, max_value=20.0
)
FEATURE_CLIP_ENABLED: bool = _parse_bool_env("FEATURE_CLIP_ENABLED", True)

LOG_LEVEL: int = _parse_log_level("LOG_LEVEL", "INFO")
LOG_FORMAT: str = os.getenv(
    "LOG_FORMAT", "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
LOG_FILE: str = os.getenv("LOG_FILE", str(CACHE_DIR / "goangel.log")).strip()
LOG_MAX_BYTES: int = _parse_int_env(
    "LOG_MAX_BYTES", 10 * 1024 * 1024, min_value=1024, max_value=1024 * 1024 * 1024
)
LOG_BACKUP_COUNT: int = _parse_int_env(
    "LOG_BACKUP_COUNT", 5, min_value=1, max_value=100
)
CONSOLE_VERBOSE: bool = _parse_bool_env("CONSOLE_VERBOSE", False)

TIMEZONE: str = os.getenv("GOANGEL_TIMEZONE", "UTC").strip()

_TZ_CACHE: Dict[str, Any] = {}


def get_timezone() -> Any:
    if TIMEZONE in _TZ_CACHE:
        return _TZ_CACHE[TIMEZONE]
    tz: Any = timezone.utc
    if ZoneInfo is not None:
        try:
            tz = ZoneInfo(TIMEZONE)
        except Exception as exc:
            logger.warning(
                "Timezone %r invalide, repli sur UTC : %s", TIMEZONE, exc
            )
            tz = timezone.utc
    _TZ_CACHE[TIMEZONE] = tz
    return tz


def now_local() -> datetime:
    return datetime.now(get_timezone())


DEFAULT_SEASON_START_MONTH: int = _parse_int_env(
    "DEFAULT_SEASON_START_MONTH", 7, min_value=1, max_value=12
)
DEFAULT_SEASON_START_DAY: int = _parse_int_env(
    "DEFAULT_SEASON_START_DAY", 1, min_value=1, max_value=28
)
DEFAULT_SEASON_END_MONTH: int = _parse_int_env(
    "DEFAULT_SEASON_END_MONTH", 6, min_value=1, max_value=12
)
DEFAULT_SEASON_END_DAY: int = _parse_int_env(
    "DEFAULT_SEASON_END_DAY", 30, min_value=1, max_value=30
)


def _build_log_handlers() -> List[logging.Handler]:
    handlers: List[logging.Handler] = []
    if LOG_FILE:
        try:
            from logging.handlers import RotatingFileHandler
            log_path = Path(LOG_FILE)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = RotatingFileHandler(
                log_path,
                maxBytes=LOG_MAX_BYTES,
                backupCount=LOG_BACKUP_COUNT,
                encoding="utf-8",
            )
            file_handler.setLevel(LOG_LEVEL)
            file_handler.setFormatter(logging.Formatter(LOG_FORMAT))
            handlers.append(file_handler)
        except Exception as exc:
            print(f"Impossible d'initialiser le fichier de log : {exc}", file=sys.stderr)
    if CONSOLE_VERBOSE:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(LOG_LEVEL)
        console_handler.setFormatter(logging.Formatter(LOG_FORMAT))
        handlers.append(console_handler)
    if not handlers:
        handlers.append(logging.NullHandler())
    return handlers


def configure_logging() -> None:
    handlers = _build_log_handlers()
    logging.basicConfig(
        level=LOG_LEVEL,
        format=LOG_FORMAT,
        handlers=handlers,
        force=True,
    )
    logging.captureWarnings(True)
    warnings_logger = logging.getLogger("py.warnings")
    warnings_logger.setLevel(LOG_LEVEL)
    warnings_logger.propagate = False
    for h in handlers:
        warnings_logger.addHandler(h)


configure_logging()


def stage_print(message: str) -> None:
    try:
        print(message, flush=True)
    except Exception:
        pass


def validate_runtime_environment() -> None:
    errors: List[str] = []

    if not tokens:
        errors.append("Aucun token football-data.org configuré")
    if not COMPETITIONS:
        errors.append("Aucune compétition configurée")
    if not (0.0 < MODEL_TRAIN_TEST_SPLIT < 1.0):
        errors.append("MODEL_TRAIN_TEST_SPLIT doit être strictement dans (0, 1)")
    ratio_sum = TRAIN_RATIO + CALIB_RATIO + TEST_RATIO
    if abs(ratio_sum - 1.0) > 1e-6:
        errors.append(
            f"TRAIN_RATIO + CALIB_RATIO + TEST_RATIO doit valoir 1.0 "
            f"(actuellement {ratio_sum:.4f})"
        )
    if TRAIN_RATIO <= 0 or CALIB_RATIO <= 0 or TEST_RATIO <= 0:
        errors.append("TRAIN_RATIO, CALIB_RATIO et TEST_RATIO doivent être > 0")
    if FORM_WINDOW_SHORT > FORM_WINDOW_MEDIUM:
        errors.append("FORM_WINDOW_SHORT doit être <= FORM_WINDOW_MEDIUM")
    if FORM_WINDOW_MEDIUM > FORM_WINDOW_LONG:
        errors.append("FORM_WINDOW_MEDIUM doit être <= FORM_WINDOW_LONG")
    if ODDS_BLEND_WEIGHT + MODEL_BLEND_WEIGHT <= 0:
        errors.append("ODDS_BLEND_WEIGHT + MODEL_BLEND_WEIGHT doit être > 0")
    if MAX_CONFIDENT_PROBABILITY <= MIN_CONFIDENT_PROBABILITY:
        errors.append(
            "MAX_CONFIDENT_PROBABILITY doit être > MIN_CONFIDENT_PROBABILITY"
        )
    if not (0.0 <= DRAW_FLOOR_PROBABILITY <= 0.5):
        errors.append("DRAW_FLOOR_PROBABILITY doit être dans [0, 0.5]")
    if TEMPERATURE_SCALING_MIN >= TEMPERATURE_SCALING_MAX:
        errors.append("TEMPERATURE_SCALING_MIN doit être < TEMPERATURE_SCALING_MAX")
    if not (TEMPERATURE_SCALING_MIN <= TEMPERATURE_SCALING_DEFAULT <= TEMPERATURE_SCALING_MAX):
        errors.append("TEMPERATURE_SCALING_DEFAULT doit être dans [MIN, MAX]")
    if MIN_REALISTIC_LAMBDA <= 0:
        errors.append("MIN_REALISTIC_LAMBDA doit être > 0")
    if MAX_REALISTIC_LAMBDA <= MIN_REALISTIC_LAMBDA:
        errors.append("MAX_REALISTIC_LAMBDA doit être > MIN_REALISTIC_LAMBDA")
    if MAX_GOALS_GRID < 6:
        errors.append("MAX_GOALS_GRID doit être >= 6")
    if not (0.0 < ODDS_BLEND_WEIGHT <= 1.0):
        errors.append("ODDS_BLEND_WEIGHT doit être dans (0, 1]")
    if not (0.0 < MODEL_BLEND_WEIGHT <= 1.0):
        errors.append("MODEL_BLEND_WEIGHT doit être dans (0, 1]")
    if not CACHE_DIR.exists():
        errors.append(f"Le répertoire de cache {CACHE_DIR} n'existe pas")
    if not os.access(CACHE_DIR, os.W_OK):
        errors.append(f"Le répertoire de cache {CACHE_DIR} n'est pas accessible en écriture")
    if BACKTEST_MIN_LOG_LOSS <= 0:
        errors.append("BACKTEST_MIN_LOG_LOSS doit être > 0")
    if not (0.0 < BACKTEST_MIN_ACCURACY < 1.0):
        errors.append("BACKTEST_MIN_ACCURACY doit être dans (0, 1)")
    if not (0.0 < BACKTEST_MIN_BRIER < 1.0):
        errors.append("BACKTEST_MIN_BRIER doit être dans (0, 1)")

    if errors:
        for err in errors:
            logger.critical("Configuration invalide : %s", err)
        raise ConfigValidationError(
            "Configuration invalide : " + " | ".join(errors)
        )


validate_runtime_environment()

logger.info(
    "Configuration chargée : %d token(s), %d compétitions, cache=%s, "
    "ratios train/calib/test=%.2f/%.2f/%.2f, calibration=%s, "
    "temperature=%.2f, odds_blend=%.2f, tz=%s",
    len(tokens),
    len(COMPETITIONS),
    CACHE_DIR,
    TRAIN_RATIO,
    CALIB_RATIO,
    TEST_RATIO,
    CALIBRATION_METHOD,
    TEMPERATURE_SCALING_DEFAULT,
    ODDS_BLEND_WEIGHT,
    TIMEZONE,
)

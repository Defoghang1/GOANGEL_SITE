import math
import logging
import unicodedata
import warnings
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import log_loss

warnings.filterwarnings("ignore")

try:
    from sklearn.frozen import FrozenEstimator
except ImportError:
    FrozenEstimator = None

from penaltyblog.models import (
    PoissonGoalsModel,
    DixonColesGoalModel,
    BivariatePoissonGoalModel,
    ZeroInflatedPoissonGoalsModel,
    NegativeBinomialGoalModel,
    WeibullCopulaGoalsModel,
)

try:
    from xgboost import XGBClassifier
except ImportError:
    XGBClassifier = None
try:
    from lightgbm import LGBMClassifier
except ImportError:
    LGBMClassifier = None
try:
    from catboost import CatBoostClassifier
except ImportError:
    CatBoostClassifier = None
try:
    from sklearn.ensemble import RandomForestClassifier
except ImportError:
    RandomForestClassifier = None
try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
except ImportError:
    torch = None
    nn = None

from config import (
    FORM_WINDOW_MEDIUM,
    FORM_WINDOW_LONG,
    ELO_INITIAL_RATING,
    ELO_K_FACTOR,
    ELO_HOME_ADVANTAGE,
    MODEL_TRAIN_TEST_SPLIT,
    MODEL_WALK_FORWARD_FOLDS,
    MODEL_RANDOM_SEED,
    MODEL_N_JOBS,
    CALIBRATION_METHOD,
    CALIBRATION_MIN_VAL_SAMPLES,
    TEMPERATURE_SCALING_ENABLED,
    TEMPERATURE_SCALING_DEFAULT,
    TEMPERATURE_SCALING_MIN,
    TEMPERATURE_SCALING_MAX,
    XGB_N_ESTIMATORS,
    XGB_MAX_DEPTH,
    XGB_LEARNING_RATE,
    XGB_SUBSAMPLE,
    XGB_COLSAMPLE,
    XGB_MIN_CHILD_WEIGHT,
    XGB_REG_LAMBDA,
    XGB_REG_ALPHA,
    LGBM_N_ESTIMATORS,
    LGBM_MAX_DEPTH,
    LGBM_LEARNING_RATE,
    LGBM_NUM_LEAVES,
    LGBM_MIN_CHILD_SAMPLES,
    LGBM_SUBSAMPLE,
    LGBM_COLSAMPLE,
    LGBM_REG_LAMBDA,
    CATBOOST_ITERATIONS,
    CATBOOST_DEPTH,
    CATBOOST_LEARNING_RATE,
    CATBOOST_L2_LEAF_REG,
    CATBOOST_RANDOM_STRENGTH,
    RF_N_ESTIMATORS,
    RF_MAX_DEPTH,
    RF_MIN_SAMPLES_LEAF,
    RF_MIN_SAMPLES_SPLIT,
    RF_MAX_FEATURES,
    DL_ENABLED,
    DL_HIDDEN_SIZE,
    DL_EPOCHS,
    DL_BATCH_SIZE,
    DL_LEARNING_RATE,
    DL_WEIGHT_DECAY,
    DL_DROPOUT,
    DL_EARLY_STOPPING_PATIENCE,
    DL_GRAD_CLIP,
    MIN_MATCHES_FOR_TRAINING,
    MIN_MATCHES_PER_CLASS,
    COMPETITIONS_TIER_INDEX,
    H2H_MAX_MATCHES,
    H2H_MAX_AGE_DAYS,
    H2H_MIN_MATCHES_FOR_FEATURE,
    REST_DAYS_DEFAULT,
    REST_DAYS_CAP,
    FEATURE_CLIP_ENABLED,
    FEATURE_OUTLIER_ZSCORE,
    ENSEMBLE_MIN_WEIGHT,
    ENSEMBLE_MAX_WEIGHT,
    stage_print,
)

logger = logging.getLogger("goangel.features")

FEATURE_NAMES: List[str] = [
    "home_gf_medium", "home_ga_medium", "away_gf_medium", "away_ga_medium",
    "home_gf_long", "home_ga_long", "away_gf_long", "away_ga_long",
    "home_home_gf", "home_home_ga", "away_away_gf", "away_away_ga",
    "home_gd_medium", "away_gd_medium",
    "home_pts_medium", "away_pts_medium",
    "home_elo", "away_elo", "elo_diff",
    "h2h_home_winrate", "h2h_draw_rate", "h2h_away_winrate", "h2h_avg_goals",
    "home_rest_days", "away_rest_days", "rest_days_diff",
    "home_matches_played", "away_matches_played",
    "competition_tier_index",
]

EXPECTED_FEATURE_COUNT: int = len(FEATURE_NAMES)
NEUTRAL_ODDS_PROBS: Tuple[float, float, float] = (1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)

_FEATURE_INDEX: Dict[str, int] = {name: idx for idx, name in enumerate(FEATURE_NAMES)}

_NON_NEGATIVE_FEATURES: Tuple[str, ...] = (
    "home_gf_medium", "home_ga_medium", "away_gf_medium", "away_ga_medium",
    "home_gf_long", "home_ga_long", "away_gf_long", "away_ga_long",
    "home_home_gf", "home_home_ga", "away_away_gf", "away_away_ga",
    "home_pts_medium", "away_pts_medium",
    "h2h_home_winrate", "h2h_draw_rate", "h2h_away_winrate", "h2h_avg_goals",
    "home_rest_days", "away_rest_days",
    "home_matches_played", "away_matches_played",
)

_PB_MODEL_CLASSES: Dict[str, Any] = {
    "PoissonGoalsModel": PoissonGoalsModel,
    "DixonColesGoalModel": DixonColesGoalModel,
    "BivariatePoissonGoalModel": BivariatePoissonGoalModel,
    "ZeroInflatedPoissonGoalsModel": ZeroInflatedPoissonGoalsModel,
    "NegativeBinomialGoalModel": NegativeBinomialGoalModel,
    "WeibullCopulaGoalsModel": WeibullCopulaGoalsModel,
}

_PB_MODEL_ORDER: Tuple[str, ...] = tuple(_PB_MODEL_CLASSES.keys())

_TRAIN_RATIO: float = 0.70
_CALIB_RATIO: float = 0.15
_TEST_RATIO: float = 0.15


def normalize_name(name: Any) -> str:
    if not isinstance(name, str):
        return ""
    name = unicodedata.normalize("NFKD", name).encode("ASCII", "ignore").decode("ASCII")
    name = name.lower().strip()
    for suffix in (" fc", " cf", " ud", " cd", " sc", " ac", " afc", " cfc"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
    for token in (" de ", " la ", " el ", " los ", " ca ", " aa ", " rc ", " do ", " da "):
        name = name.replace(token, " ")
    name = " ".join(name.split())
    return name


def _team_key_raw(team_id: Any, raw_name: Any) -> str:
    if team_id is not None:
        try:
            if not (isinstance(team_id, float) and np.isnan(team_id)):
                return f"id:{int(team_id)}"
        except (TypeError, ValueError):
            pass
    return f"name:{normalize_name(raw_name)}"


def _build_name_to_id_resolver(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    votes: Dict[str, Dict[int, int]] = {}
    for r in rows:
        for name_field, id_field in (("home_raw", "home_id"), ("away_raw", "away_id")):
            name = normalize_name(r.get(name_field))
            tid = r.get(id_field)
            if not name or tid is None:
                continue
            try:
                tid_int = int(tid)
            except (TypeError, ValueError):
                continue
            votes.setdefault(name, {})
            votes[name][tid_int] = votes[name].get(tid_int, 0) + 1
    resolver: Dict[str, int] = {}
    for name, counts in votes.items():
        resolver[name] = max(counts.items(), key=lambda kv: kv[1])[0]
    return resolver


def process_matches(matches: List[Dict[str, Any]]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for m in matches:
        if not isinstance(m, dict):
            continue
        home_team = m.get("homeTeam")
        away_team = m.get("awayTeam")
        if not isinstance(home_team, dict) or not isinstance(away_team, dict):
            continue
        home_name = home_team.get("name")
        away_name = away_team.get("name")
        if not home_name or not away_name:
            continue
        score = m.get("score", {})
        full_time = score.get("fullTime", {}) if isinstance(score, dict) else {}
        goals_home = full_time.get("home") if isinstance(full_time, dict) else None
        goals_away = full_time.get("away") if isinstance(full_time, dict) else None
        comp = m.get("competition", {}) if isinstance(m.get("competition"), dict) else {}
        rows.append({
            "match_id": m.get("id"),
            "home_raw": home_name,
            "away_raw": away_name,
            "home_id": home_team.get("id"),
            "away_id": away_team.get("id"),
            "goals_home": goals_home,
            "goals_away": goals_away,
            "status": m.get("status", "SCHEDULED"),
            "date": m.get("utcDate", ""),
            "competition": comp.get("name", ""),
            "competition_code": comp.get("code", ""),
        })

    resolver = _build_name_to_id_resolver(rows)
    for r in rows:
        if r["home_id"] is None:
            r["home_id"] = resolver.get(normalize_name(r["home_raw"]))
        if r["away_id"] is None:
            r["away_id"] = resolver.get(normalize_name(r["away_raw"]))
        r["home"] = normalize_name(r["home_raw"])
        r["away"] = normalize_name(r["away_raw"])
        r["home_key"] = _team_key_raw(r["home_id"], r["home_raw"])
        r["away_key"] = _team_key_raw(r["away_id"], r["away_raw"])

    df = pd.DataFrame(rows)
    if not df.empty:
        df["date_parsed"] = pd.to_datetime(df["date"], errors="coerce", utc=True)
        df = df.sort_values("date_parsed", kind="mergesort").reset_index(drop=True)
    return df


class EloSystem:
    def __init__(
        self,
        initial_rating: float = ELO_INITIAL_RATING,
        k_factor: float = ELO_K_FACTOR,
        home_advantage: float = ELO_HOME_ADVANTAGE,
    ):
        self.initial_rating = float(initial_rating)
        self.k_factor = float(k_factor)
        self.home_advantage = float(home_advantage)
        self.ratings: Dict[str, float] = {}

    def get_rating(self, team: str) -> float:
        return self.ratings.get(team, self.initial_rating)

    def expected_score(self, rating_a: float, rating_b: float) -> float:
        return 1.0 / (1.0 + 10.0 ** ((rating_b - rating_a) / 400.0))

    def update(self, home: str, away: str, goals_home: int, goals_away: int) -> Tuple[float, float]:
        home_rating = self.get_rating(home)
        away_rating = self.get_rating(away)
        pre_home = home_rating
        pre_away = away_rating
        expected_home = self.expected_score(home_rating + self.home_advantage, away_rating)
        expected_away = 1.0 - expected_home
        if goals_home > goals_away:
            actual_home, actual_away = 1.0, 0.0
        elif goals_home == goals_away:
            actual_home, actual_away = 0.5, 0.5
        else:
            actual_home, actual_away = 0.0, 1.0
        goal_diff = abs(int(goals_home) - int(goals_away))
        multiplier = math.log(max(goal_diff, 1) + 1.0)
        new_home = home_rating + self.k_factor * multiplier * (actual_home - expected_home)
        new_away = away_rating + self.k_factor * multiplier * (actual_away - expected_away)
        self.ratings[home] = new_home
        self.ratings[away] = new_away
        return pre_home, pre_away


class TeamHistoryTracker:
    def __init__(self, default_gf: float = 1.35, default_ga: float = 1.35, default_pts: float = 0.42):
        self.gf: Dict[str, List[float]] = {}
        self.ga: Dict[str, List[float]] = {}
        self.home_gf: Dict[str, List[float]] = {}
        self.home_ga: Dict[str, List[float]] = {}
        self.away_gf: Dict[str, List[float]] = {}
        self.away_ga: Dict[str, List[float]] = {}
        self.results: Dict[str, List[str]] = {}
        self.last_match_date: Dict[str, Optional[pd.Timestamp]] = {}
        self.matches_played: Dict[str, int] = {}
        self.h2h: Dict[Tuple[str, str], List[Tuple[int, int, Optional[pd.Timestamp]]]] = {}
        self.default_gf = float(default_gf)
        self.default_ga = float(default_ga)
        self.default_pts = float(default_pts)

    def _ensure(self, team: str) -> None:
        if team not in self.gf:
            self.gf[team] = []
            self.ga[team] = []
            self.home_gf[team] = []
            self.home_ga[team] = []
            self.away_gf[team] = []
            self.away_ga[team] = []
            self.results[team] = []
            self.last_match_date[team] = None
            self.matches_played[team] = 0

    def snapshot(self, team: str) -> Dict[str, Any]:
        self._ensure(team)
        return {
            "gf": self.gf[team],
            "ga": self.ga[team],
            "home_gf": self.home_gf[team],
            "home_ga": self.home_ga[team],
            "away_gf": self.away_gf[team],
            "away_ga": self.away_ga[team],
            "results": self.results[team],
            "last_match_date": self.last_match_date[team],
            "matches_played": self.matches_played[team],
        }

    def head_to_head(
        self,
        home: str,
        away: str,
        limit: int = H2H_MAX_MATCHES,
        reference_date: Optional[pd.Timestamp] = None,
        max_age_days: int = H2H_MAX_AGE_DAYS,
    ) -> List[Tuple[int, int]]:
        key1 = (home, away)
        key2 = (away, home)
        raw: List[Tuple[int, int, Optional[pd.Timestamp]]] = []
        for gh, ga, dt in self.h2h.get(key1, []):
            raw.append((gh, ga, dt))
        for gh, ga, dt in self.h2h.get(key2, []):
            raw.append((ga, gh, dt))
        if reference_date is not None and not pd.isna(reference_date):
            cutoff = reference_date - pd.Timedelta(days=int(max_age_days))
            raw = [r for r in raw if r[2] is None or pd.isna(r[2]) or r[2] >= cutoff]
        raw.sort(key=lambda r: r[2] if r[2] is not None and not pd.isna(r[2]) else pd.Timestamp.min.tz_localize("UTC"))
        tail = raw[-limit:] if limit > 0 else raw
        return [(gh, ga) for gh, ga, _ in tail]

    def record(
        self,
        home: str,
        away: str,
        goals_home: int,
        goals_away: int,
        match_date: Optional[pd.Timestamp],
    ) -> None:
        self._ensure(home)
        self._ensure(away)
        self.gf[home].append(goals_home)
        self.ga[home].append(goals_away)
        self.gf[away].append(goals_away)
        self.ga[away].append(goals_home)
        self.home_gf[home].append(goals_home)
        self.home_ga[home].append(goals_away)
        self.away_gf[away].append(goals_away)
        self.away_ga[away].append(goals_home)
        if goals_home > goals_away:
            self.results[home].append("W")
            self.results[away].append("L")
        elif goals_home == goals_away:
            self.results[home].append("D")
            self.results[away].append("D")
        else:
            self.results[home].append("L")
            self.results[away].append("W")
        self.last_match_date[home] = match_date
        self.last_match_date[away] = match_date
        self.matches_played[home] += 1
        self.matches_played[away] += 1
        key = (home, away)
        if key not in self.h2h:
            self.h2h[key] = []
        self.h2h[key].append((int(goals_home), int(goals_away), match_date))


def _safe_mean(values: List[float], window: int, default: float) -> float:
    if window <= 0:
        tail = values
    else:
        tail = values[-window:]
    if not tail:
        return float(default)
    return float(np.mean(tail))


def _points_rate(results: List[str], window: int, default: float) -> float:
    if window <= 0:
        tail = results
    else:
        tail = results[-window:]
    if not tail:
        return float(default)
    points = sum(3 if r == "W" else 1 if r == "D" else 0 for r in tail)
    return points / (3.0 * len(tail))


def _rest_days(
    last_date: Optional[pd.Timestamp],
    current_date: Optional[pd.Timestamp],
    default_days: float = REST_DAYS_DEFAULT,
    cap_days: float = REST_DAYS_CAP,
) -> float:
    if last_date is None or current_date is None or pd.isna(last_date) or pd.isna(current_date):
        return float(default_days)
    delta = (current_date - last_date).total_seconds() / 86400.0
    if delta < 0 or delta > 365:
        return float(default_days)
    if delta > cap_days:
        return float(cap_days)
    return float(delta)


def compute_league_defaults(df_past: pd.DataFrame) -> Tuple[float, float, float]:
    if df_past.empty:
        return 1.35, 0.42, 1.45
    home_goals = df_past["goals_home"].dropna()
    away_goals = df_past["goals_away"].dropna()
    default_home_gf = float(home_goals.mean()) if not home_goals.empty else 1.45
    goals_all = pd.concat([df_past["goals_home"], df_past["goals_away"]], ignore_index=True).dropna()
    default_gf = float(goals_all.mean()) if not goals_all.empty else 1.35
    draw_mask = (df_past["goals_home"] == df_past["goals_away"])
    draw_rate = float(draw_mask.mean()) if len(df_past) > 0 else 0.25
    default_pts = (3.0 - draw_rate) / 6.0
    return default_gf, default_pts, default_home_gf


def build_feature_vector(
    home: str,
    away: str,
    tracker: TeamHistoryTracker,
    elo_system: EloSystem,
    match_date: Optional[pd.Timestamp],
    competition_code: Optional[str] = None,
    odds_probs: Optional[Tuple[float, float, float]] = None,
) -> np.ndarray:
    home_hist = tracker.snapshot(home)
    away_hist = tracker.snapshot(away)
    dgf = tracker.default_gf
    dga = tracker.default_ga
    dpts = tracker.default_pts

    home_gf_medium = _safe_mean(home_hist["gf"], FORM_WINDOW_MEDIUM, dgf)
    home_ga_medium = _safe_mean(home_hist["ga"], FORM_WINDOW_MEDIUM, dga)
    away_gf_medium = _safe_mean(away_hist["gf"], FORM_WINDOW_MEDIUM, dgf)
    away_ga_medium = _safe_mean(away_hist["ga"], FORM_WINDOW_MEDIUM, dga)

    home_gf_long = _safe_mean(home_hist["gf"], FORM_WINDOW_LONG, dgf)
    home_ga_long = _safe_mean(home_hist["ga"], FORM_WINDOW_LONG, dga)
    away_gf_long = _safe_mean(away_hist["gf"], FORM_WINDOW_LONG, dgf)
    away_ga_long = _safe_mean(away_hist["ga"], FORM_WINDOW_LONG, dga)

    home_home_gf = _safe_mean(home_hist["home_gf"], FORM_WINDOW_MEDIUM, dgf)
    home_home_ga = _safe_mean(home_hist["home_ga"], FORM_WINDOW_MEDIUM, dga)
    away_away_gf = _safe_mean(away_hist["away_gf"], FORM_WINDOW_MEDIUM, dgf)
    away_away_ga = _safe_mean(away_hist["away_ga"], FORM_WINDOW_MEDIUM, dga)

    home_gd_medium = home_gf_medium - home_ga_medium
    away_gd_medium = away_gf_medium - away_ga_medium

    home_pts_medium = _points_rate(home_hist["results"], FORM_WINDOW_MEDIUM, dpts)
    away_pts_medium = _points_rate(away_hist["results"], FORM_WINDOW_MEDIUM, dpts)

    home_elo = elo_system.get_rating(home)
    away_elo = elo_system.get_rating(away)
    elo_diff = home_elo - away_elo

    h2h_matches = tracker.head_to_head(
        home, away, limit=H2H_MAX_MATCHES, reference_date=match_date
    )
    if len(h2h_matches) >= H2H_MIN_MATCHES_FOR_FEATURE:
        total = len(h2h_matches)
        h2h_home_wins = sum(1 for gh, ga in h2h_matches if gh > ga)
        h2h_draws = sum(1 for gh, ga in h2h_matches if gh == ga)
        h2h_away_wins = sum(1 for gh, ga in h2h_matches if gh < ga)
        h2h_home_winrate = h2h_home_wins / total
        h2h_draw_rate = h2h_draws / total
        h2h_away_winrate = h2h_away_wins / total
        h2h_avg_goals = float(np.mean([gh + ga for gh, ga in h2h_matches]))
    else:
        h2h_home_winrate = 0.40
        h2h_draw_rate = 0.25
        h2h_away_winrate = 0.35
        h2h_avg_goals = 2.5

    home_rest = _rest_days(home_hist["last_match_date"], match_date)
    away_rest = _rest_days(away_hist["last_match_date"], match_date)
    rest_diff = home_rest - away_rest

    home_played = float(home_hist["matches_played"])
    away_played = float(away_hist["matches_played"])

    competition_tier_index = float(
        COMPETITIONS_TIER_INDEX.get(competition_code, len(COMPETITIONS_TIER_INDEX))
    )

    feat = np.array([
        home_gf_medium, home_ga_medium, away_gf_medium, away_ga_medium,
        home_gf_long, home_ga_long, away_gf_long, away_ga_long,
        home_home_gf, home_home_ga, away_away_gf, away_away_ga,
        home_gd_medium, away_gd_medium,
        home_pts_medium, away_pts_medium,
        home_elo, away_elo, elo_diff,
        h2h_home_winrate, h2h_draw_rate, h2h_away_winrate, h2h_avg_goals,
        home_rest, away_rest, rest_diff,
        home_played, away_played,
        competition_tier_index,
    ], dtype=np.float64)

    if FEATURE_CLIP_ENABLED:
        np.nan_to_num(feat, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
        for name in _NON_NEGATIVE_FEATURES:
            idx = _FEATURE_INDEX.get(name)
            if idx is not None:
                feat[idx] = max(feat[idx], 0.0)
        home_elo_idx = _FEATURE_INDEX["home_elo"]
        away_elo_idx = _FEATURE_INDEX["away_elo"]
        feat[home_elo_idx] = max(feat[home_elo_idx], 0.0)
        feat[away_elo_idx] = max(feat[away_elo_idx], 0.0)

    return feat


def build_tracking_state(df_past: pd.DataFrame) -> Tuple[TeamHistoryTracker, EloSystem]:
    dgf, dpts, _ = compute_league_defaults(df_past)
    tracker = TeamHistoryTracker(default_gf=dgf, default_ga=dgf, default_pts=dpts)
    elo_system = EloSystem()
    if df_past.empty:
        return tracker, elo_system
    df_sorted = df_past.sort_values("date_parsed", kind="mergesort") if "date_parsed" in df_past.columns else df_past
    for row in df_sorted.itertuples(index=False):
        home = getattr(row, "home_key", None)
        away = getattr(row, "away_key", None)
        gh = getattr(row, "goals_home", None)
        ga = getattr(row, "goals_away", None)
        if home is None or away is None:
            continue
        if gh is None or ga is None or pd.isna(gh) or pd.isna(ga):
            continue
        match_date = getattr(row, "date_parsed", None)
        tracker.record(home, away, int(gh), int(ga), match_date)
        elo_system.update(home, away, int(gh), int(ga))
    return tracker, elo_system


def create_features_with_context(
    df_past: pd.DataFrame,
) -> Tuple[
    np.ndarray, np.ndarray, List[str], List[str], List[int], List[int], List[Optional[str]]
]:
    if df_past.empty:
        return (
            np.zeros((0, EXPECTED_FEATURE_COUNT)), np.zeros((0,), dtype=np.int64),
            [], [], [], [], [],
        )
    dgf, dpts, _ = compute_league_defaults(df_past)
    df_sorted = df_past.sort_values("date_parsed", kind="mergesort").reset_index(drop=True)
    tracker = TeamHistoryTracker(default_gf=dgf, default_ga=dgf, default_pts=dpts)
    elo_system = EloSystem()
    feature_rows: List[np.ndarray] = []
    labels: List[int] = []
    home_keys: List[str] = []
    away_keys: List[str] = []
    goals_home_list: List[int] = []
    goals_away_list: List[int] = []
    comp_codes: List[Optional[str]] = []
    for row in df_sorted.itertuples(index=False):
        home = getattr(row, "home_key", None)
        away = getattr(row, "away_key", None)
        gh = getattr(row, "goals_home", None)
        ga = getattr(row, "goals_away", None)
        if home is None or away is None:
            continue
        if gh is None or ga is None or pd.isna(gh) or pd.isna(ga):
            continue
        match_date = getattr(row, "date_parsed", None)
        comp_code = getattr(row, "competition_code", None)
        feat = build_feature_vector(home, away, tracker, elo_system, match_date, comp_code, None)
        feature_rows.append(feat)
        gh_int = int(gh)
        ga_int = int(ga)
        if gh_int > ga_int:
            labels.append(0)
        elif gh_int == ga_int:
            labels.append(1)
        else:
            labels.append(2)
        home_keys.append(home)
        away_keys.append(away)
        goals_home_list.append(gh_int)
        goals_away_list.append(ga_int)
        comp_codes.append(comp_code)
        tracker.record(home, away, gh_int, ga_int, match_date)
        elo_system.update(home, away, gh_int, ga_int)
    if not feature_rows:
        return (
            np.zeros((0, EXPECTED_FEATURE_COUNT)), np.zeros((0,), dtype=np.int64),
            [], [], [], [], [],
        )
    return (
        np.array(feature_rows, dtype=np.float64),
        np.array(labels, dtype=np.int64),
        home_keys, away_keys, goals_home_list, goals_away_list, comp_codes,
    )


if nn is not None:
    class _TorchNet(nn.Module):
        def __init__(
            self,
            input_dim: int,
            hidden_size: int = DL_HIDDEN_SIZE,
            output_dim: int = 3,
            dropout: float = DL_DROPOUT,
        ):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_size),
                nn.BatchNorm1d(hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_size, hidden_size),
                nn.BatchNorm1d(hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_size, hidden_size // 2),
                nn.ReLU(),
                nn.Dropout(dropout / 2.0),
                nn.Linear(hidden_size // 2, output_dim),
            )

        def forward(self, x):
            return self.net(x)
else:
    _TorchNet = None


if torch is not None and nn is not None:
    class _TorchProbaWrapper:
        def __init__(self, model: Any):
            self.model = model
            self.classes_ = np.array([0, 1, 2])
            self._estimator_type = "classifier"

        def get_params(self, deep: bool = True) -> Dict[str, Any]:
            return {"model": self.model}

        def set_params(self, **params: Any) -> "_TorchProbaWrapper":
            if "model" in params:
                self.model = params["model"]
            return self

        def fit(self, X: Any, y: Any) -> "_TorchProbaWrapper":
            return self

        def predict_proba(self, X: Any) -> np.ndarray:
            self.model.eval()
            with torch.no_grad():
                logits = self.model(torch.FloatTensor(np.asarray(X, dtype=np.float32)))
                return torch.softmax(logits, dim=1).numpy()

        def predict(self, X: Any) -> np.ndarray:
            return np.argmax(self.predict_proba(X), axis=1)
else:
    _TorchProbaWrapper = None


def _fit_pb_model(
    class_name: str,
    gh: List[int],
    ga: List[int],
    th: List[str],
    ta: List[str],
) -> Tuple[str, Any]:
    cls = _PB_MODEL_CLASSES[class_name]
    try:
        m = cls(gh, ga, th, ta)
        m.fit()
        return "ok", m
    except Exception as exc:
        return "error", str(exc)


def _calibrate_or_keep(
    name: str,
    base_model: Any,
    X_calib: np.ndarray,
    y_calib: np.ndarray,
) -> Any:
    if name == "DL" and _TorchProbaWrapper is not None:
        wrapped: Any = _TorchProbaWrapper(base_model)
    else:
        wrapped = base_model

    if X_calib.shape[0] < CALIBRATION_MIN_VAL_SAMPLES:
        logger.warning(
            "%s : set de calibration trop petit (%d) pour calibrer, non calibré conservé",
            name, X_calib.shape[0],
        )
        stage_print(f"⚠️ {name.upper()} : pas assez de calibration, non calibré")
        return wrapped

    unique_classes = np.unique(y_calib)
    if len(unique_classes) < 3:
        logger.warning(
            "%s : calibration ne contient que %s classes, calibration ignorée",
            name, unique_classes.tolist(),
        )
        return wrapped

    if FrozenEstimator is not None:
        try:
            calibrated = CalibratedClassifierCV(
                FrozenEstimator(wrapped), method=CALIBRATION_METHOD
            )
            calibrated.fit(X_calib, y_calib)
            return calibrated
        except Exception as exc:
            logger.warning(
                "%s : calibration FrozenEstimator échouée : %s: %s",
                name, type(exc).__name__, exc,
            )

    try:
        calibrated = CalibratedClassifierCV(
            wrapped, method=CALIBRATION_METHOD, cv="prefit"
        )
        calibrated.fit(X_calib, y_calib)
        return calibrated
    except Exception as exc:
        logger.error(
            "%s : calibration (prefit) échouée : %s: %s",
            name, type(exc).__name__, exc,
        )
        stage_print(f"❌ {name.upper()} : calibration échouée, modèle brut conservé")
        return wrapped


def _extract_market_probabilities(grid: Any) -> Dict[str, float]:
    result: Dict[str, float] = {}
    try:
        hda = np.array(grid.home_draw_away, dtype=np.float64)
        if hda.shape == (3,) and np.all(np.isfinite(hda)) and hda.sum() > 0:
            result["home_draw_away"] = (hda / hda.sum()).tolist()
    except Exception:
        pass
    for line, key in ((1.5, "over15"), (2.5, "over25")):
        val = None
        try:
            val = float(grid.total_goals("over", line))
        except Exception:
            try:
                _, _, over_val = grid.totals(line)
                val = float(over_val)
            except Exception:
                try:
                    attr_name = f"over_{str(line).replace('.', '')}"
                    val = float(getattr(grid, attr_name))
                except Exception:
                    val = None
        if val is not None and np.isfinite(val):
            result[key] = float(np.clip(val, 0.0, 1.0))
    try:
        btts = float(grid.btts_yes)
        if np.isfinite(btts):
            result["btts_yes"] = float(np.clip(btts, 0.0, 1.0))
    except Exception:
        pass
    try:
        home_xg = float(np.ravel(grid.home_goal_expectation)[0])
        away_xg = float(np.ravel(grid.away_goal_expectation)[0])
        if np.isfinite(home_xg) and np.isfinite(away_xg):
            result["home_xg"] = home_xg
            result["away_xg"] = away_xg
    except Exception:
        pass
    return result


def _walk_forward_splits(
    n_samples: int,
    n_folds: int,
    initial_train_ratio: float = 0.40,
) -> List[Tuple[int, int]]:
    if n_samples < 200 or n_folds < 2:
        cut = max(1, int(n_samples * (1.0 - MODEL_TRAIN_TEST_SPLIT)))
        cut = min(cut, n_samples - 1)
        return [(cut, n_samples)]
    initial_train = max(int(n_samples * initial_train_ratio), 100)
    initial_train = min(initial_train, n_samples - n_folds * 10)
    if initial_train < 50:
        initial_train = max(50, n_samples // 3)
    remaining = n_samples - initial_train
    fold_size = max(remaining // n_folds, 10)
    splits: List[Tuple[int, int]] = []
    for i in range(n_folds):
        train_end = initial_train + i * fold_size
        val_end = train_end + fold_size
        if i == n_folds - 1:
            val_end = n_samples
        train_end = min(train_end, n_samples - 1)
        val_end = min(val_end, n_samples)
        if val_end - train_end < 5:
            continue
        splits.append((train_end, val_end))
    if not splits:
        cut = max(1, int(n_samples * 0.80))
        cut = min(cut, n_samples - 1)
        splits.append((cut, n_samples))
    return splits


def _evaluate_ml_model_walk_forward(
    factory: Callable[[], Any],
    X_raw: np.ndarray,
    y: np.ndarray,
    n_folds: int,
) -> float:
    splits = _walk_forward_splits(len(X_raw), n_folds)
    log_losses: List[float] = []
    for train_end, val_end in splits:
        try:
            fold_scaler = StandardScaler()
            X_tr = fold_scaler.fit_transform(X_raw[:train_end])
            X_va = fold_scaler.transform(X_raw[train_end:val_end])
            y_tr = y[:train_end]
            y_va = y[train_end:val_end]
            if len(np.unique(y_va)) < 2 or len(np.unique(y_tr)) < 2:
                continue
            m = factory()
            m.fit(X_tr, y_tr)
            proba = m.predict_proba(X_va)
            if proba.shape[1] != 3:
                continue
            ll = log_loss(y_va, proba, labels=[0, 1, 2])
            log_losses.append(float(ll))
        except Exception as exc:
            logger.debug("Walk-forward fold échoué : %s", exc)
            continue
    if not log_losses:
        return float("inf")
    return float(np.mean(log_losses))


def _make_xgb_factory() -> Callable[[], Any]:
    n_jobs = MODEL_N_JOBS if MODEL_N_JOBS != 0 else 1
    def factory() -> Any:
        return XGBClassifier(
            n_estimators=XGB_N_ESTIMATORS,
            max_depth=XGB_MAX_DEPTH,
            learning_rate=XGB_LEARNING_RATE,
            random_state=MODEL_RANDOM_SEED,
            eval_metric="mlogloss",
            objective="multi:softprob",
            num_class=3,
            n_jobs=n_jobs,
            subsample=XGB_SUBSAMPLE,
            colsample_bytree=XGB_COLSAMPLE,
            min_child_weight=XGB_MIN_CHILD_WEIGHT,
            reg_lambda=XGB_REG_LAMBDA,
            reg_alpha=XGB_REG_ALPHA,
            tree_method="hist",
        )
    return factory


def _make_lgbm_factory() -> Callable[[], Any]:
    n_jobs = MODEL_N_JOBS if MODEL_N_JOBS != 0 else 1
    def factory() -> Any:
        return LGBMClassifier(
            n_estimators=LGBM_N_ESTIMATORS,
            max_depth=LGBM_MAX_DEPTH,
            learning_rate=LGBM_LEARNING_RATE,
            num_leaves=LGBM_NUM_LEAVES,
            min_child_samples=LGBM_MIN_CHILD_SAMPLES,
            subsample=LGBM_SUBSAMPLE,
            colsample_bytree=LGBM_COLSAMPLE,
            reg_lambda=LGBM_REG_LAMBDA,
            random_state=MODEL_RANDOM_SEED,
            verbose=-1,
            objective="multiclass",
            num_class=3,
            n_jobs=n_jobs,
        )
    return factory


def _make_catboost_factory() -> Callable[[], Any]:
    thread_count = MODEL_N_JOBS if MODEL_N_JOBS != 0 else -1
    def factory() -> Any:
        return CatBoostClassifier(
            iterations=CATBOOST_ITERATIONS,
            depth=CATBOOST_DEPTH,
            learning_rate=CATBOOST_LEARNING_RATE,
            l2_leaf_reg=CATBOOST_L2_LEAF_REG,
            random_strength=CATBOOST_RANDOM_STRENGTH,
            random_state=MODEL_RANDOM_SEED,
            verbose=False,
            loss_function="MultiClass",
            classes_count=3,
            thread_count=thread_count,
        )
    return factory


def _make_rf_factory() -> Callable[[], Any]:
    n_jobs = MODEL_N_JOBS if MODEL_N_JOBS != 0 else 1
    max_features: Any = None
    if RF_MAX_FEATURES == "sqrt":
        max_features = "sqrt"
    elif RF_MAX_FEATURES == "log2":
        max_features = "log2"
    elif RF_MAX_FEATURES == "auto":
        max_features = "sqrt"
    def factory() -> Any:
        return RandomForestClassifier(
            n_estimators=RF_N_ESTIMATORS,
            max_depth=RF_MAX_DEPTH,
            min_samples_leaf=RF_MIN_SAMPLES_LEAF,
            min_samples_split=RF_MIN_SAMPLES_SPLIT,
            max_features=max_features,
            random_state=MODEL_RANDOM_SEED,
            n_jobs=n_jobs,
            class_weight="balanced_subsample",
        )
    return factory


def _compute_optimal_temperature(
    probas: np.ndarray,
    y_true: np.ndarray,
) -> float:
    if probas.shape[0] < 50:
        return float(TEMPERATURE_SCALING_DEFAULT)
    best_t = float(TEMPERATURE_SCALING_DEFAULT)
    best_ll = float("inf")
    lo = float(TEMPERATURE_SCALING_MIN)
    hi = float(TEMPERATURE_SCALING_MAX)
    for t in np.linspace(lo, hi, 17):
        if t <= 0:
            continue
        logits = np.log(np.clip(probas, 1e-9, 1.0)) / t
        logits -= logits.max(axis=1, keepdims=True)
        exp_logits = np.exp(logits)
        softmax = exp_logits / exp_logits.sum(axis=1, keepdims=True)
        try:
            ll = log_loss(y_true, softmax, labels=[0, 1, 2])
        except Exception:
            continue
        if ll < best_ll:
            best_ll = float(ll)
            best_t = float(t)
    return best_t


def _compute_ensemble_probas(
    ml_models: Dict[str, Any],
    pb_models: List[Tuple[str, Any]],
    Xs_set: np.ndarray,
    home_keys_set: List[str],
    away_keys_set: List[str],
    weights: Dict[str, float],
) -> Optional[np.ndarray]:
    hda_list: List[np.ndarray] = []
    w_list: List[float] = []

    for name, model in ml_models.items():
        try:
            proba = model.predict_proba(Xs_set)
            w = float(weights.get(name, 0.0))
            if w > 0 and proba.shape[1] == 3:
                hda_list.append(proba)
                w_list.append(w)
        except Exception:
            continue

    for i, (class_name, model) in enumerate(pb_models):
        w = float(weights.get(f"pb_{i}", 0.0))
        if w <= 0:
            continue
        probas: List[List[float]] = []
        try:
            for h, a in zip(home_keys_set, away_keys_set):
                grid = model.predict(h, a)
                markets = _extract_market_probabilities(grid)
                hda = markets.get("home_draw_away")
                if hda is None:
                    raise ValueError("home_draw_away indisponible")
                probas.append(hda)
            probas_arr = np.array(probas, dtype=np.float64)
            if probas_arr.shape == (Xs_set.shape[0], 3):
                hda_list.append(probas_arr)
                w_list.append(w)
        except Exception:
            continue

    if not hda_list:
        return None

    w_arr = np.array(w_list, dtype=np.float64)
    if w_arr.sum() <= 0:
        w_arr = np.ones_like(w_arr)
    w_arr = w_arr / w_arr.sum()

    stacked = np.stack(hda_list, axis=0)
    blended = np.tensordot(w_arr, stacked, axes=(0, 0))
    blended = np.clip(blended, 1e-9, 1.0)
    blended = blended / blended.sum(axis=1, keepdims=True)
    return blended


def _evaluate_ensemble_on_set(
    ml_models: Dict[str, Any],
    pb_models: List[Tuple[str, Any]],
    Xs_set: np.ndarray,
    y_set: np.ndarray,
    home_keys_set: List[str],
    away_keys_set: List[str],
    weights: Dict[str, float],
    temperature: float,
) -> Optional[Tuple[float, float]]:
    blended = _compute_ensemble_probas(
        ml_models, pb_models, Xs_set, home_keys_set, away_keys_set, weights
    )
    if blended is None:
        return None
    if temperature is not None and np.isfinite(temperature) and temperature > 0 and abs(temperature - 1.0) > 1e-6:
        logits = np.log(np.clip(blended, 1e-9, 1.0)) / float(temperature)
        logits -= logits.max(axis=1, keepdims=True)
        exp_logits = np.exp(logits)
        blended = exp_logits / exp_logits.sum(axis=1, keepdims=True)
    try:
        ll = log_loss(y_set, blended, labels=[0, 1, 2])
    except Exception:
        return None
    acc = float((blended.argmax(axis=1) == y_set).mean())
    return (float(ll), acc)


def _normalize_weights(
    weights: Dict[str, float],
    min_w: float,
    max_w: float,
) -> Dict[str, float]:
    keys = [k for k in weights.keys() if not k.startswith("__")]
    if not keys:
        return weights

    vals: Dict[str, float] = {}
    for k in keys:
        try:
            v = float(weights[k])
        except (TypeError, ValueError):
            v = 0.0
        if not np.isfinite(v) or v < 0:
            v = 0.0
        vals[k] = v

    if min_w > 0.0:
        for k in keys:
            if vals[k] < min_w:
                vals[k] = float(min_w)

    total = sum(vals.values())
    if total <= 0:
        uniform = 1.0 / len(keys)
        for k in keys:
            vals[k] = uniform
    else:
        for k in keys:
            vals[k] = vals[k] / total

    if 0.0 < max_w < 1.0:
        for _ in range(200):
            over = [k for k in keys if vals[k] > max_w + 1e-12]
            if not over:
                break
            under = [k for k in keys if k not in over]
            capped_sum = len(over) * max_w
            if capped_sum >= 1.0 - 1e-12:
                uniform = 1.0 / len(keys)
                for k in keys:
                    vals[k] = uniform
                break
            remaining = 1.0 - capped_sum
            under_sum = sum(vals[k] for k in under)
            if under_sum <= 1e-12:
                if under:
                    share = remaining / len(under)
                    for k in under:
                        vals[k] = share
                for k in over:
                    vals[k] = max_w
                break
            for k in over:
                vals[k] = max_w
            for k in under:
                vals[k] = vals[k] / under_sum * remaining

        total = sum(vals.values())
        if total > 0:
            for k in keys:
                vals[k] = vals[k] / total

    if min_w > 0.0:
        deficit_fixed = False
        for _ in range(200):
            under = [k for k in keys if vals[k] < min_w - 1e-12]
            if not under:
                deficit_fixed = True
                break
            over = [k for k in keys if k not in under and vals[k] > min_w + 1e-12]
            deficit = sum(min_w - vals[k] for k in under)
            over_excess = sum(vals[k] - min_w for k in over)
            if over_excess <= 1e-12:
                break
            for k in under:
                vals[k] = min_w
            for k in over:
                vals[k] = vals[k] - (vals[k] - min_w) / over_excess * deficit
        if not deficit_fixed:
            total = sum(vals.values())
            if total > 0:
                for k in keys:
                    vals[k] = vals[k] / total

    for k in keys:
        weights[k] = float(vals[k])
    return weights


def train_models(
    df_past: pd.DataFrame,
) -> Tuple[
    Optional[Dict[str, Any]],
    Optional[List[Tuple[str, Any]]],
    Optional[StandardScaler],
    Dict[str, float],
]:
    if len(df_past) < MIN_MATCHES_FOR_TRAINING:
        logger.warning(
            "Données insuffisantes pour l'entraînement : %d < %d",
            len(df_past), MIN_MATCHES_FOR_TRAINING,
        )
        return None, None, None, {}

    X, y, home_keys, away_keys, gh_all, ga_all, _ = create_features_with_context(df_past)
    if X.shape[0] < MIN_MATCHES_FOR_TRAINING or X.shape[0] != len(y):
        logger.warning("Échec de la construction des features pour l'entraînement")
        return None, None, None, {}

    class_counts = np.bincount(y, minlength=3)
    if np.any(class_counts < MIN_MATCHES_PER_CLASS):
        logger.warning(
            "Distribution de classes trop déséquilibrée : %s", class_counts.tolist()
        )

    n = len(X)
    cut_train = int(n * _TRAIN_RATIO)
    cut_calib = int(n * (_TRAIN_RATIO + _CALIB_RATIO))
    cut_train = max(1, min(cut_train, n - 3))
    cut_calib = max(cut_train + 1, min(cut_calib, n - 2))

    X_train_raw = X[:cut_train].astype(np.float64, copy=True)
    X_calib_raw = X[cut_train:cut_calib].astype(np.float64, copy=True)
    X_test_raw = X[cut_calib:].astype(np.float64, copy=True)

    y_train = y[:cut_train]
    y_calib = y[cut_train:cut_calib]
    y_test = y[cut_calib:]

    home_keys_train = home_keys[:cut_train]
    away_keys_train = away_keys[:cut_train]
    home_keys_calib = home_keys[cut_train:cut_calib]
    away_keys_calib = away_keys[cut_train:cut_calib]
    home_keys_test = home_keys[cut_calib:]
    away_keys_test = away_keys[cut_calib:]
    gh_train = gh_all[:cut_train]
    ga_train = ga_all[:cut_train]

    stage_print(
        f"🤖 ENTRAÎNEMENT — train={cut_train}, calib={cut_calib - cut_train}, "
        f"test={n - cut_calib}, walk-forward={MODEL_WALK_FORWARD_FOLDS} folds"
    )

    if FEATURE_OUTLIER_ZSCORE > 0:
        mean = X_train_raw.mean(axis=0)
        std = X_train_raw.std(axis=0)
        std[std == 0] = 1.0
        z_train = np.abs((X_train_raw - mean) / std)
        z_calib = np.abs((X_calib_raw - mean) / std)
        z_test = np.abs((X_test_raw - mean) / std)
        np.clip(z_train, 0.0, FEATURE_OUTLIER_ZSCORE, out=z_train)
        np.clip(z_calib, 0.0, FEATURE_OUTLIER_ZSCORE, out=z_calib)
        np.clip(z_test, 0.0, FEATURE_OUTLIER_ZSCORE, out=z_test)
        X_train_raw = mean + z_train * std
        X_calib_raw = mean + z_calib * std
        X_test_raw = mean + z_test * std

    scaler = StandardScaler()
    Xs_train = scaler.fit_transform(X_train_raw)
    Xs_calib = scaler.transform(X_calib_raw)
    Xs_test = scaler.transform(X_test_raw)

    ml_models: Dict[str, Any] = {}
    weights: Dict[str, float] = {}

    factories: List[Tuple[str, Callable[[], Any], str]] = []
    if XGBClassifier is not None:
        factories.append(("XGB", _make_xgb_factory(), "XGBOOST"))
    if LGBMClassifier is not None:
        factories.append(("LGBM", _make_lgbm_factory(), "LIGHTGBM"))
    if CatBoostClassifier is not None:
        factories.append(("CatBoost", _make_catboost_factory(), "CATBOOST"))
    if RandomForestClassifier is not None:
        factories.append(("RF", _make_rf_factory(), "RANDOM FOREST"))

    for name, factory, display in factories:
        try:
            m = factory()
            m.fit(Xs_train, y_train)
            calibrated = _calibrate_or_keep(name, m, Xs_calib, y_calib)
            ml_models[name] = calibrated

            ll_wf = _evaluate_ml_model_walk_forward(
                factory, X_train_raw, y_train, MODEL_WALK_FORWARD_FOLDS
            )
            if not np.isfinite(ll_wf):
                try:
                    ll_wf = log_loss(
                        y_calib,
                        calibrated.predict_proba(Xs_calib),
                        labels=[0, 1, 2],
                    )
                    logger.warning(
                        "%s : walk-forward indisponible, repli sur calibration (%.4f)",
                        name, ll_wf,
                    )
                except Exception:
                    ll_wf = 1.10

            weights[name] = 1.0 / (float(ll_wf) + 1e-6)

            logger.info("%s — Walk-forward LogLoss %.4f", name, float(ll_wf))
            stage_print(f"✅ {display} — WF: {float(ll_wf):.4f}")
        except Exception as exc:
            logger.error("%s : %s", display, exc)
            stage_print(f"❌ {display} : échec")

    if DL_ENABLED and torch is not None and nn is not None and _TorchNet is not None:
        try:
            torch.manual_seed(MODEL_RANDOM_SEED)
            model = _TorchNet(Xs_train.shape[1])
            opt = torch.optim.AdamW(
                model.parameters(), lr=DL_LEARNING_RATE, weight_decay=DL_WEIGHT_DECAY
            )
            scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                opt, mode="min", factor=0.5, patience=5
            )
            crit = nn.CrossEntropyLoss()
            Xt = torch.FloatTensor(Xs_train)
            yt = torch.LongTensor(y_train)
            Xc = torch.FloatTensor(Xs_calib)
            yc = torch.LongTensor(y_calib)
            loader = DataLoader(
                TensorDataset(Xt, yt), batch_size=DL_BATCH_SIZE, shuffle=True
            )
            best_val_loss = float("inf")
            best_state = None
            patience_counter = 0
            for _ in range(DL_EPOCHS):
                model.train()
                for bx, by in loader:
                    opt.zero_grad()
                    loss = crit(model(bx), by)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), DL_GRAD_CLIP)
                    opt.step()
                model.eval()
                with torch.no_grad():
                    val_logits = model(Xc)
                    val_loss = crit(val_logits, yc).item()
                scheduler.step(val_loss)
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    best_state = {k: v.clone() for k, v in model.state_dict().items()}
                    patience_counter = 0
                else:
                    patience_counter += 1
                    if patience_counter >= DL_EARLY_STOPPING_PATIENCE:
                        break
            if best_state is not None:
                model.load_state_dict(best_state)
            calibrated = _calibrate_or_keep("DL", model, Xs_calib, y_calib)
            ml_models["DL"] = calibrated
            try:
                ll_calib = log_loss(
                    y_calib,
                    calibrated.predict_proba(Xs_calib),
                    labels=[0, 1, 2],
                )
            except Exception:
                ll_calib = 1.10
            weights["DL"] = 1.0 / (float(ll_calib) + 1e-6)
            logger.info("Deep Learning — calibration LogLoss %.4f", float(ll_calib))
            stage_print(f"✅ DEEP LEARNING — CALIB: {float(ll_calib):.4f}")
        except Exception as exc:
            logger.error("Deep Learning : %s", exc)
            stage_print("❌ DEEP LEARNING : échec")

    stage_print("🤖 PENALTY BLOG MODELS (entraînement unique sur la partie train)")
    pb_models: List[Tuple[str, Any]] = []
    for class_name in _PB_MODEL_ORDER:
        status, payload = _fit_pb_model(
            class_name, gh_train, ga_train, home_keys_train, away_keys_train
        )
        if status == "ok":
            pb_models.append((class_name, payload))
            logger.info("penaltyblog %s entraîné", class_name)
            stage_print(f"✅ {class_name.upper()} : entraîné")
        else:
            logger.error("penaltyblog %s : %s", class_name, payload)
            stage_print(f"❌ {class_name.upper()} : échec ({payload})")

    for i, (class_name, model) in enumerate(pb_models):
        try:
            probas: List[List[float]] = []
            for h, a in zip(home_keys_calib, away_keys_calib):
                grid = model.predict(h, a)
                markets = _extract_market_probabilities(grid)
                hda = markets.get("home_draw_away")
                if hda is None:
                    raise ValueError("home_draw_away indisponible")
                probas.append(hda)
            probas_arr = np.array(probas, dtype=np.float64)
            ll_calib = log_loss(y_calib, probas_arr, labels=[0, 1, 2])
            weights[f"pb_{i}"] = 1.0 / (float(ll_calib) + 1e-6)
            logger.info("penaltyblog %s — calibration LogLoss %.4f", class_name, ll_calib)
            stage_print(f"✅ {class_name.upper()} — CALIB: {ll_calib:.4f}")
        except Exception as exc:
            logger.error("Pondération pb_%d=%s : %s", i, class_name, exc)
            weights[f"pb_{i}"] = 1.0

    if not ml_models and not pb_models:
        logger.error("Aucun modèle n'a pu être entraîné")
        stage_print("❌ Aucun modèle n'a pu être entraîné")
        return None, None, None, {}

    weights = _normalize_weights(weights, ENSEMBLE_MIN_WEIGHT, ENSEMBLE_MAX_WEIGHT)

    if TEMPERATURE_SCALING_ENABLED:
        try:
            calib_blend = _compute_ensemble_probas(
                ml_models, pb_models, Xs_calib,
                home_keys_calib, away_keys_calib, weights,
            )
            if calib_blend is not None:
                temp = _compute_optimal_temperature(calib_blend, y_calib)
                weights["__temperature__"] = float(temp)
                logger.info("Température optimale (calibration) : %.4f", temp)
                stage_print(f"✅ TEMPÉRATURE OPTIMALE (calib) : {temp:.4f}")
            else:
                weights["__temperature__"] = float(TEMPERATURE_SCALING_DEFAULT)
        except Exception as exc:
            logger.warning("Calcul température échoué : %s", exc)
            weights["__temperature__"] = float(TEMPERATURE_SCALING_DEFAULT)

    stage_print("📊 ÉVALUATION FINALE SUR LE JEU DE TEST (une seule fois)")
    final_temperature = float(weights.get("__temperature__", 1.0))
    test_metrics = _evaluate_ensemble_on_set(
        ml_models, pb_models, Xs_test, y_test,
        home_keys_test, away_keys_test,
        weights, final_temperature,
    )
    if test_metrics is not None:
        ll_test, acc_test = test_metrics
        logger.info(
            "Test final — LogLoss %.4f | Accuracy %.2f%%", ll_test, acc_test * 100
        )
        stage_print(
            f"📊 TEST FINAL — LogLoss: {ll_test:.4f} | Accuracy: {acc_test * 100:.1f}%"
        )
    else:
        logger.warning("Évaluation finale sur le test impossible.")

    return ml_models, pb_models, scaler, weights
